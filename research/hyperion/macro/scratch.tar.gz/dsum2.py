import pickle
from collections import Counter
res=pickle.load(open('dstate.pkl','rb'))
D=[x for r in res for x in r[4]]; G=len(res)
pc=lambda n,m: f'{100*n/m:.0f}%' if m else '-'
n=len(D)
print('pre5 last char R',pc(sum(x['pre5'][-1:]=='R' for x in D),n),' any R in pre5',pc(sum('R' in x['pre5'] for x in D),n))
print('branch R & saw attacker in 5r before',pc(sum(x['branch']=='R' and x['sawatk'] for x in D),n),' R & seen any',pc(sum(x['branch']=='R' and x['seen5'] for x in D),n),' R & none seen',pc(sum(x['branch']=='R' and not x['seen5'] for x in D),n))
print('blind (attacker not in sees at last turn start)',pc(sum(x['blind'] for x in D),n))
print('after-hit branch',Counter(x['after'] for x in D).most_common(8))
print('K in window',pc(sum(x['kwin'] for x in D),n),' K at hit',pc(sum(x['kept_at_hit'] for x in D),n))
print('ally hit in r1-1..r1',pc(sum(x['ally_hit']>0 for x in D),n))
# hp drivers
low=[x for x in D if x['hpf']<.5]
print('\nlow<50%:',len(low),pc(len(low),n))
print(' camp-driven (cd30f>=0.3 & cd>=chd)',pc(sum(x['cd30f']>=.3 and x['cd30']>=x['chd30'] for x in low),len(low)),
      ' champ-driven(chd>cd & chd30f>=.3)',pc(sum(x['chd30f']>=.3 and x['chd30']>x['cd30'] for x in low),len(low)),
      ' neither (low >30r earlier/not healed)',pc(sum(x['cd30f']<.3 and x['chd30f']<.3 for x in low),len(low)))
print(' hp30 of neither',sorted(round(x['hp30'],2) for x in low if x['cd30f']<.3 and x['chd30f']<.3)[::20])
