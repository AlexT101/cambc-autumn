# Belief audit

240 team-games, 231924 dumps.

| Check | Wrong | Checked | Rate |
| --- | ---: | ---: | ---: |
| Enemy true tile not in `possible` | 0 | 0 | - |
|   of which teleport (unmodelled) | 0 | 0 | - |
|   of which after a comms fix | 0 | 0 | - |
|   of which after respawn / recall / dash | 0 | 0 | - |
|   of which other | 0 | 0 | - |
|   in sets of 9 tiles or fewer (ground-cast targets) | 0 | 0 | - |
| Enemy ability ready before the bot believes, unseen | 120 | 1976284 | 0.0% |
|   same while visible | 0 | 1976284 | 0.0% |
| Enemy ability believed ready before it is, visible | 720 | 1976284 | 0.0% |
|   unseen (a cast we missed; expected) | 521668 | 1976284 | 26.4% |
| Visible enemy at the wrong tile | 4 | 145802 | 0.0% |
| Enemy in sight but not visible (did not move) | 28 | 1049482 | 0.0% |
| Enemy alive/dead wrong | 0 | 1049482 | 0.0% |
| Respawn window misses the respawn | 0 | 57938 | 0.0% |
| Camp state wrong, seen this turn | 0 | 649568 | 0.0% |
| Camp state stale (not seen) | 592522 | 3075740 | 19.3% |
| Awake believed asleep, seen | 860 | 2219228 | 0.0% |
| Awake believed asleep, unseen | 159902 | 2219228 | 7.2% |
| Asleep believed awake, seen | 1108 | 2219228 | 0.0% |
| Asleep believed awake, unseen | 236 | 2219228 | 0.0% |
| Awake unknown | 25030 | 2219228 | 1.1% |
| Respawn round early, seen | 0 | 826936 | 0.0% |
| Respawn round late, seen | 0 | 826936 | 0.0% |
| Respawn round off, unseen | 172 | 826936 | 0.0% |
| Capture holder wrong, tiles in view | 0 | 86622 | 0.0% |
| Capture holder stale | 1854 | 86622 | 2.1% |
| Payout round (held_since + 6) wrong | 1086 | 35480 | 3.1% |
| Respawn later than believed: tiles occupied (expected) | 10242 | 826936 | 1.2% |
| Altar locks wrong | 135436 | 231924 | 58.4% |
| Own turn slot wrong | 78338 | 231924 | 33.8% |

Stale camp states (believed -> true): alive -> true cleared 131442, alive -> true respawning 457508, cleared -> true alive 1068, cleared -> true respawning 2218, respawning -> true cleared 286.

Unseen live enemies: 842340; untracked (anywhere) 63.4%, set left out for fuel 308612.

`possible` size by rounds since last fixed:

| Rounds | n | median | p90 | max |
| --- | ---: | ---: | ---: | ---: |
| 0 | 0 | - | - | - |
| 1-2 | 0 | - | - | - |
| 3-5 | 0 | - | - | - |
| 6-10 | 0 | - | - | - |
| 11-20 | 0 | - | - | - |
| >20 | 0 | - | - | - |

Dump fuel: median 7722, p90 10265, max 21261.

Integrity: decode_count_mismatch 0, visible_set_wrong 0, group_map_mismatch 0, self_team_mismatch 0, self_alive_wrong 0, slot_rule_vs_events 0 (group map checked 4188).

## altar_locks_wrong (135436)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r35 c2: believed [(0, 18, 8)], true [(0, 18, 8), (1, 18, 8)]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r35 c0: believed [], true [(0, 18, 8), (1, 18, 8)]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r35 c1: believed [(0, 18, 8)], true [(0, 18, 8), (1, 18, 8)]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r40 c1: believed [(0, 18, 8)], true [(0, 18, 8), (1, 18, 8)]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r40 c2: believed [(0, 18, 8)], true [(0, 18, 8), (1, 18, 8)]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r40 c0: believed [], true [(0, 18, 8), (1, 18, 8)]

## awake_believed_asleep_seen (860)

- 9fead5c12b5ea91e (003-00contest-12.repl26a, side A) r360 c1 slot 1 g4: believed asleep, true awake (damaged r278)
- 9fead5c12b5ea91e (003-00contest-12.repl26a, side B) r360 c8 slot 8 g4: believed asleep, true awake (damaged r356)
- 9fead5c12b5ea91e (003-00contest-12.repl26a, side B) r1210 c6 slot 8 g2: believed asleep, true awake (damaged r590)
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side A) r360 c1 slot 1 g4: believed asleep, true awake (damaged r278)
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side B) r360 c8 slot 8 g4: believed asleep, true awake (damaged r356)
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side B) r1210 c6 slot 8 g2: believed asleep, true awake (damaged r590)

## awake_believed_asleep_unseen (159902)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r5 c0 slot 0 g5: believed asleep, true awake (damaged r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r15 c0 slot 0 g1: believed asleep, true awake (damaged r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r15 c0 slot 0 g8: believed asleep, true awake (damaged r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r15 c0 slot 0 g9: believed asleep, true awake (damaged r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r15 c1 slot 2 g0: believed asleep, true awake (damaged r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r15 c1 slot 2 g1: believed asleep, true awake (damaged r-1)

## awake_believed_awake_seen (1108)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r60 c2 slot 5 g3: believed awake, true asleep (damaged r53)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1190 c1 slot 5 g2: believed awake, true asleep (damaged r1180)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1195 c1 slot 4 g2: believed awake, true asleep (damaged r1180)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1200 c1 slot 3 g2: believed awake, true asleep (damaged r1180)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1205 c1 slot 2 g2: believed awake, true asleep (damaged r1180)
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r710 c5 slot 2 g2: believed awake, true asleep (damaged r706)

## awake_believed_awake_unseen (236)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r70 c2 slot 5 g3: believed awake, true asleep (damaged r53)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r435 c2 slot 4 g2: believed awake, true asleep (damaged r431)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1110 c2 slot 5 g2: believed awake, true asleep (damaged r942)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1210 c1 slot 3 g2: believed awake, true asleep (damaged r1180)
- f49874374b0db91a (002-00anvil-21.repl26a, side A) r70 c2 slot 5 g3: believed awake, true asleep (damaged r53)
- f49874374b0db91a (002-00anvil-21.repl26a, side A) r435 c2 slot 4 g2: believed awake, true asleep (damaged r431)

## camp_state_stale (592522)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r5 c1 slot 2 g4: believed alive, true cleared (bot respawn r-1, last seen r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r5 c1 slot 2 g5: believed alive, true cleared (bot respawn r-1, last seen r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r5 c2 slot 4 g5: believed alive, true cleared (bot respawn r-1, last seen r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r10 c0 slot 1 g5: believed alive, true cleared (bot respawn r-1, last seen r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r10 c0 slot 1 g12: believed alive, true cleared (bot respawn r-1, last seen r-1)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r10 c1 slot 3 g4: believed alive, true cleared (bot respawn r-1, last seen r-1)

## holder_stale (1854)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r65 c2 slot 4 g4: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 0)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r380 c2 slot 1 g6: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 0)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r390 c1 slot 5 g9: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 0)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r855 c1 slot 4 g6: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 0)
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1175 c2 slot 0 g3: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 0)
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r100 c3 slot 2 g9: believed -1, true 0 (0 us, 1 them, -1 nobody; engine 2)

## payout_round_off (1086)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r435 c1 slot 2 g6: held_since r434 (payout r440), paid r438
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r690 c0 slot 3 g4: held_since r690 (payout r696), paid r694
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r730 c0 slot 3 g9: held_since r730 (payout r736), paid r734
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r730 c2 slot 5 g9: held_since r730 (payout r736), paid r734
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r805 c2 slot 4 g8: held_since r805 (payout r811), paid r809
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r1200 c1 slot 3 g9: held_since r1200 (payout r1206), paid r1204

## ready_round_early_visible (720)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r220 c1 slot 1 -> e3 slot 0: believed ready r221, truly r228
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r220 c2 slot 3 -> e3 slot 0: believed ready r221, truly r228
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r220 c0 slot 5 -> e3 slot 0: believed ready r221, truly r228
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r235 c0 slot 0 -> e3 slot 1: believed ready r235, truly r240
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r235 c1 slot 2 -> e3 slot 1: believed ready r235, truly r240
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r235 c2 slot 4 -> e3 slot 1: believed ready r235, truly r240

## ready_round_too_late (120)

- f49874374b0db91a (001-00anvil-12.repl26a, side B) r355 c3 slot 1 -> e0 slot 1: believed ready r357, truly r355
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r475 c3 slot 5 -> e0 slot 0: believed ready r479, truly r476
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r645 c3 slot 1 -> e0 slot 0: believed ready r648, truly r646
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r715 c5 slot 3 -> e0 slot 0: believed ready r718, truly r716
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r775 c5 slot 1 -> e0 slot 0: believed ready r776, truly r775
- f49874374b0db91a (001-00anvil-12.repl26a, side B) r1005 c3 slot 1 -> e0 slot 0: believed ready r1009, truly r1005

## respawn_round_early_unseen (42)

- 9fead5c12b5ea91e (003-00contest-12.repl26a, side A) r185 c3 slot 2 g2: believed r220, respawned r231
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side A) r185 c3 slot 2 g2: believed r220, respawned r231
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side B) r145 c7 slot 7 g6: believed r189, respawned r191
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side B) r150 c7 slot 6 g6: believed r189, respawned r191
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side B) r155 c7 slot 1 g6: believed r189, respawned r191
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side B) r160 c7 slot 0 g6: believed r189, respawned r191

## respawn_round_late_unseen (130)

- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side A) r635 c3 slot 6 g17: believed r694, respawned r692
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side A) r640 c3 slot 5 g17: believed r694, respawned r692
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side A) r645 c3 slot 0 g17: believed r694, respawned r692
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side A) r650 c3 slot 1 g17: believed r694, respawned r692
- b0fe966c484c8c6a (029-00rushbait-v2-12.repl26a, side A) r655 c3 slot 0 g17: believed r694, respawned r692
- b0fe966c484c8c6a (030-00rushbait-v2-21.repl26a, side A) r635 c3 slot 6 g17: believed r694, respawned r692

## slot_wrong (78338)

- f49874374b0db91a (001-00anvil-12.repl26a, side A) r35 c0: bot slot 4, rule 2, action turns [2]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r50 c2: bot slot 5, rule 3, action turns [3]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r90 c0: bot slot 3, rule 5, action turns []
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r95 c2: bot slot 4, rule 2, action turns []
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r95 c0: bot slot 2, rule 4, action turns [4]
- f49874374b0db91a (001-00anvil-12.repl26a, side A) r100 c2: bot slot 5, rule 3, action turns [3]

## visible_missed (28)

- 9fead5c12b5ea91e (003-00contest-12.repl26a, side B) r225 c7 slot 5 -> e0: engine shows it at (22, 26) at turn start
- 9fead5c12b5ea91e (003-00contest-12.repl26a, side B) r225 c7 slot 5 -> e1: engine shows it at (28, 22) at turn start
- 9fead5c12b5ea91e (003-00contest-12.repl26a, side B) r225 c7 slot 5 -> e2: engine shows it at (27, 22) at turn start
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side B) r225 c7 slot 5 -> e0: engine shows it at (22, 26) at turn start
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side B) r225 c7 slot 5 -> e1: engine shows it at (28, 22) at turn start
- 9fead5c12b5ea91e (004-00contest-21.repl26a, side B) r225 c7 slot 5 -> e2: engine shows it at (27, 22) at turn start

## visible_pos_wrong (4)

- f2a515293032d147 (061-gen-archipelago-600102014-12.repl26a, side A) r1020 c1 slot 1 -> e4: believed (50, 53), true (47, 50)
- f2a515293032d147 (062-gen-archipelago-600102014-21.repl26a, side A) r1020 c1 slot 1 -> e4: believed (50, 53), true (47, 50)
- 5c5b5313c4b0001a (075-gen-atoll-600101906-12.repl26a, side B) r1135 c5 slot 1 -> e0: believed (17, 19), true (20, 22)
- 5c5b5313c4b0001a (076-gen-atoll-600101906-21.repl26a, side B) r1135 c5 slot 1 -> e0: believed (17, 19), true (20, 22)

