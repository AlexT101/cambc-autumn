import sys,glob,collections,multiprocessing as mp,pickle
sys.path.insert(0,sys.argv[1]); from sumd import load
ch=lambda a,b: max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def work(gf):
    try: hdr,g,br=load(gf)
    except Exception: return []
    out=[]; W=g.winner; dmg=g.champ_damage
    byv=collections.defaultdict(list)
    for d in dmg: byv[d[3]].append(d[1])
    deaths=[]
    for c in g.team_of:
        a=g.ch(c)['alive']
        for i in range(1,len(a)):
            if a[i-1] and not a[i]: deaths.append((i+1,c))
    deaths.sort(); seen=set()
    for r,c in deaths:
        t=g.team_of[c]
        if g.name_of[c] in ('Issac','Cassi') and (r,t) in seen: continue
        seen.add((r,t))
        rs=sorted(set(x for x in byv[c] if x<=r and x>r-40))
        if not rs or rs[-1]<r-3: continue
        s=rs[-1]
        for x in reversed(rs):
            if s-x>3: break
            s=x
        dur=r-s
        i0=s-2; i1=r-2
        v0=g.pos(c,i0); v1=g.pos(c,i1)
        if not v0 or not v1: continue
        allies=[]
        for cc in g.team_of:
            if cc==c or g.team_of[cc]!=t: continue
            p0=g.pos(cc,i0); p1=g.pos(cc,i1)
            if not p0 or not p1: continue
            hp=g.ch(cc)['hp'][i0]/g.ch(cc)['maxHp'][i0]
            b=''.join(br.get((rr,cc),'.') for rr in range(s,r+1))
            allies.append((ch(p0,v0),ch(p1,v1),hp,b,g.name_of[cc]))
        att=set(d[2] for d in dmg if d[3]==c and s<=d[1]<=r)
        enemies_in=sum(1 for cc in g.team_of if g.team_of[cc]!=t and g.pos(cc,i0) and ch(g.pos(cc,i0),v0)<=8)
        vb=''.join(br.get((rr,c),'.') for rr in range(s,r+1))
        out.append(dict(g=hdr[0].split()[1],r=r,s=s,dur=dur,win=(t==W),name=g.name_of[c],allies=allies,natt=len(att),vb=vb,enem=enemies_in,
                        sp0=ch(v0,g.map.spawn_center(t)),sp1=ch(v1,g.map.spawn_center(t))))
    return out
if __name__=='__main__':
    files=[f for d in sys.argv[2:4] for f in glob.glob(d+'/games/*.txt') if not f.endswith('.fights.txt')]
    with mp.Pool(32) as p: res=[x for l in p.map(work,files) for x in l]
    pickle.dump(res,open(sys.argv[4],'wb')); print(len(res))
