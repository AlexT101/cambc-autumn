import sys,re,zipfile
sys.path.insert(0,'/home/ubuntu/cambc-autumn/tools/replay')
from analysis import Game
def load(gf):
    hdr=open(gf).read().split('\n')[:3]
    src=re.search(r'source (\S+)',hdr[1]).group(1); an=re.search(r'analysis (\S+)',hdr[1]).group(1)
    g=Game(an); br={}
    z=zipfile.ZipFile('/home/ubuntu/cambc-autumn/'+src)
    for t in ('team-a.stdout','team-b.stdout'):
        for l in z.read(t).decode(errors='replace').split('\n'):
            p=l.split()
            if len(p)>=4 and p[0]=='D': br[(int(p[1]),int(p[2]))]=p[3]
    return hdr,g,br
short={'Vesper Vale':'Ves','Heart of Ruin':'HoR'}
def main(gf,maxd=8,detail=()):
    hdr,g,br=load(gf)
    nm=lambda c: ('a' if g.team_of[c]==0 else 'b')+short.get(g.name_of[c],g.name_of[c][:4])+str(c)
    W=g.winner
    print(hdr[0]); print(hdr[2])
    sp=[g.map.spawn_center(t) for t in (0,1)] if hasattr(g.map,'spawn_center') else None
    P=lambda c,i: g.pos(c,i)
    ch=lambda a,b: max(abs(a[0]-b[0]),abs(a[1]-b[1]))
    deaths=[]
    for c in g.team_of:
        a=g.ch(c)['alive']
        for i in range(1,len(a)):
            if a[i-1] and not a[i]: deaths.append((i+1,c))
    deaths.sort(); seen=set(); k=0; dmg=g.champ_damage
    for r,c in deaths:
        t=g.team_of[c]
        if g.name_of[c] in ('Issac','Cassi') and (r,t) in seen: continue
        seen.add((r,t)); k+=1
        if k>maxd: break
        hits=[d for d in dmg if d[3]==c and r-4<=d[1]<=r]
        att=sorted(set(nm(d[2]) for d in hits))
        killer=nm(hits[-1][2]) if hits else 'CAMP'
        i=r-2  # end of round r-1
        vp=P(c,i)
        seq=''.join(br.get((rr,c),'.') for rr in range(r-12,r+1))
        spc=g.map.spawn_center(t)
        d0=ch(P(c,r-13) or vp,spc) if vp else -1; d1=ch(vp,spc) if vp else -1
        gems=g.ch(c)['gems'][i]; hp=int(100*g.ch(c)['hp'][max(0,r-6)]/g.ch(c)['maxHp'][max(0,r-6)])
        allies=[];enem=[]
        for cc in g.team_of:
            if cc==c: continue
            p=P(cc,i)
            if not p: 
                (allies if g.team_of[cc]==t else enem).append(f'{nm(cc)}:dead'); continue
            dd=ch(p,vp) if vp else -1
            s=f"{nm(cc)}:{dd}{''.join(br.get((rr,cc),'.') for rr in range(r-6,r+1))}"
            (allies if g.team_of[cc]==t else enem).append(s)
        res='W' if t==W else 'L'
        print(f"r{r} {res} {nm(c)} by {killer} att{att} g{gems} hp@-5 {hp}% spawnd {d0}->{d1} br[{seq}]\n    allies {' '.join(allies)}\n    enemies {' '.join(enem)}")
if __name__=='__main__':
    main(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 8)
