import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def cheb(a,b): return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    mp=json.loads((d/meta['mapFile']).resolve().read_text())
    camps={c['id']:c for c in mp['camps']}
    groups=mp['groups']
    R=json.load(gzip.open(d/'rounds.json.gz'))
    rix={r:i for i,r in enumerate(R['round'])}
    # group state per round
    gs={}; rows=R['groups']; gi=0; states=[]
    n=len(R['round'])
    st=[None]*n
    cur={}
    for i in range(n):
        rnd=R['round'][i]
        while gi<len(rows) and rows[gi][0]<=rnd:
            cur[rows[gi][1]]=rows[gi]; gi+=1
        st[i]={g:(row[2],row[6]) for g,row in cur.items()}
    # first camp attack per champion per round
    att={}
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k'] in('attack','cast') and e.get('cdmg'):
            key=(e['a'],e['r'])
            if key not in att: att[key]=camps[e['cdmg'][0][0]]['group']
    out=[]
    ch=R['champions']
    for c in ch:
        last_work=None  # (round index, pos, group)
        for i in range(n):
            if not c['alive'][i] or c['x'][i] is None: last_work=None; continue
            g=att.get((c['id'],R['round'][i]))
            p=(c['x'][i],c['y'][i])
            if g is not None:
                if last_work is not None and last_work[2]!=g and i-last_work[0]>3 and c['gems'][i]==0 or (last_work and last_work[2]!=g and i-last_work[0]>3):
                    i0,p0,g0=last_work
                    # nearest up group from p0 at i0 (excluding g0)
                    def gd(gid): return min(cheb(p0,tuple(t)) for t in groups[gid]['tiles'])
                    ups=[gid for gid,(s,a) in st[i0].items() if s==1 and gid!=g0 and 'Monolith' not in groups[gid]['types']]
                    nearest=min((gd(x) for x in ups), default=99)
                    out.append((i-i0, gd(g), nearest, len(ups), c['gems'][i0]>0))
                last_work=(i,p,g)
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=[x for l in ex.map(one,dirs) for x in l]
    import statistics as S
    print(len(res),'transitions between groups (gap>3 rounds)')
    for bag in (False,True):
        r=[x for x in res if x[4]==bag]
        print('bag' if bag else 'empty', len(r), 'rounds gap median',S.median(x[0] for x in r),'mean %.1f'%S.mean(x[0] for x in r),
              '| dist chosen median',S.median(x[1] for x in r),'mean %.1f'%S.mean(x[1] for x in r),'| nearest up median',S.median(x[2] for x in r),'mean %.1f'%S.mean(x[2] for x in r), '| ups %.1f'%S.mean(x[3] for x in r))
    c=collections.Counter((min(x[1],30)//5*5, min(x[2],30)//5*5) for x in res)
    print('chosen-dist bucket x nearest-dist bucket'); 
    for a in range(0,35,5): print(a, [c[(a,b)] for b in range(0,35,5)])
