import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    mp=json.loads((d/meta['mapFile']).resolve().read_text())
    mg={g['id'] for g in mp['groups'] if 'Monolith' in g['types']}
    R=json.load(gzip.open(d/'rounds.json.gz'))
    strs=collections.defaultdict(list)
    for c in R['champions']:
        for rr in (100,300,600):
            if rr<len(c['str']): strs[rr].append((c['str'][rr], c['maxHp'][rr]))
    if not mg: return None, strs
    caps=[]
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k']=='capture' and e['g'] in mg: caps.append((e['r'],e['team'],sum(s[1] for s in e['shares'])))
        if e['k']=='group_clear' and e['g'] in mg: pass
    return (meta['result']['winner'], caps, meta['result']['rounds']), strs
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    S=collections.defaultdict(list)
    for _,s in res:
        for k,v in s.items(): S[k]+=v
    for k in sorted(S): print(k,'mean str %.0f maxhp %.0f'%(sum(a for a,b in S[k])/len(S[k]), sum(b for a,b in S[k])/len(S[k])))
    m=[x for x,_ in res if x]
    none=sum(1 for w,c,r in m if not c)
    first=collections.Counter()
    for w,c,r in m:
        if c: first[c[0][1]==w]+=1
    print(len(m),'monolith games; none captured',none,'; first capturer wins',first)
    print('caps per game', sum(len(c) for w,c,r in m)/len(m), 'first cap round median', sorted(c[0][0] for w,c,r in m if c)[len([1 for w,c,r in m if c])//2] if first else None)
