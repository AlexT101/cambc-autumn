"""Champion-time cost buckets from macro features: python3 -I buckets.py features.jsonl.gz"""
import gzip, json, sys
from collections import defaultdict
G = [json.loads(l) for l in gzip.open(sys.argv[1], 'rt')]
for side in ('win', 'lose', 'all'):
    cr = 0; leg = defaultdict(float); T = defaultdict(float)
    for g in G:
        for t in (0, 1):
            if side != 'all' and (side == 'win') != (g['winner'] == t): continue
            cr += g['T'][t]['champ_rounds']
            for k, v in g['H'][t]['legs'].items():
                if k.endswith('|rounds'): leg[k[:-7]] += v
            for k, v in g['T'][t].items(): T[k] += v
    def L(pred): return 100 * sum(v for k, v in leg.items() if pred(k)) / cr
    print(f"{side}: champion-rounds/team-game {cr/ (len(G)*(2 if side=='all' else 1)):.0f}")
    print(f"  recall channel {100*T['tb_recall']/cr:.1f}% + walk out of spawn after recall/respawn {L(lambda k: k.startswith(('recall->','spawn->','dead->')))}%".replace('%%','%'))
    print(f"  banking: tribute {100*T['tb_tribute']/cr:.1f}% + legs to altar {L(lambda k: k.endswith('to_altar')):.1f}% + altar->camp {L(lambda k: k.startswith('altar->')):.1f}%")
    print(f"  camp->camp(other) {L(lambda k: k=='camp->to_camp(other)'):.1f}%, camp->camp(same) {L(lambda k: k=='camp->to_camp(same)'):.1f}%")
    print(f"  fight-linked walking (legs from or to a fight) {L(lambda k: 'fight' in k):.1f}%; legs ending in recall {L(lambda k: k.endswith('then_recall')):.1f}%; to spawn {L(lambda k: k.endswith('to_spawn')):.1f}%")
    print(f"  productive camp+hold {100*(T['tb_camp']+T['tb_hold'])/cr:.1f}%; idle waiting at respawning group {100*T['sub_idle_near_respawning']/cr:.1f}%")
