# Deaths and engagements: 582 games, 4065 champion-kill deaths

### D1. Champion-kill deaths per team-game

| side | deaths | gems lost | deaths with bag>=30 | no ally within 6 | outnumbered by 2+ (within 6) | no ally hit an enemy | median nearest-ally dist |
|---|---|---|---|---|---|---|---|
| win | 1.98 | 30.6 | 0.24 | 45% | 27% | 62% | 5 |
| lose | 5.01 | 76.6 | 0.58 | 37% | 23% | 56% | 4 |
| all | 6.98 | 107.2 | 0.82 | 40% | 24% | 57% | 5 |

### D2. Deaths by victim activity, 10 rounds before its first hit

| act | n | all | win | lose |
|---|---|---|---|---|
| walking out | 744 | 18% | 17% | 19% |
| farming camp | 635 | 16% | 17% | 15% |
| already fighting | 626 | 15% | 16% | 15% |
| walking across | 575 | 14% | 13% | 15% |
| walking home | 257 | 6% | 6% | 7% |
| tributing | 235 | 6% | 7% | 5% |
| recalling | 230 | 6% | 6% | 5% |
| walking w/ bag out | 217 | 5% | 5% | 6% |
| walking w/ bag across | 203 | 5% | 5% | 5% |
| holding | 193 | 5% | 4% | 5% |
| walking w/ bag home | 69 | 2% | 1% | 2% |
| idle | 59 | 1% | 2% | 1% |

### D2. Deaths by victim behaviour from first hit to death

| beh | n | all | win | lose |
|---|---|---|---|---|
| standing | 1760 | 43% | 43% | 44% |
| retreating | 1454 | 36% | 37% | 35% |
| chasing | 740 | 18% | 17% | 19% |
| recalling | 111 | 3% | 3% | 3% |

### D2. Deaths by zone of the first hit (victim frame)

| zone | n | all | win | lose |
|---|---|---|---|---|
| mid | 1802 | 44% | 48% | 43% |
| own | 1664 | 41% | 31% | 45% |
| enemy | 598 | 15% | 21% | 12% |
| ? | 1 | 0% | 0% | 0% |

### D2. Deaths by nearest ally's label at the first hit

| near_lab | n | all | win | lose |
|---|---|---|---|---|
| walk | 1740 | 43% | 39% | 44% |
| fight | 571 | 14% | 13% | 15% |
| walk_bag | 562 | 14% | 17% | 13% |
| camp | 356 | 9% | 11% | 8% |
| recall | 290 | 7% | 9% | 7% |
| idle | 190 | 5% | 5% | 5% |
| hold | 105 | 3% | 3% | 2% |
| tribute | 89 | 2% | 2% | 2% |
| dead | 64 | 2% | 1% | 2% |
| spawn | 54 | 1% | 1% | 2% |
| None | 44 | 1% | 0% | 1% |

### D3. Victim hp at its first enemy hit of the engagement

| hp | n | % |
|---|---|---|
| <100% | 890 | 22% |
| <25% | 428 | 11% |
| <50% | 682 | 17% |
| <75% | 812 | 20% |
| full | 1253 | 31% |

### D4. Deaths by local numbers at the first hit (victim side incl. victim v enemies, within 6)

| numbers | n | % |
|---|---|---|
| 1v1 | 921 | 23% |
| 2v1 | 535 | 13% |
| 1v2 | 476 | 12% |
| 2v2 | 473 | 12% |
| 3v2 | 296 | 7% |
| 3v1 | 244 | 6% |
| 2v3 | 179 | 4% |
| 3v3 | 166 | 4% |
| 1v3 | 160 | 4% |
| 4v3+ | 128 | 3% |
| 4v2+ | 127 | 3% |
| 4v1+ | 107 | 3% |

### D4. Deaths by local numbers at the first hit (victim side incl. victim v enemies, within 10)

| numbers | n | % |
|---|---|---|
| 1v1 | 415 | 10% |
| 2v2 | 415 | 10% |
| 4v4+ | 375 | 9% |
| 1v2 | 350 | 9% |
| 3v3 | 345 | 8% |
| 2v3 | 327 | 8% |
| 3v2 | 322 | 8% |
| 2v1 | 298 | 7% |
| 4v3+ | 231 | 6% |
| 3v4+ | 221 | 5% |
| 1v3 | 189 | 5% |
| 3v1 | 155 | 4% |

### E1. Engagements by numbers advantage at the first hit (own minus enemy champions within 6 of the centre), per side

| adv | side-fights | kills | deaths | K/D | dmg dealt/taken | won on kills | lost on kills |
|---|---|---|---|---|---|---|---|
| -2 | 2181 | 0.145 | 0.175 | 0.83 | 1.03 | 11% | 15% |
| -1 | 6948 | 0.113 | 0.131 | 0.86 | 1.00 | 10% | 12% |
| +0 | 16510 | 0.101 | 0.101 | 1.00 | 1.00 | 9% | 9% |
| +1 | 6948 | 0.131 | 0.113 | 1.16 | 1.00 | 12% | 10% |
| +2 | 2181 | 0.175 | 0.145 | 1.21 | 0.98 | 15% | 11% |

### E2. Side-fights by own/enemy current hp within 6 at the first hit (both sides present)

| ratio | side-fights | kills | deaths | K/D |
|---|---|---|---|---|
| <0.5 | 4814 | 0.036 | 0.287 | 0.13 |
| 0.5-0.8 | 7281 | 0.070 | 0.139 | 0.50 |
| 0.8-1.25 | 10497 | 0.093 | 0.094 | 0.99 |
| 1.25-2 | 7285 | 0.138 | 0.070 | 1.98 |
| >2 | 4855 | 0.286 | 0.036 | 7.94 |

### E2. Side-fights by own/enemy effective Strength within 6 at the first hit (both sides present)

| ratio | side-fights | kills | deaths | K/D |
|---|---|---|---|---|
| <0.5 | 6305 | 0.106 | 0.170 | 0.62 |
| 0.5-0.8 | 6116 | 0.093 | 0.125 | 0.75 |
| 0.8-1.25 | 9836 | 0.100 | 0.100 | 1.00 |
| 1.25-2 | 5963 | 0.125 | 0.094 | 1.33 |
| >2 | 6514 | 0.168 | 0.105 | 1.61 |

### E2. Side-fights by own/enemy max hp (items) within 6 at the first hit (both sides present)

| ratio | side-fights | kills | deaths | K/D |
|---|---|---|---|---|
| <0.5 | 3570 | 0.052 | 0.246 | 0.21 |
| 0.5-0.8 | 7294 | 0.087 | 0.144 | 0.60 |
| 0.8-1.25 | 12810 | 0.101 | 0.102 | 0.99 |
| 1.25-2 | 7267 | 0.142 | 0.086 | 1.65 |
| >2 | 3793 | 0.241 | 0.054 | 4.49 |
  win: median per-champion max hp 1580, Strength 54.0, hp fraction 0.87
  lose: median per-champion max hp 1400, Strength 52.5, hp fraction 0.87

Engagements: 29.9 per game; 21% have a kill.
Joiners (participants not within 6 at the first hit): 0.17 per engagement; delay after the first hit: 0 r 2%, 1-2 r 17%, 3-5 r 32%, 6-10 r 31%, >10 r 18%
Side-fights with an ally 7-15 tiles from the centre at the first hit that never joins: 62%; of side-fights where that side lost a champion: 55%
  win: initiates 53%, mean adv at first hit -0.088, kills/fight 0.168, outnumbered (adv<0) 29%
  lose: initiates 47%, mean adv at first hit +0.088, kills/fight 0.066, outnumbered (adv<0) 23%

### R1. Retreats after taking champion damage (recall within 3 rounds, or 2+ tiles toward spawn in 3 rounds without dealing damage); outcome within 25 rounds

| retreats | per team-game | died | reached spawn/recalled | re-engaged | other | died (win) | died (lose) |
|---|---|---|---|---|---|---|---|
| all | 22.1 | 3% | 50% | 30% | 16% | 2% | 5% |
| recall | 6.1 | 2% | 85% | 10% | 3% | 1% | 2% |
| walk home | 15.9 | 4% | 37% | 37% | 22% | 3% | 5% |
| hp<30% | 4.7 | 7% | 80% | 10% | 3% | 6% | 8% |
| hp>=30% | 17.4 | 3% | 42% | 35% | 20% | 2% | 3% |
| ally nearer than spawn | 20.5 | 3% | 49% | 30% | 17% | 2% | 5% |
| spawn nearer than any ally | 1.6 | 4% | 60% | 23% | 14% | 4% | 3% |
| bag>=30 | 2.3 | 4% | 52% | 29% | 15% | 3% | 5% |
| in own half | 8.0 | 3% | 60% | 23% | 14% | 2% | 3% |
| mid/enemy half | 14.1 | 4% | 45% | 34% | 18% | 3% | 5% |
Share of champion-kill deaths whose victim was retreating or recalling between first hit and death: 38%

Deaths within 20 rounds of leaving spawn: 11% (after respawn 93, after recall 149, other 202); within 40: 31%
Deaths walking (no camp/hold/tribute) in mid/enemy half with no ally within 6: 15%; any activity alone in mid/enemy half: 28%
  win: within 20 of spawn 7%; alone in mid/enemy 35%
  lose: within 20 of spawn 12%; alone in mid/enemy 26%

### S1. Snowball: side-fights by recent deaths (within 60 rounds before the first hit)

| state | side-fights | mean adv | kills | deaths | K/D | outnumbered |
|---|---|---|---|---|---|---|
| no recent deaths | 21078 | +0.00 | 0.107 | 0.107 | 1.00 | 25% |
| own champion died <=60 r before | 5880 | -0.10 | 0.095 | 0.161 | 0.59 | 31% |
| enemy champion died <=60 r before | 5880 | +0.10 | 0.161 | 0.095 | 1.69 | 24% |
| both | 1930 | +0.00 | 0.162 | 0.162 | 1.00 | 27% |

After a death, the same team loses another champion within 60 rounds 36% of the time (base rate of >=1 death in a random 60-round window ~21%).
