import re,sys,glob
from collections import defaultdict
for f in sorted(glob.glob(sys.argv[1]+'/games/*[0-9].txt')):
    L=open(f).read().splitlines()
    print('=====',f.split('__')[1], L[0][:120])
    for l in L:
        if 'STATE' in l and re.match(r'r(2|4|6|8)00 ',l): print('  ',l[:230])
    for team in ('[astraeus]','[astraeus-ef8f0b8]'):
        d=defaultdict(list)
        for l in L:
            if not re.match(r'^r\d+ +'+re.escape(team),l): continue
            m=re.search(r'DIED r(\d+) (killed by [^,]+|by camp [^,]+)[^,]*, bag (\d+)',l)
            if m: d['died'].append(f"r{m.group(1)} bag{m.group(3)} {'camp' if 'camp' in m.group(2) else ''}")
            for m in re.finditer(r'TRIBUTE \S+ r(\d+)-\d+ bag (\d+)',l): d['trib'].append(int(m.group(2)))
            for m in re.finditer(r'RECALL r(\d+)-\d+ from \S+ bag (\d+) hp (\d+)%',l): d['recall'].append(f"{m.group(3)}%/{m.group(2)}g")
            for m in re.finditer(r'IDLE (\d+) rounds',l): d['idle'].append(int(m.group(1)))
            if 'turned back' in l: d['turnback'].append(1)
            if 'indirect' in l: d['indirect'].append(1)
            for m in re.finditer(r'took (\d+) champion damage while channelling',l): d['trib_hit'].append(int(m.group(1)))
        print('  ',team,'deaths',len(d['died']),d['died'][:12])
        print('      tributes',len(d['trib']),'bags',d['trib'][:40])
        print('      recalls',len(d['recall']),d['recall'][:30])
        print('      idle legs',len(d['idle']),'rounds',sum(d['idle']),' turned-back legs',len(d['turnback']),' indirect legs',len(d['indirect']))
