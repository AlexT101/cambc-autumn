#!/usr/bin/env python3
"""Champion deaths, engagements, retreats and snowballing over an extracted batch (macro context of kills).

  python3 -I deaths_study.py ANALYSIS_DIR [--out deaths.jsonl.gz] [--threads 32]     # extract + report
  python3 -I deaths_study.py --report deaths.jsonl.gz [--by result|team]            # report only

Engagements are tools/replay/analysis/fights.py clusters (hits sharing a champion within 3 rounds and 16 tiles, or
within 1 round and 8 tiles). Distances are Chebyshev unless noted; positions are start-of-round states.
"""
import argparse
import gzip
import json
import os
import sys
from collections import Counter, defaultdict
from multiprocessing import Pool
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/home/ubuntu/cambc-autumn')
sys.path.insert(0, str(REPO / 'tools' / 'replay'))
sys.path.insert(0, str(HERE))

INF = 1 << 30


def cheb(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def setup(adir):
    import analysis.data as D
    D.ANALYSIS = Path(adir).resolve()
    D._maps.clear()


def clamp(x, lo=-2, hi=2):
    return max(lo, min(hi, x))


def process(args):
    adir, d, teams = args
    try:
        return _process(adir, d, teams)
    except Exception as ex:
        import traceback
        return {'dir': d, 'error': repr(ex) + traceback.format_exc()[-800:]}


def _process(adir, d, teams):
    setup(adir)
    import analysis.data as D
    from analysis.fights import _cluster, _split
    from analysis import params
    import macro_study as MS
    g = D.Game(d)
    with open(os.path.join(adir, 'maps', f"{g.meta['map']['hash']}.json")) as f:
        geo = MS.MapGeo(json.load(f))
    N = len(g.rounds['round'])
    ids = [c['id'] for c in g.champs]
    team_of = g.team_of
    CH = {c: g.ch(c) for c in ids}
    winner = g.winner

    def P(c, r):
        """Position at the start of round r (end of r-1); None if dead."""
        i = max(0, r - 2) if r > 1 else 0
        a = CH[c]
        if i >= N or not a['alive'][i]:
            return None
        return (a['x'][i], a['y'][i])

    def Pend(c, r):
        i = min(N - 1, r - 1)
        a = CH[c]
        return (a['x'][i], a['y'][i]) if a['alive'][i] else None

    def hpf(c, r):
        i = max(0, r - 2)
        a = CH[c]
        return a['hp'][i] / a['maxHp'][i] if a['maxHp'][i] else None

    def dspawn(t, p):
        return geo.dspawn[t][geo.idx(p)] if p else INF

    def zone(t, p):
        if p is None:
            return '?'
        a, b = dspawn(t, p), dspawn(1 - t, p)
        if a >= INF or b >= INF:  # spawn cut off by holes (dash-only): fall back to Chebyshev
            a, b = (min(cheb(p, q) for q in geo.spawn_tiles[x]) for x in (t, 1 - t))
        x = a / max(1, a + b)
        return 'own' if x < 0.45 else 'enemy' if x > 0.55 else 'mid'

    # ---- per-round labels (light version of macro_study's)
    by_round = defaultdict(list)
    for e in g.events:
        by_round[e['r']].append(e)
    camp_hit, trib, shop = set(), set(), set()
    champ_hit = defaultdict(set)   # c -> rounds it dealt or took enemy champion damage
    took = defaultdict(set)        # c -> rounds it took enemy champion damage
    dealt = defaultdict(set)
    inst = []
    for s, r, a, v, amt, ap, vp in g.champ_damage:
        champ_hit[a].add(r)
        champ_hit[v].add(r)
        took[v].add(r)
        dealt[a].add(r)
        i = g.start_idx(r)
        inst.append((s, r, a, v, amt, ap or g.pos(a, i), vp or g.pos(v, i)))
    for e in g.events:
        k = e['k']
        if k in ('attack', 'cast') and e.get('cdmg'):
            camp_hit.add((e['a'], e['r']))
        elif k in ('tribute_start', 'tribute_end'):
            trib.add((e['a'], e['r']))
    recalls, open_ = [], {}
    for e in g.events:
        if e['k'] == 'recall_start':
            open_[e['a']] = e
        elif e['k'] in ('recall_end', 'recall_cancel') and e['a'] in open_:
            st = open_.pop(e['a'])
            if e['k'] == 'recall_cancel' and e['r'] - st['r'] <= 1:
                continue
            recalls.append((e['a'], st['r'], e['r'], e['k'] == 'recall_end'))
    rec_round = {(c, r) for c, r0, r1, _ in recalls for r in range(r0, r1 + 1)}
    rec_start = defaultdict(list)
    rec_done_r = defaultdict(set)
    for c, r0, r1, done in recalls:
        rec_start[c].append(r0)
        if done:
            rec_done_r[c].add(r1)

    gst = {}
    rows = defaultdict(list)
    for row in g.rounds['groups']:
        rows[row[1]].append(row)
    for gid, rs in rows.items():
        arr = [None] * (N + 2)
        j, cur = 0, None
        for r in range(1, N + 1):
            while j < len(rs) and rs[j][0] <= r:
                cur = rs[j]
                j += 1
            arr[r] = cur
        gst[gid] = arr

    lab = {}
    for c in ids:
        t = team_of[c]
        L = [None] * (N + 2)
        a = CH[c]
        for r in range(1, N + 1):
            i = r - 1
            ae = a['alive'][i]
            as_ = a['alive'][i - 1] if i else 1
            p1 = (a['x'][i], a['y'][i]) if ae else None
            p0 = P(c, r)
            gems0 = a['gems'][i - 1] if i else 0
            if not (ae and as_):
                L[r] = 'dead'
            elif (c, r) in rec_round:
                L[r] = 'recall'
            elif (c, r) in trib or a['chan'][i] == 2:
                L[r] = 'tribute'
            elif r in champ_hit[c]:
                L[r] = 'fight'
            elif (c, r) in camp_hit:
                L[r] = 'camp'
            elif p1 in geo.tile_group and (gst.get(geo.tile_group[p1]) or [None] * (N + 2))[r] and gst[geo.tile_group[p1]][r][2] == 2:
                L[r] = 'hold'
            elif p1 in geo.spawn_set[t]:
                L[r] = 'spawn'
            elif p0 != p1:
                L[r] = 'walk_bag' if gems0 >= 10 else 'walk'
            else:
                L[r] = 'idle'
        lab[c] = L

    def activity(c, r):
        """Dominant activity in rounds r-10..r-1."""
        t = team_of[c]
        win = [lab[c][x] for x in range(max(1, r - 10), r)]
        cnt = Counter(win)
        for k in ('tribute', 'recall', 'hold', 'camp'):
            if cnt[k] >= 2:
                return {'hold': 'holding', 'camp': 'farming camp', 'tribute': 'tributing', 'recall': 'recalling'}[k]
        if cnt['fight'] >= 3:
            return 'already fighting'
        if cnt['spawn'] + cnt['dead'] >= 3 and cnt['walk'] + cnt['walk_bag'] < 5:
            return 'just left spawn'
        walkish = cnt['walk'] + cnt['walk_bag'] + cnt['idle']
        if walkish >= 5:
            p0, p1 = P(c, max(1, r - 10)), P(c, r)
            dd = (dspawn(t, p1) - dspawn(t, p0)) if p0 and p1 else 0
            base = 'walking w/ bag' if cnt['walk_bag'] >= cnt['walk'] else 'walking' if cnt['walk'] >= cnt['idle'] else 'idle'
            if base == 'idle':
                return 'idle'
            return base + (' home' if dd <= -3 else ' out' if dd >= 3 else ' across')
        return 'mixed'

    # ---- engagements (fights.py clustering, keeping the hit lists)
    P_ = params.DEFAULTS
    clusters = []
    for its in _cluster(inst, P_['radius'], P_['gap']):
        clusters += _split(its, P_['max_dur'])
    step_cl = {}
    for k, its in enumerate(clusters):
        its.sort()
        for it in its:
            step_cl[it[0]] = k
    deaths = [e for e in g.deaths]
    death_cl = {}
    for e in deaths:
        if e.get('by') in team_of and e['s'] in step_cl:
            death_cl[e['s']] = step_cl[e['s']]
    eng = []
    for k, its in enumerate(clusters):
        r0, r1 = its[0][1], its[-1][1]
        pts0 = [p for s, r, a, v, amt, ap, vp in its if r == r0 for p in (ap, vp) if p]
        if not pts0:
            continue
        cen = (round(sum(p[0] for p in pts0) / len(pts0)), round(sum(p[1] for p in pts0) / len(pts0)))
        first = {}
        part = [set(), set()]
        dmg = [0.0, 0.0]
        for s, r, a, v, amt, ap, vp in its:
            for x in (a, v):
                first.setdefault(x, r)
                part[team_of[x]].add(x)
            dmg[team_of[a]] += amt
        pres6, pres10, near7_15 = [set(), set()], [set(), set()], [set(), set()]
        for c in ids:
            p = P(c, r0)
            if not p:
                continue
            dd = cheb(p, cen)
            t = team_of[c]
            if dd <= 6:
                pres6[t].add(c)
            if dd <= 10:
                pres10[t].add(c)
            if 7 <= dd <= 15 and c not in part[t]:
                near7_15[t].add(c)
        hp6, mhp6, str6 = [0.0, 0.0], [0.0, 0.0], [0.0, 0.0]
        i0 = max(0, r0 - 2)
        for t in (0, 1):
            for c in pres6[t]:
                hp6[t] += CH[c]['hp'][i0]
                mhp6[t] += CH[c]['maxHp'][i0]
                str6[t] += CH[c]['str'][i0] or 0
        kills = [0, 0]
        killed = []
        for e in deaths:
            if death_cl.get(e['s']) == k:
                killed.append(e['v'])
                if 'linked' not in e:
                    kills[team_of[e['by']]] += 1
        joiners = [[(c, first[c] - r0) for c in part[t] if c not in pres6[t]] for t in (0, 1)]
        eng.append({'k': k, 'r0': r0, 'r1': r1, 'cen': cen, 'init': team_of[its[0][2]],
                    'p6': [len(x) for x in pres6], 'p10': [len(x) for x in pres10], 'part': [len(x) for x in part],
                    'join': [[dl for _, dl in j] for j in joiners], 'idle_near': [len(x) for x in near7_15],
                    'kills': kills, 'dmg': [round(x) for x in dmg],
                    'hp6': [round(x) for x in hp6], 'mhp6': [round(x) for x in mhp6], 'str6': [round(x, 1) for x in str6], 'zone': [zone(t, cen) for t in (0, 1)],
                    'ids': [sorted(x) for x in part], 'killed': killed})
    eng_by_k = {e['k']: e for e in eng}

    # ---- deaths by champions
    drecs = []
    last_spawn = {}
    spawn_rounds = {c: [r for r in range(1, N + 1) if lab[c][r] == 'spawn' or (P(c, r) in geo.spawn_set[team_of[c]])] for c in ids}
    for e in deaths:
        v = e['v']
        t = team_of[v]
        if e.get('camp') is not None or e.get('by') not in team_of or e.get('linked') is not None:
            continue
        rd = e['r']
        k = death_cl.get(e['s'])
        en = eng_by_k.get(k)
        if en:
            hits_v = [it[1] for it in clusters[k] if it[3] == v]
            r_first = min(hits_v) if hits_v else en['r0']
            allies_hit = any(x in en['ids'][t] for x in en['ids'][t] if x != v and x in {it[2] for it in clusters[k]})
        else:
            r_first, allies_hit = rd, False
        pv = P(v, r_first) or Pend(v, rd)
        a6 = a10 = e6 = e10 = 0
        near_d, near_lab = None, None
        for c in ids:
            if c == v:
                continue
            p = P(c, r_first)
            if not p or not pv:
                continue
            dd = cheb(p, pv)
            if team_of[c] == t:
                a6 += dd <= 6
                a10 += dd <= 10
                if near_d is None or dd < near_d:
                    near_d, near_lab = dd, lab[c][r_first]
            else:
                e6 += dd <= 6
                e10 += dd <= 10
        # behaviour from first hit to death: moves relative to the nearest enemy
        away = toward = 0
        for r in range(r_first, rd + 1):
            p0, p1 = P(v, r), Pend(v, r)
            if not p0 or not p1 or p0 == p1:
                continue
            ens = [P(c, r) for c in ids if team_of[c] != t and P(c, r)]
            if not ens:
                continue
            d0 = min(cheb(p0, q) for q in ens)
            d1 = min(cheb(p1, q) for q in ens)
            away += d1 > d0
            toward += d1 < d0
        beh = 'retreating' if away > toward and away >= 1 else 'chasing' if toward > away and toward >= 1 else 'standing'
        if any(r0 <= rd <= r1 + 1 for c, r0, r1, _ in recalls if c == v) or any((v, r) in rec_round for r in range(r_first, rd + 1)):
            beh = 'recalling'
        sp = [r for r in spawn_rounds[v] if r < r_first]
        since_spawn = r_first - sp[-1] if sp else r_first
        came_from = None
        if sp:
            ls = sp[-1]
            came_from = 'respawn' if any(lab[v][x] == 'dead' for x in range(max(1, ls - 3), ls + 1)) else \
                'recall' if any(x in rec_done_r[v] for x in range(max(1, ls - 3), ls + 1)) else 'start/walk'
        drecs.append({'r': rd, 'r_first': r_first, 'team': t, 'type': g.name_of[v], 'bag': e.get('gems', 0),
                      'hp_first': hpf(v, r_first), 'zone': zone(t, pv), 'act': activity(v, r_first), 'beh': beh,
                      'a6': a6, 'a10': a10, 'e6': e6, 'e10': e10, 'near_d': near_d, 'near_lab': near_lab,
                      'ally_hit': allies_hit, 'eng': k is not None, 'since_spawn': since_spawn, 'came_from': came_from,
                      'win': t == winner})

    # ---- retreats: took enemy champion damage, then recalled or walked toward own spawn without dealing damage
    rets = []
    for c in ids:
        t = team_of[c]
        busy_until = 0
        deaths_c = sorted(e['r'] for e in deaths if e['v'] == c)
        for r in sorted(took[c]):
            if r < busy_until:
                continue
            mode = None
            for q in range(r, min(N, r + 3) + 1):
                if q in rec_start[c]:
                    mode, rs = 'recall', q
                    break
            if mode is None:
                p0, p3 = Pend(c, r), Pend(c, min(N, r + 3))
                if p0 and p3 and dspawn(t, p3) <= dspawn(t, p0) - 2 and not any(x in dealt[c] for x in range(r + 1, r + 4)):
                    mode, rs = 'walk', r + 1
            if mode is None:
                continue
            p = Pend(c, r)
            if p is None:
                continue
            f = geo.from_pt(p)
            dsp = dspawn(t, p)
            ally_d = min((f[geo.idx(P(o, r + 1))] for o in ids if o != c and team_of[o] == t and P(o, r + 1)), default=INF)
            # outcome within 25 rounds
            out = 'timeout'
            end = min(N, rs + 25)
            for q in range(rs, end + 1):
                if q in deaths_c:
                    out = 'died'
                    break
                pq = Pend(c, q)
                if pq in geo.spawn_set[t] or q in rec_done_r[c]:
                    out = 'safe'
                    break
                if q > rs + 1 and q in dealt[c]:
                    out = 're-engaged'
                    break
            busy_until = q + 1
            rets.append({'team': t, 'mode': mode, 'hp': hpf(c, r + 1), 'bag': CH[c]['gems'][r - 1],
                         'dspawn': dsp if dsp < INF else None, 'ally_d': ally_d if ally_d < INF else None,
                         'ally_nearer': ally_d < dsp, 'out': out, 'win': t == winner, 'zone': zone(t, p)})

    # ---- snowball: fights within 60 rounds after a team's champion death vs the rest
    snow = []
    tdeaths = defaultdict(list)
    for e in deaths:
        if e.get('linked') is None:
            tdeaths[team_of[e['v']]].append(e['r'])
    for en in eng:
        for t in (0, 1):
            recent_own = any(0 < en['r0'] - x <= 60 for x in tdeaths[t])
            recent_enemy = any(0 < en['r0'] - x <= 60 for x in tdeaths[1 - t])
            snow.append({'team': t, 'own_dead_recent': recent_own, 'enemy_dead_recent': recent_enemy,
                         'kills': en['kills'][t], 'deaths': en['kills'][1 - t], 'adv': en['p6'][t] - en['p6'][1 - t],
                         'win': t == winner})
    # next death of the same team after a death
    nxt = []
    for t in (0, 1):
        xs = sorted(tdeaths[t])
        for i, x in enumerate(xs):
            nxt.append({'team': t, 'gap': xs[i + 1] - x if i + 1 < len(xs) else None, 'left': N - x, 'win': t == winner})

    return {'dir': d, 'map': g.map_name, 'N': N, 'winner': winner, 'teams': teams, 'deaths': drecs,
            'eng': [{k: v for k, v in en.items() if k not in ('ids', 'killed', 'k')} for en in eng],
            'rets': rets, 'snow': snow, 'next': nxt,
            'dead_rounds': [sum(1 for c in ids if team_of[c] == t for r in range(1, N + 1) if lab[c][r] == 'dead') for t in (0, 1)],
            'champ_rounds': [N * sum(1 for c in ids if team_of[c] == t) for t in (0, 1)]}


# ---------------------------------------------------------------- report

def pct(a, b):
    return f'{100 * a / b:.0f}%' if b else '-'


def table(title, header, rows):
    print(f'\n### {title}\n')
    print('| ' + ' | '.join(header) + ' |')
    print('|' + '---|' * len(header))
    for r in rows:
        print('| ' + ' | '.join(str(x) for x in r) + ' |')


def report(games, by):
    def side(rec_win, team, g):
        return ('win' if rec_win else 'lose') if by == 'result' else g['teams'][team]
    D = [(side(x['win'], x['team'], g), x) for g in games for x in g['deaths']]
    sides = sorted({s for s, _ in D}, key=lambda s: (s != 'win', s))
    ng = len(games)
    print(f'# Deaths and engagements: {ng} games, {len(D)} champion-kill deaths')
    rows = []
    for s in sides + ['all']:
        xs = [x for sd, x in D if s == 'all' or sd == s]
        rows.append([s, f'{len(xs) / ng:.2f}', f"{sum(x['bag'] for x in xs) / ng:.1f}", f"{sum(1 for x in xs if x['bag'] >= 30) / ng:.2f}",
                     pct(sum(1 for x in xs if x['a6'] == 0), len(xs)), pct(sum(1 for x in xs if x['e6'] > x['a6'] + 1), len(xs)),
                     pct(sum(1 for x in xs if not x['ally_hit']), len(xs)),
                     f"{sorted(x['near_d'] for x in xs if x['near_d'] is not None)[len(xs) // 2] if xs else '-'}"])
    table('D1. Champion-kill deaths per team-game', ['side', 'deaths', 'gems lost', 'deaths with bag>=30', 'no ally within 6',
                                                     'outnumbered by 2+ (within 6)', 'no ally hit an enemy', 'median nearest-ally dist'], rows)
    for key, title in (('act', 'victim activity, 10 rounds before its first hit'), ('beh', 'victim behaviour from first hit to death'),
                       ('zone', 'zone of the first hit (victim frame)'), ('near_lab', "nearest ally's label at the first hit")):
        ks = Counter(x[key] for _, x in D)
        rows = []
        for k, n in ks.most_common(12):
            rows.append([k, n, pct(n, len(D))] + [pct(sum(1 for sd, x in D if sd == s and x[key] == k), sum(1 for sd, _ in D if sd == s)) for s in sides])
        table(f'D2. Deaths by {title}', [key, 'n', 'all'] + sides, rows)
    hb = Counter()
    for _, x in D:
        h = x['hp_first']
        hb['?' if h is None else '<25%' if h < .25 else '<50%' if h < .5 else '<75%' if h < .75 else '<100%' if h < .999 else 'full'] += 1
    table('D3. Victim hp at its first enemy hit of the engagement', ['hp', 'n', '%'], [[k, v, pct(v, len(D))] for k, v in sorted(hb.items())])
    for rad in ('6', '10'):
        c = Counter((1 + min(x['a' + rad], 3), min(x['e' + rad], 4)) for _, x in D)
        rows = [[f'{a}v{e}' + ('+' if a == 4 or e == 4 else ''), n, pct(n, len(D))] for (a, e), n in sorted(c.items(), key=lambda kv: -kv[1])[:12]]
        table(f'D4. Deaths by local numbers at the first hit (victim side incl. victim v enemies, within {rad})', ['numbers', 'n', '%'], rows)
    # engagements
    E = [(t, en, g) for g in games for en in g['eng'] for t in (0, 1)]
    rows = []
    for adv in (-2, -1, 0, 1, 2):
        xs = [(t, en) for t, en, g in E if clamp(en['p6'][t] - en['p6'][1 - t]) == adv]
        k = sum(en['kills'][t] for t, en in xs)
        dth = sum(en['kills'][1 - t] for t, en in xs)
        dm = sum(en['dmg'][t] for t, en in xs)
        dt = sum(en['dmg'][1 - t] for t, en in xs)
        won = sum(1 for t, en in xs if en['kills'][t] > en['kills'][1 - t])
        lost = sum(1 for t, en in xs if en['kills'][t] < en['kills'][1 - t])
        rows.append([f'{adv:+d}', len(xs) // 1, f'{k / max(1, len(xs)):.3f}', f'{dth / max(1, len(xs)):.3f}', f'{k / max(1, dth):.2f}',
                     f'{dm / max(1, dt):.2f}', pct(won, len(xs)), pct(lost, len(xs))])
    table('E1. Engagements by numbers advantage at the first hit (own minus enemy champions within 6 of the centre), per side',
          ['adv', 'side-fights', 'kills', 'deaths', 'K/D', 'dmg dealt/taken', 'won on kills', 'lost on kills'], rows)
    for key, title in (('hp6', 'current hp'), ('str6', 'effective Strength'), ('mhp6', 'max hp (items)')):
        rows = []
        for lo, hi, name in ((0, .5, '<0.5'), (.5, .8, '0.5-0.8'), (.8, 1.25, '0.8-1.25'), (1.25, 2, '1.25-2'), (2, 1e9, '>2')):
            xs = [(t, en) for t, en, g in E if en[key][1 - t] > 0 and en[key][t] > 0 and lo <= en[key][t] / en[key][1 - t] < hi]
            k = sum(en['kills'][t] for t, en in xs)
            dth = sum(en['kills'][1 - t] for t, en in xs)
            rows.append([name, len(xs), f'{k / max(1, len(xs)):.3f}', f'{dth / max(1, len(xs)):.3f}', f'{k / max(1, dth):.2f}'])
        table(f'E2. Side-fights by own/enemy {title} within 6 at the first hit (both sides present)', ['ratio', 'side-fights', 'kills', 'deaths', 'K/D'], rows)
    for s in sides:
        xs = [(t, en) for t, en, g in E if side(t == g['winner'], t, g) == s and en['p6'][t] and en['p6'][1 - t]]
        import statistics as st
        print(f"  {s}: median per-champion max hp {st.median(en['mhp6'][t] / en['p6'][t] for t, en in xs):.0f}, Strength {st.median(en['str6'][t] / en['p6'][t] for t, en in xs):.1f}, "
              f"hp fraction {st.median(en['hp6'][t] / max(1, en['mhp6'][t]) for t, en in xs):.2f}")
    nE = len(E) // 2
    nfights = sum(len(g['eng']) for g in games)
    join = [dl for t, en, g in E for dl in en['join'][t]]
    sides_with_idle = sum(1 for t, en, g in E if en['idle_near'][t] > 0)
    sides_with_idle_kill = sum(1 for t, en, g in E if en['idle_near'][t] > 0 and en['kills'][1 - t] > 0)
    deadly = sum(1 for t, en, g in E if en['kills'][1 - t] > 0)
    jb = Counter('0' if x == 0 else '1-2' if x <= 2 else '3-5' if x <= 5 else '6-10' if x <= 10 else '>10' for x in join)
    print(f"\nEngagements: {nfights / ng:.1f} per game; {sum(1 for t, en, g in E if en['kills'][0] + en['kills'][1] > 0) / 2 / nfights * 100:.0f}% have a kill.")
    print(f"Joiners (participants not within 6 at the first hit): {len(join) / nfights:.2f} per engagement; delay after the first hit: "
          + ', '.join(f'{k} r {pct(v, len(join))}' for k, v in sorted(jb.items(), key=lambda kv: ['0', '1-2', '3-5', '6-10', '>10'].index(kv[0]))))
    print(f"Side-fights with an ally 7-15 tiles from the centre at the first hit that never joins: {pct(sides_with_idle, len(E))}; "
          f"of side-fights where that side lost a champion: {pct(sides_with_idle_kill, deadly)}")
    for s in sides:
        xs = [(t, en) for t, en, g in E if side(t == g['winner'], t, g) == s]
        print(f"  {s}: initiates {pct(sum(1 for t, en in xs if en['init'] == t), len(xs))}, mean adv at first hit {sum(en['p6'][t] - en['p6'][1 - t] for t, en in xs) / len(xs):+.3f}, "
              f"kills/fight {sum(en['kills'][t] for t, en in xs) / len(xs):.3f}, outnumbered (adv<0) {pct(sum(1 for t, en in xs if en['p6'][t] < en['p6'][1 - t]), len(xs))}")
    # retreats
    R = [(side(x['win'], x['team'], g), x) for g in games for x in g['rets']]
    rows = []
    for name, pred in (('all', lambda x: True), ('recall', lambda x: x['mode'] == 'recall'), ('walk home', lambda x: x['mode'] == 'walk'),
                       ('hp<30%', lambda x: (x['hp'] or 1) < .3), ('hp>=30%', lambda x: (x['hp'] or 1) >= .3),
                       ('ally nearer than spawn', lambda x: x['ally_nearer']), ('spawn nearer than any ally', lambda x: not x['ally_nearer']),
                       ('bag>=30', lambda x: x['bag'] >= 30), ('in own half', lambda x: x['zone'] == 'own'), ('mid/enemy half', lambda x: x['zone'] in ('mid', 'enemy'))):
        xs = [x for _, x in R if pred(x)]
        o = Counter(x['out'] for x in xs)
        rows.append([name, f'{len(xs) / ng:.1f}', pct(o['died'], len(xs)), pct(o['safe'], len(xs)), pct(o['re-engaged'], len(xs)), pct(o['timeout'], len(xs))]
                    + [pct(sum(1 for sd, x in R if sd == s and pred(x) and x['out'] == 'died'), sum(1 for sd, x in R if sd == s and pred(x))) for s in sides])
    table('R1. Retreats after taking champion damage (recall within 3 rounds, or 2+ tiles toward spawn in 3 rounds without dealing damage); outcome within 25 rounds',
          ['retreats', 'per team-game', 'died', 'reached spawn/recalled', 're-engaged', 'other'] + [f'died ({s})' for s in sides], rows)
    rd = sum(1 for _, x in D if x['beh'] in ('retreating', 'recalling'))
    print(f"Share of champion-kill deaths whose victim was retreating or recalling between first hit and death: {pct(rd, len(D))}")
    # Q4
    w20 = [x for _, x in D if x['since_spawn'] <= 20]
    cf = Counter(x['came_from'] for x in w20)
    alone_out = [x for _, x in D if x['zone'] in ('mid', 'enemy') and x['a6'] == 0 and x['act'].startswith(('walking', 'just left'))]
    alone_any = [x for _, x in D if x['zone'] in ('mid', 'enemy') and x['a6'] == 0]
    print(f"\nDeaths within 20 rounds of leaving spawn: {pct(len(w20), len(D))} (after respawn {cf['respawn']}, after recall {cf['recall']}, other {cf['start/walk'] + cf[None]});"
          f" within 40: {pct(sum(1 for _, x in D if x['since_spawn'] <= 40), len(D))}")
    print(f"Deaths walking (no camp/hold/tribute) in mid/enemy half with no ally within 6: {pct(len(alone_out), len(D))}; any activity alone in mid/enemy half: {pct(len(alone_any), len(D))}")
    for s in sides:
        xs = [x for sd, x in D if sd == s]
        print(f"  {s}: within 20 of spawn {pct(sum(1 for x in xs if x['since_spawn'] <= 20), len(xs))}; alone in mid/enemy {pct(sum(1 for x in xs if x['zone'] in ('mid', 'enemy') and x['a6'] == 0), len(xs))}")
    # Q5 snowball
    S = [x for g in games for x in g['snow']]
    rows = []
    for name, pred in (('no recent deaths', lambda x: not x['own_dead_recent'] and not x['enemy_dead_recent']),
                       ('own champion died <=60 r before', lambda x: x['own_dead_recent'] and not x['enemy_dead_recent']),
                       ('enemy champion died <=60 r before', lambda x: x['enemy_dead_recent'] and not x['own_dead_recent']),
                       ('both', lambda x: x['own_dead_recent'] and x['enemy_dead_recent'])):
        xs = [x for x in S if pred(x)]
        k = sum(x['kills'] for x in xs)
        dth = sum(x['deaths'] for x in xs)
        rows.append([name, len(xs), f'{sum(x["adv"] for x in xs) / max(1, len(xs)):+.2f}', f'{k / max(1, len(xs)):.3f}', f'{dth / max(1, len(xs)):.3f}', f'{k / max(1, dth):.2f}',
                     pct(sum(1 for x in xs if x['adv'] < 0), len(xs))])
    table('S1. Snowball: side-fights by recent deaths (within 60 rounds before the first hit)',
          ['state', 'side-fights', 'mean adv', 'kills', 'deaths', 'K/D', 'outnumbered'], rows)
    Nx = [x for g in games for x in g['next']]
    within = sum(1 for x in Nx if x['gap'] is not None and x['gap'] <= 60)
    elig = sum(1 for x in Nx if x['left'] > 60)
    tot_d = sum(len(g['next']) for g in games)
    tot_r = sum(g['N'] for g in games) * 2
    base = 1 - (1 - tot_d / tot_r) ** 60
    print(f"\nAfter a death, the same team loses another champion within 60 rounds {pct(within, elig)} of the time "
          f"(base rate of >=1 death in a random 60-round window ~{100 * base:.0f}%).")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('analysis', nargs='?')
    ap.add_argument('--out')
    ap.add_argument('--report')
    ap.add_argument('--threads', type=int, default=32)
    ap.add_argument('--by', default='result', choices=['result', 'team'])
    ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()
    path = a.report
    if not path:
        adir = os.path.abspath(a.analysis)
        idx = json.load(open(os.path.join(adir, 'index.json')))['games']
        seen = {}
        for row in idx:
            if row['ok'] and row['dir'] not in seen:
                seen[row['dir']] = row['teams']
        jobs = [(adir, d, t) for d, t in seen.items()][:a.limit or None]
        path = a.out or os.path.join(adir, 'deaths.jsonl.gz')
        err = 0
        with gzip.open(path, 'wt') as f, Pool(a.threads) as pool:
            for res in pool.imap_unordered(process, jobs, chunksize=1):
                if 'error' in res:
                    err += 1
                    print('ERR', res['dir'], res['error'], file=sys.stderr)
                    continue
                f.write(json.dumps(res) + '\n')
        print(f'wrote {path}, {err} errors', file=sys.stderr)
    games = [json.loads(l) for l in gzip.open(path, 'rt')]
    report(games, a.by)


if __name__ == '__main__':
    main()
