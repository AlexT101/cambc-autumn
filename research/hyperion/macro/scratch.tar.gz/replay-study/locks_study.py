"""Altar-lock denial per team: share of rounds with all / any altars enemy-locked, lock placements, blocked tributes.
usage: python3 -I locks_study.py ANALYSIS_DIR"""
import json, gzip, sys, statistics
from collections import Counter, defaultdict
from multiprocessing import Pool
A = sys.argv[1] if len(sys.argv) > 1 else 'analysis'

def f(d):
    m = json.load(open(f'{A}/{d}/meta.json'))
    mp = json.load(open(f"{A}/maps/{m['map']['hash']}.json"))
    R = json.load(gzip.open(f'{A}/{d}/rounds.json.gz'))
    w = m['result']['winner']
    nalt = len(mp['altars'])
    N = len(R['round'])
    out = {'w': w, 'nalt': nalt, 'N': N}
    for t in (0, 1):
        allr = anyr = 0
        first_all = None
        for i, L in enumerate(R['locks']):
            k = len({(x, y) for tm, x, y, h in L if tm == 1 - t})
            if k >= nalt:
                allr += 1
                if first_all is None: first_all = i + 1
            if k: anyr += 1
        out[t] = {'all': allr / N, 'any': anyr / N, 'first_all': first_all}
    team_of = {c['id']: c['team'] for c in m['champions']}
    c = Counter()
    for l in gzip.open(f'{A}/{d}/events.jsonl.gz', 'rt'):
        e = json.loads(l)
        if e['k'] == 'lock_place': c[(team_of[e['a']], 'place')] += 1
        elif e['k'] == 'tribute_blocked': c[(team_of[e['a']], 'blocked')] += 1
        elif e['k'] == 'tribute_cancel' and e.get('cause') == 'lock': c[(team_of[e['a']], 'cancel_lock')] += 1; c[(team_of[e['a']], 'cancel_lock_gems')] += e.get('gems', 0)
        elif e['k'] == 'attack' and e.get('lock'): c[(team_of[e['a']], 'lock_hits')] += 1
    for t in (0, 1):
        for k in ('place', 'blocked', 'cancel_lock', 'cancel_lock_gems', 'lock_hits'):
            out[t][k] = c[(t, k)]
    return out

if __name__ == '__main__':
    idx = json.load(open(f'{A}/index.json'))['games']
    dirs = sorted({r['dir'] for r in idx})
    with Pool(32) as p:
        res = p.map(f, dirs)
    for lab, pick in (('winner', lambda r: r['w']), ('loser', lambda r: 1 - r['w'])):
        rows = [r[pick(r)] for r in res]
        n = len(rows)
        print(f"{lab}: all altars enemy-locked {100*statistics.mean(x['all'] for x in rows):.1f}% of rounds, any {100*statistics.mean(x['any'] for x in rows):.1f}%;"
              f" games with all altars locked >=25% of game {sum(1 for x in rows if x['all']>=.25)}/{n};"
              f" locks placed/game {statistics.mean(x['place'] for x in rows):.2f}; lock hits {statistics.mean(x['lock_hits'] for x in rows):.2f};"
              f" tributes blocked {statistics.mean(x['blocked'] for x in rows):.2f}; cancelled by lock {statistics.mean(x['cancel_lock'] for x in rows):.2f} ({statistics.mean(x['cancel_lock_gems'] for x in rows):.1f} gems)")
    for na in sorted({r['nalt'] for r in res}):
        sub = [r for r in res if r['nalt'] == na]
        print(f"  maps with {na} altars ({len(sub)} games): winner all-locked {100*statistics.mean(r[r['w']]['all'] for r in sub):.1f}%, loser {100*statistics.mean(r[1-r['w']]['all'] for r in sub):.1f}%;"
              f" loser locked-out more in {sum(1 for r in sub if r[1-r['w']]['all']>r[r['w']]['all']+.05)}, winner more in {sum(1 for r in sub if r[r['w']]['all']>r[1-r['w']]['all']+.05)}")
