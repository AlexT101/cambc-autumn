#!/usr/bin/env python3
"""Macro metrics (time budget, camp utilisation, walking, banking, clears, score) over an extracted batch.

  python3 macro_study.py extract ANALYSIS_DIR [--out features.jsonl.gz] [--threads 32] [--limit N]
  python3 macro_study.py report features.jsonl.gz [--by result|team] [--min-gap 0]

ANALYSIS_DIR is an `extract.mjs --out` dir (index.json, maps/, <dir>/...). Each distinct game is processed once.
--by result splits winner/loser (mirror batches); --by team splits by the index's team names (A/B of two bots).
"""
import argparse
import gzip
import json
import math
import os
import statistics
import sys
from collections import Counter, defaultdict, deque
from multiprocessing import Pool

INF = 1 << 30
CAMP = {'Wolf': (4, 40, 40), 'Elk': (15, 90, 60), 'Golem': (36, 160, 80), 'Gem cluster': (7, 0, 50),
        'Gold cluster': (0, 20, 50), 'Monolith': (200, 300, 150)}  # gems, gold, respawn (rules)
N8 = ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1))
PRIMARY = ['Monolith', 'Golem', 'Elk', 'Wolf', 'Gem cluster', 'Gold cluster']
LABELS = ['dead', 'recall', 'tribute', 'teleport', 'fight', 'camp', 'hold', 'spawn', 'walk_empty', 'walk_gems', 'idle']
WALKISH = ('walk_empty', 'walk_gems', 'idle')
FIGHT_GAP = 3
NEAR = 3
EARLY = 300

# ---------------------------------------------------------------- map geometry


class MapGeo:
    def __init__(self, m):
        self.m = m
        self.W, self.H = m['width'], m['height']
        W, H = self.W, self.H
        blocked = {tuple(t) for t in m['walls']} | {tuple(t) for t in m['holes']} | {tuple(t) for t in m['altars']}
        self.passable = bytearray(W * H)
        for x in range(W):
            for y in range(H):
                if (x, y) not in blocked:
                    self.passable[y * W + x] = 1
        self.nbr = [None] * (W * H)
        for x in range(W):
            for y in range(H):
                i = y * W + x
                if not self.passable[i]:
                    continue
                self.nbr[i] = [(y + dy) * W + x + dx for dx, dy in N8
                               if 0 <= x + dx < W and 0 <= y + dy < H and self.passable[(y + dy) * W + x + dx]]
        self.spawn_tiles = [[(x, y) for x in range(s['minX'], s['maxX'] + 1) for y in range(s['minY'], s['maxY'] + 1)]
                            for s in m['spawn']]
        self.spawn_set = [set(s) for s in self.spawn_tiles]
        self.dspawn = [self.field(s) for s in self.spawn_tiles]
        self.camp_group = {c['id']: c['group'] for c in m['camps']}
        self.tile_group = {}
        for g in m['groups']:
            for t in g['tiles']:
                self.tile_group[tuple(t)] = g['id']
        self.gfield = {g['id']: self.field([tuple(t) for t in g['tiles']]) for g in m['groups']}
        # The extracted map JSON's group gems/gold/mirror are wrong for ~6% of groups: rebuild them from the camps.
        members = defaultdict(list)
        for c in m['camps']:
            members[c['group']].append(c['type'])
        self.groups = []
        self.side_mismatch = 0
        for g in m['groups']:
            g = dict(g)
            ts = members[g['id']] or g['types']
            g['types'] = ts
            g['gems'] = sum(CAMP[t][0] for t in ts)
            g['gold'] = sum(CAMP[t][1] for t in ts)
            g['respawn'] = max(CAMP[t][2] for t in ts)
            t0 = tuple(g['tiles'][0])
            g['mirror'] = self.tile_group.get(self.mirror(t0), g['id'])
            f = self.gfield[g['id']]
            da = min(f[self.idx(p)] for p in self.spawn_tiles[0])
            db = min(f[self.idx(p)] for p in self.spawn_tiles[1])
            side = 0 if da < db else 1 if db < da else -1
            self.side_mismatch += side != g['side']
            g['side'] = side
            self.groups.append(g)
        self.altars = [tuple(a) for a in m['altars']]
        self.afield = {}
        for a in self.altars:
            src = [(a[0] + dx, a[1] + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)
                   if 0 <= a[0] + dx < W and 0 <= a[1] + dy < H and self.passable[(a[1] + dy) * W + a[0] + dx]]
            self.afield[a] = self.field(src)
        self._cache = {}
        hp = {}
        for c in m['camps']:
            hp[c['group']] = hp.get(c['group'], 0) + c['hp']
        self.ghp = hp

    def mirror(self, p):
        x, y = p
        sym = self.m['symmetry']
        if sym == 'horizontal':
            return (self.W - 1 - x, y)
        if sym == 'vertical':
            return (x, self.H - 1 - y)
        return (self.W - 1 - x, self.H - 1 - y)

    def idx(self, p):
        return p[1] * self.W + p[0]

    def field(self, sources):
        d = [INF] * (self.W * self.H)
        q = deque()
        for p in sources:
            i = self.idx(p)
            if 0 <= p[0] < self.W and 0 <= p[1] < self.H and d[i] == INF:
                d[i] = 0
                q.append(i)
        nbr = self.nbr
        while q:
            i = q.popleft()
            ni = nbr[i]
            if ni is None:
                continue
            di = d[i] + 1
            for j in ni:
                if d[j] > di:
                    d[j] = di
                    q.append(j)
        return d

    def from_pt(self, p):
        f = self._cache.get(p)
        if f is None:
            if len(self._cache) > 400:
                self._cache.clear()
            f = self._cache[p] = self.field([p])
        return f

    def gdist(self, g, p):
        return self.gfield[g][self.idx(p)]


def cheb(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def primary_type(types):
    for t in PRIMARY:
        if t in types:
            return t
    return types[0]


def gtype(g):
    p = primary_type(g['types'])
    n = len(g['types'])
    return p if n == 1 else f'{p}+{n - 1}'


def bucket(v, edges):
    for e in edges:
        if v < e:
            return f'<{e}'
    return f'>={edges[-1]}'


# ---------------------------------------------------------------- per game

_maps = {}


def load_geo(adir, h):
    if h not in _maps:
        if len(_maps) > 8:
            _maps.clear()
        with open(os.path.join(adir, 'maps', f'{h}.json')) as f:
            _maps[h] = MapGeo(json.load(f))
    return _maps[h]


def side_rel(side, team):
    return 'mid' if side == -1 else ('own' if side == team else 'enemy')


def process(args):
    adir, d, teams = args
    try:
        return _process(adir, d, teams)
    except Exception as ex:  # keep the batch going; report at the end
        import traceback
        return {'dir': d, 'error': f'{ex!r} {traceback.format_exc()[-600:]}'}


def _process(adir, d, teams):
    base = os.path.join(adir, d)
    with open(os.path.join(base, 'meta.json')) as f:
        meta = json.load(f)
    with gzip.open(os.path.join(base, 'rounds.json.gz')) as f:
        R = json.load(f)
    with gzip.open(os.path.join(base, 'events.jsonl.gz'), 'rt') as f:
        events = [json.loads(l) for l in f if l.strip()]
    G = load_geo(adir, meta['map']['hash'])
    N = len(R['round'])
    rnum = R['round']
    ri = {r: i for i, r in enumerate(rnum)}
    champs = meta['champions']
    ids = [c['id'] for c in champs]
    team_of = {c['id']: c['team'] for c in champs}
    ctype = {c['id']: c['name'] for c in champs}
    CH = {c['id']: R['champions'][i] for i, c in enumerate(champs)}
    winner = meta['result']['winner']

    def at(c, key, r):
        i = ri.get(r)
        if i is None:
            i = 0 if r < rnum[0] else N - 1
        return CH[c][key][i]

    def pos(c, r):
        if r < 1:
            r = 1
        a = CH[c]
        i = ri.get(r, N - 1)
        if not a['alive'][i]:
            return None
        return (a['x'][i], a['y'][i])

    def start_pos(c, r):
        if r <= 1:
            a = CH[c]
            return (a['x'][0], a['y'][0]) if a['alive'][0] else None
        return pos(c, r - 1)

    # group state per round (end of round), forward filled
    gst = {}
    rows = defaultdict(list)
    for row in R['groups']:
        rows[row[1]].append(row)
    for g, rs in rows.items():
        arr = [None] * (N + 2)
        j, cur = 0, None
        for r in range(1, N + 1):
            while j < len(rs) and rs[j][0] <= r:
                cur = rs[j]
                j += 1
            arr[r] = cur
        arr[0] = rs[0]
        arr[N + 1] = arr[N]
        gst[g] = arr
    full_hp = {g: max((x[7] for x in rs if x[2] == 1), default=G.ghp.get(g, 0)) for g, rs in rows.items()}

    def gstate(g, r):
        a = gst.get(g)
        return a[min(max(r, 0), N + 1)] if a else None

    by_round = defaultdict(list)
    for e in events:
        by_round[e['r']].append(e)

    # per (champion, round) flags
    camp_hit = defaultdict(lambda: defaultdict(float))  # (c,r) -> g -> dmg
    champ_hit_rounds = defaultdict(set)
    trib_r, tp_r, shop_r = set(), set(), set()
    dmg_dealt_champ = Counter()
    camp_taken = Counter()  # (c) -> damage from camps
    camp_taken_r = defaultdict(float)  # (c, r)
    for e in events:
        k = e['k']
        r = e['r']
        a = e.get('a')
        if k in ('attack', 'cast'):
            if e.get('cdmg'):
                for camp, amt in e['cdmg']:
                    g = G.camp_group.get(camp)
                    if g is not None:
                        camp_hit[(a, r)][g] += amt
            for v, amt in e.get('dmg') or []:
                if v in team_of and a in team_of and team_of[v] != team_of[a] and amt > 0:
                    champ_hit_rounds[a].add(r)
                    champ_hit_rounds[v].add(r)
                    dmg_dealt_champ[a] += amt
        elif k == 'camp_attack':
            t = e.get('tgt')
            if t is not None:
                camp_taken[t] += e.get('dmg', 0)
                camp_taken_r[(t, r)] += e.get('dmg', 0)
            for x, amt in e.get('xdmg', []) or []:
                camp_taken[x] += amt
                camp_taken_r[(x, r)] += amt
        elif k in ('tribute_start', 'tribute_end'):
            trib_r.add((a, r))
        elif k in ('teleport_start', 'teleport_end'):
            tp_r.add((a, r))
        elif k in ('shop', 'sell'):
            shop_r.add((a, r))

    # real recalls
    recalls = []
    open_ = {}
    for e in events:
        k = e['k']
        if k == 'recall_start':
            open_[e['a']] = e
        elif k in ('recall_end', 'recall_cancel') and e['a'] in open_:
            st = open_.pop(e['a'])
            done = k == 'recall_end'
            if not done and e['r'] - st['r'] <= 1:
                continue
            recalls.append({'c': e['a'], 'r0': st['r'], 'r1': e['r'], 'gems': st['gems'], 'done': done,
                            'cause': None if done else e.get('cause'), 'at': st['at']})
    for c, st in open_.items():
        if N - st['r'] >= 2:
            recalls.append({'c': c, 'r0': st['r'], 'r1': N, 'gems': st['gems'], 'done': False, 'cause': 'end', 'at': st['at']})
    rec_round = {}
    for rc in recalls:
        for r in range(rc['r0'], rc['r1'] + 1):
            rec_round[(rc['c'], r)] = rc

    fight_round = set()
    for c, rs in champ_hit_rounds.items():
        rs = sorted(rs)
        for i, r in enumerate(rs):
            fight_round.add((c, r))
            if i + 1 < len(rs) and rs[i + 1] - r <= FIGHT_GAP:
                for rr in range(r, rs[i + 1]):
                    fight_round.add((c, rr))

    # labels
    lab = {}
    key = {}
    sub = Counter()  # (team, subkind) -> champion-rounds
    for c in ids:
        t = team_of[c]
        L = [None] * (N + 1)
        K = [None] * (N + 1)
        for r in range(1, N + 1):
            i = r - 1
            a = CH[c]
            alive_end = a['alive'][i]
            alive_start = a['alive'][i - 1] if i > 0 else 1
            p1 = (a['x'][i], a['y'][i]) if alive_end else None
            p0 = start_pos(c, r)
            chan = a['chan'][i]
            gems0 = a['gems'][i - 1] if i > 0 else 0
            if not (alive_start and alive_end):
                L[r] = 'dead'
            elif (c, r) in rec_round:
                L[r] = 'recall'
            elif (c, r) in trib_r or chan == 2:
                L[r] = 'tribute'
            elif (c, r) in tp_r or chan == 3:
                L[r] = 'teleport'
            elif (c, r) in fight_round:
                L[r] = 'fight'
                alone = all(not CH[o]['alive'][i] or cheb(p1, (CH[o]['x'][i], CH[o]['y'][i])) > 6
                            for o in ids if o != c and team_of[o] == t)
                if alone:
                    sub[(t, 'fight_alone')] += 1
            elif (c, r) in camp_hit:
                L[r] = 'camp'
                hits = camp_hit[(c, r)]
                K[r] = max(hits, key=hits.get)
            elif p1 in G.tile_group and (gstate(G.tile_group[p1], r) or [0, 0, 0])[2] == 2:
                L[r] = 'hold'
                K[r] = G.tile_group[p1]
            elif p1 in G.spawn_set[t]:
                L[r] = 'spawn'
                if (c, r) in shop_r:
                    sub[(t, 'spawn_shop')] += 1
            elif p0 != p1:
                L[r] = 'walk_gems' if gems0 > 0 else 'walk_empty'
            else:
                L[r] = 'idle'
                # what is it idling next to
                why = 'other'
                gn = G.tile_group.get(p1)
                near = None
                bestd = NEAR + 1
                for g in G.groups:
                    dd = G.gfield[g['id']][G.idx(p1)]
                    if dd < bestd:
                        bestd, near = dd, g['id']
                if near is not None:
                    s = gstate(near, r)
                    why = {1: 'idle_near_up', 2: 'idle_near_cleared', 3: 'idle_near_respawning'}.get(s[2] if s else 0, 'other')
                elif any(G.afield[al][G.idx(p1)] <= 1 for al in G.altars):
                    why = 'idle_at_altar'
                sub[(t, why if why != 'other' else 'idle_other')] += 1
                if gems0 > 0:
                    sub[(t, 'idle_with_gems')] += 1
            if L[r] == 'walk_gems' and gems0 >= 30:
                sub[(t, 'walk_gems30')] += 1
        lab[c] = L
        key[c] = K

    out = {'dir': d, 'map': meta['map']['name'], 'hash': meta['map']['hash'], 'W': G.W, 'H': G.H, 'N': N,
           'winner': winner, 'gems': meta['result']['gems'], 'teams': teams, 'nchamp': len(ids),
           'picks': meta['draft']['picks'], 'nalt': len(G.altars), 'ngroups': len(G.groups)}

    T = [defaultdict(float) for _ in (0, 1)]  # per-team scalars
    H = [defaultdict(lambda: defaultdict(float)) for _ in (0, 1)]  # per-team histograms / tables

    # time budget
    for c in ids:
        t = team_of[c]
        for r in range(1, N + 1):
            l = lab[c][r]
            T[t]['tb_' + l] += 1
            H[t]['tb_type'][ctype[c] + '|' + l] += 1
            if r <= EARLY:
                T[t]['tbE_' + l] += 1
        T[t]['champ_rounds'] += N
        T[t]['champ_roundsE'] += min(N, EARLY)
        H[t]['type_rounds'][ctype[c]] += N
    for (t, s), v in sub.items():
        T[t]['sub_' + s] += v

    # recalls
    for rc in recalls:
        c, t = rc['c'], team_of[rc['c']]
        r0 = rc['r0']
        hpf = at(c, 'hp', r0 - 1) / max(1e-9, at(c, 'maxHp', r0 - 1)) if r0 > 1 else 1.0
        shop_after = any((c, r) in shop_r for r in range(rc['r1'], rc['r1'] + 4)) if rc['done'] else False
        if hpf < 0.6:
            kind = 'heal'
        elif rc['gems'] >= 10:
            kind = 'bank'
        elif shop_after:
            kind = 'shop'
        else:
            kind = 'other'
        T[t]['rec_n'] += 1
        T[t]['rec_' + kind] += 1
        T[t]['recr_' + kind] += rc['r1'] - rc['r0'] + 1
        if not rc['done']:
            T[t]['rec_wasted_rounds'] += rc['r1'] - rc['r0'] + 1
        T[t]['rec_done'] += rc['done']
        if rc['done']:
            T[t]['rec_' + kind + '_done'] += 1
        else:
            H[t]['rec_cancel'][str(rc['cause'])] += 1
        H[t]['rec_hp'][bucket(hpf * 100, [25, 50, 60, 75, 90])] += 1
        H[t]['rec_gems'][bucket(rc['gems'], [1, 10, 30, 60])] += 1
        T[t]['rec_gems_carried'] += rc['gems']
        if r0 <= EARLY:
            T[t]['recE_' + kind] += 1

    # deaths
    for e in events:
        if e['k'] != 'death':
            continue
        v = e['v']
        t = team_of[v]
        bycamp = e.get('camp') is not None
        cause = 'camp' if bycamp else 'champ'
        T[t]['death_' + cause] += 1
        T[t]['gemslost_' + cause] += e.get('gems', 0)
        if e['r'] <= EARLY:
            T[t]['deathE_' + cause] += 1
            T[t]['gemslostE_' + cause] += e.get('gems', 0)
        if not bycamp and e.get('by') in team_of:
            kt = team_of[e['by']]
            T[kt]['kill_gems'] += e.get('gemsTo', 0) or 0
            T[kt]['kills'] += 0 if e.get('linked') is not None else 1
            if e['r'] <= EARLY:
                T[kt]['kill_gemsE'] += e.get('gemsTo', 0) or 0
        H[t]['death_bag'][bucket(e.get('gems', 0), [1, 10, 30, 60, 100])] += 1

    # captures
    for e in events:
        if e['k'] != 'capture':
            continue
        t = e['team']
        if t not in (0, 1):
            continue
        g = G.groups[e['g']]
        s = side_rel(g['side'], t)
        gems = sum(x[1] for x in e['shares'])
        gold = sum(x[2] for x in e['shares'])
        T[t]['cap_n'] += 1
        T[t]['cap_gems'] += gems
        T[t]['cap_gold'] += gold
        T[t]['cap_gems_' + s] += gems
        T[t]['cap_n_' + s] += 1
        if len(e['shares']) > 1:
            T[t]['cap_shared'] += 1
        if e['r'] <= EARLY:
            T[t]['capE_gems'] += gems
            T[t]['capE_gems_' + s] += gems
        H[t]['cap_type_gems'][gtype(g)] += gems
        H[t]['cap_type_n'][gtype(g)] += 1
        H[t]['cap_ptype_gems'][primary_type(g['types'])] += gems
        if 'Monolith' in g['types']:
            T[t]['mono_caps'] += 1
            T[t]['mono_gems'] += gems
            T[t]['mono_first_r'] = T[t].get('mono_first_r') or e['r']

    # tributes
    trib_open = {}
    for e in events:
        k = e['k']
        if k == 'tribute_start':
            trib_open[e['a']] = e
            t = team_of[e['a']]
            T[t]['trib_start'] += 1
            H[t]['trib_bag'][bucket(e['gems'], [10, 20, 30, 50, 100, 200])] += 1
            T[t]['trib_bag_sum'] += e['gems']
        elif k == 'tribute_end':
            t = team_of[e['a']]
            T[t]['trib_done'] += 1
            T[t]['trib_gems'] += e['gems']
        elif k == 'tribute_cancel':
            t = team_of[e['a']]
            T[t]['trib_cancel'] += 1
            H[t]['trib_cancel'][str(e.get('cause'))] += 1
    for c in ids:
        t = team_of[c]
        gm = CH[c]['gems']
        T[t]['carried_sum'] += sum(gm)
        T[t]['carried_max'] = max(T[t]['carried_max'], max(gm))
        T[t]['carried30_rounds'] += sum(1 for x in gm if x >= 30)
        T[t]['alive_rounds'] += sum(CH[c]['alive'])
        T[t]['carried_end'] += CH[c]['gems'][-1] if CH[c]['alive'][-1] else 0
        T[t]['gold_earned'] += CH[c]['earned'][-1]
        T[t]['camp_dmg_taken'] += camp_taken[c]
        T[t]['champ_dmg_dealt'] += dmg_dealt_champ[c]

    # score trajectory
    for t in (0, 1):
        gs = R['gems'][t]
        for rr in (200, 400, 600, 800, 1000):
            T[t][f'score_{rr}'] = gs[min(rr, N) - 1]
    # lead: first round from which the winner leads for good
    gw, gl = R['gems'][winner], R['gems'][1 - winner]
    lead_from = 1
    for i in range(N - 1, -1, -1):
        if gw[i] <= gl[i]:
            lead_from = i + 2
            break
    lead100 = None
    for i in range(N - 1, -1, -1):
        if gw[i] - gl[i] < 100:
            lead100 = i + 2 if i + 1 < N else None
            break
    out['lead_from'] = lead_from
    out['lead100_from'] = lead100

    # ---- group utilisation
    clear_durs = defaultdict(list)
    gtab = [defaultdict(lambda: defaultdict(float)) for _ in (0, 1)]  # side-rel -> state -> group-rounds (gem weighted too)
    for g in G.groups:
        gid = g['id']
        if gid not in gst:
            continue
        fh = full_hp.get(gid, 0)
        for r in range(1, N + 1):
            s = gst[gid][r]
            st, team_, awake, hp = s[2], s[3], s[6], s[7]
            if st == 1:
                if awake == 1:
                    k = 'awake'
                elif hp < fh - 1e-6:
                    k = 'up_damaged'
                else:
                    k = 'up_unworked'
            elif st == 2:
                k = 'cleared_held' if team_ in (0, 1) else 'cleared_empty'
            elif st == 3:
                k = 'respawning'
            else:
                k = 'unknown'
            pt = primary_type(g['types'])
            for t in (0, 1):
                sr = side_rel(g['side'], t)
                gtab[t][sr][k] += 1
                gtab[t][sr + '_gw'][k] += g['gems']
                gtab[t]['type:' + pt][k] += 1
                if pt != 'Monolith':
                    gtab[t][sr + '_gwnomono'][k] += g['gems']
    for t in (0, 1):
        H[t]['gutil'] = {sr: dict(v) for sr, v in gtab[t].items()}

    # clears: wake -> clear episodes
    last_wake = {}
    last_respawn = defaultdict(lambda: 0)
    clears = []
    for e in events:
        k = e['k']
        if k == 'group_wake':
            if e['g'] not in last_wake:
                last_wake[e['g']] = e['r']
        elif k == 'group_respawn':
            last_respawn[e['g']] = e['r']
            last_wake.pop(e['g'], None)
        elif k == 'group_clear':
            g = e['g']
            r0 = last_wake.pop(g, e['r'])
            clears.append((g, r0, e['r'], e.get('by')))
    cap_after = defaultdict(list)
    for e in events:
        if e['k'] == 'capture':
            cap_after[e['g']].append(e)
    heal_rec_starts = defaultdict(list)
    for rc in recalls:
        c = rc['c']
        r0 = rc['r0']
        hpf = at(c, 'hp', r0 - 1) / max(1e-9, at(c, 'maxHp', r0 - 1)) if r0 > 1 else 1.0
        if hpf < 0.6:
            heal_rec_starts[c].append(r0)
    camp_attacks_by_g = defaultdict(list)
    for e in events:
        if e['k'] == 'camp_attack':
            camp_attacks_by_g[e['g']].append(e)
    for g, r0, r1, by in clears:
        if by not in team_of:
            continue
        t = team_of[by]
        grp = G.groups[g]
        part = defaultdict(float)
        enemy_part = False
        for r in range(r0, r1 + 1):
            for c in ids:
                v = camp_hit.get((c, r))
                if v and g in v:
                    if team_of[c] == t:
                        part[c] += v[g]
                    else:
                        enemy_part = True
        taken = defaultdict(float)
        for e in camp_attacks_by_g[g]:
            if r0 <= e['r'] <= r1:
                if e.get('tgt') in team_of:
                    taken[e['tgt']] += e.get('dmg', 0)
                for x, amt in e.get('xdmg', []) or []:
                    taken[x] += amt
        own_taken = sum(v for c, v in taken.items() if team_of[c] == t)
        n_taken = sum(1 for c, v in taken.items() if team_of[c] == t and v > 0)
        cap = next((x for x in cap_after[g] if x['r'] > r1), None)
        gems_got = 0
        captured_by = None
        if cap and (cap['r'] - r1) < 60:
            captured_by = cap['team']
            if cap['team'] == t:
                gems_got = sum(x[1] for x in cap['shares'])
        npart = max(1, len(part))
        heal_after = sum(1 for c in part for x in heal_rec_starts[c] if r1 <= x <= r1 + 20)
        died_in = 0
        typ = gtype(grp)
        clear_durs[g].append(r1 - r0 + 1)
        rec = H[t]['clears']
        kk = f'{typ}|{"solo" if npart == 1 else "multi"}'
        rec[kk + '|n'] += 1
        rec[kk + '|rounds'] += r1 - r0 + 1
        rec[kk + '|taken'] += own_taken
        rec[kk + '|gems'] += gems_got
        rec[kk + '|gemsfull'] += grp['gems']
        rec[kk + '|capd'] += 1 if captured_by == t else 0
        work_r = sum(1 for c in ids if team_of[c] == t for r in range(r0, r1 + 7)
                     if r <= N and lab[c][r] in ('camp', 'hold') and key[c][r] == g)
        rec[kk + '|work_r'] += work_r
        T[t]['clear_work_rounds'] += work_r
        rec[kk + '|ntaken'] += n_taken
        rec[kk + '|npart'] += npart
        rec[kk + '|heal'] += heal_after
        rec[kk + '|lost'] += 1 if captured_by is not None and captured_by != t else 0
        rec[kk + '|contested'] += 1 if enemy_part else 0
        T[t]['clear_n'] += 1
        T[t]['clear_multi'] += npart > 1
        T[t]['clear_stolen'] += 1 if captured_by is not None and captured_by != t else 0
        T[t]['clear_heal_after'] += heal_after
        side = side_rel(grp['side'], t)
        T[t]['clear_n_' + side] += 1

    # supply: gems / (respawn + clear + 6), clear = observed median for the group (or its mirror) else hp/150
    supply_rate = 0.0
    sup_side = [defaultdict(float), defaultdict(float)]
    for g in G.groups:
        durs = clear_durs.get(g['id'], []) + (clear_durs.get(g['mirror'], []) if g.get('mirror') is not None and g['mirror'] != g['id'] else [])
        ct = statistics.median(durs) if durs else max(1, G.ghp.get(g['id'], 1000) / 150)
        rate = g['gems'] / (g['respawn'] + ct + 6)
        supply_rate += rate
        for t in (0, 1):
            H[t]['supply_type'][primary_type(g['types'])] += rate * N / 2
        for t in (0, 1):
            sup_side[t][side_rel(g['side'], t)] += rate
    out['supply'] = supply_rate * N
    for t in (0, 1):
        for s in ('own', 'mid', 'enemy'):
            T[t]['supply_' + s] = sup_side[t][s] * N

    # ---- legs (walking runs between anchors)
    def anchor(c, r):
        l = lab[c][r]
        if l in ('camp', 'hold'):
            return ('work', key[c][r])
        return (l, None)

    tgt = {c: [None] * (N + 2) for c in ids}  # hindsight target group: (g, 'work'|'walk')
    legs = []
    for c in ids:
        L = lab[c]
        r = 1
        while r <= N:
            if L[r] in ('camp', 'hold'):
                tgt[c][r] = (key[c][r], 'work')
            if L[r] not in WALKISH:
                r += 1
                continue
            j = r
            while j + 1 <= N and L[j + 1] in WALKISH:
                j += 1
            prev = anchor(c, r - 1) if r > 1 else ('spawn', None)
            nxt = anchor(c, j + 1) if j + 1 <= N else ('end', None)
            S = start_pos(c, r)
            path = [S] + [pos(c, rr) for rr in range(r, j + 1)]
            steps = sum(cheb(path[k], path[k + 1]) for k in range(len(path) - 1) if path[k] and path[k + 1])
            idle = sum(1 for rr in range(r, j + 1) if L[rr] == 'idle')
            legs.append({'c': c, 'r0': r, 'r1': j, 'prev': prev, 'next': nxt, 'S': S, 'E': path[-1], 'path': path,
                         'steps': steps, 'idle': idle, 'gems0': at(c, 'gems', r - 1) if r > 1 else 0})
            if nxt[0] == 'work':
                for rr in range(r, j + 1):
                    tgt[c][rr] = (nxt[1], 'walk')
            r = j + 1

    def worked_by(g, r, team, excl=None):
        for c in ids:
            if c == excl or team_of[c] != team:
                continue
            for rr in (r - 1, r, r + 1):
                if 1 <= rr <= N and lab[c][rr] in ('camp', 'hold') and key[c][rr] == g:
                    return True
        return False

    for lg in legs:
        c = lg['c']
        t = team_of[c]
        S, E = lg['S'], lg['E']
        prev, nxt = lg['prev'], lg['next']
        pk = prev[0] if prev[0] != 'hold' else 'work'
        nk = nxt[0]
        purpose = {'work': 'to_camp', 'tribute': 'to_altar', 'spawn': 'to_spawn', 'recall': 'then_recall',
                   'fight': 'then_fight', 'dead': 'then_dead', 'end': 'end', 'teleport': 'then_tp'}.get(nk, 'other')
        src = {'work': 'camp', 'tribute': 'altar', 'spawn': 'spawn', 'recall': 'recall', 'dead': 'dead',
               'fight': 'fight', 'teleport': 'tp'}.get(pk, pk)
        pkey = f'{src}->{purpose}'
        if purpose == 'to_camp' and pk == 'work':
            pkey += '(same)' if prev[1] == nxt[1] else '(other)'
        n_r = lg['r1'] - lg['r0'] + 1
        Hl = H[t]['legs']
        Hl[pkey + '|n'] += 1
        Hl[pkey + '|rounds'] += n_r
        Hl[pkey + '|steps'] += lg['steps']
        Hl[pkey + '|idle'] += lg['idle']
        T[t]['walk_steps'] += lg['steps']
        if purpose == 'to_altar':
            T[t]['steps_to_altar'] += lg['steps']
            # altar choice
            if len(G.altars) > 1 and S is not None:
                used = None
                rr = lg['r1'] + 1
                for e in by_round.get(rr, []):
                    if e['k'] == 'tribute_start' and e.get('a') == c:
                        used = tuple(e['altar'])
                if used in G.afield:
                    du = G.afield[used][G.idx(S)]
                    dm = min(G.afield[a][G.idx(S)] for a in G.altars)
                    if du >= INF or dm >= INF:
                        du = dm = 0
                    T[t]['alt_trips'] += 1
                    if du > dm + 2:
                        T[t]['alt_not_nearest'] += 1
                        T[t]['alt_extra_steps'] += du - dm
        if S is None or E is None:
            continue
        # detour: walked steps beyond the shortest path between the leg's ends
        fE = G.from_pt(E)
        dSE = fE[G.idx(S)]
        if dSE >= INF:
            continue
        excess = max(0, lg['steps'] - dSE)
        T[t]['walk_excess'] += excess
        Hl[pkey + '|excess'] += excess
        if excess >= 6:
            path = [p for p in lg['path'] if p is not None]
            rem = [0] * len(path)
            for k in range(len(path) - 2, -1, -1):
                rem[k] = rem[k + 1] + cheb(path[k], path[k + 1])
            kstar = len(path) - 1
            for k in range(len(path)):
                if rem[k] <= fE[G.idx(path[k])] + 2:
                    kstar = k
                    break
            W_ = path[kstar]
            rk = lg['r0'] + kstar - 1
            best, bd = None, NEAR + 1
            for g in G.groups:
                dd = G.gfield[g['id']][G.idx(W_)]
                if dd < bd:
                    best, bd = g['id'], dd
            dest_g = nxt[1] if nk == 'work' else None
            if best is not None and best != dest_g:
                s = gstate(best, rk)
                if worked_by(best, rk, t, excl=c):
                    why = 'ally_on_it'
                elif worked_by(best, rk, 1 - t):
                    why = 'enemy_on_it'
                elif s and s[2] == 3:
                    why = 'respawning'
                elif s and s[2] == 2:
                    why = 'cleared'
                elif s and s[2] == 1 and s[6] == 1:
                    why = 'awake'
                else:
                    why = 'up_unworked'
                T[t]['turnback_group'] += 1
                T[t]['turnback_group_excess'] += excess
                H[t]['turnback_why'][why] += 1
                H[t]['turnback_next'][purpose] += 1
            else:
                T[t]['detour_other'] += 1
                T[t]['detour_other_excess'] += excess

        # nearer available group skipped
        if purpose == 'to_camp':
            g = nxt[1]
            i0 = G.idx(S)
            dg = G.gfield[g][i0]
            r0 = lg['r0']
            s0 = gstate(g, r0 - 1)
            stg = {1: 'up', 2: 'cleared', 3: 'respawning'}.get(s0[2] if s0 else 0, '?')
            if stg == 'up' and s0[6] == 1:
                stg = 'awake'
            H[t]['tocamp_target_state'][stg] += 1
            ally_t = {tgt[o][r0][0] for o in ids if o != c and team_of[o] == t and tgt[o][r0]}
            T[t]['tocamp_n'] += 1
            T[t]['tocamp_dist'] += dg if dg < INF else 0
            nearer = nearer_val = 0
            for h in G.groups:
                hid = h['id']
                if hid == g or hid in ally_t or h['gems'] == 0:
                    continue
                sh = gstate(hid, r0 - 1)
                if not sh or sh[2] != 1 or sh[6] != 0 or sh[7] < full_hp.get(hid, 0) - 1e-6:
                    continue
                if G.gfield[hid][i0] + 5 <= dg:
                    nearer = 1
                    if h['gems'] >= G.groups[g]['gems']:
                        nearer_val = 1
            T[t]['tocamp_nearer_avail'] += nearer
            T[t]['tocamp_nearer_avail_val'] += nearer_val

    # ally target overlap
    for r in range(1, N + 1):
        for t in (0, 1):
            by_g = defaultdict(list)
            for c in ids:
                if team_of[c] == t and tgt[c][r]:
                    by_g[tgt[c][r][0]].append(tgt[c][r][1])
            for g, sts in by_g.items():
                for i, s in enumerate(sts):
                    T[t]['tgt_rounds'] += 1
                    if len(sts) > 1:
                        others = sts[:i] + sts[i + 1:]
                        if s == 'walk' and 'work' in others:
                            T[t]['tgt_walk_to_ally_work'] += 1
                        elif s == 'walk':
                            T[t]['tgt_walk_walk'] += 1
                        else:
                            T[t]['tgt_cowork'] += 1

    for t in (0, 1):
        for k in ('legs', 'clears'):
            H[t][k] = dict(H[t][k])
    out['side_mismatch'] = G.side_mismatch
    out['has_mono'] = any('Monolith' in g['types'] for g in G.groups)
    out['T'] = [dict(x) for x in T]
    out['H'] = [{k: (dict(v) if not isinstance(v, dict) else v) for k, v in h.items()} for h in H]
    return out


# ---------------------------------------------------------------- extract CLI


def cmd_extract(a):
    adir = a.analysis
    with open(os.path.join(adir, 'index.json')) as f:
        idx = json.load(f)['games']
    seen = {}
    for row in idx:
        if row['ok'] and row['dir'] not in seen:
            seen[row['dir']] = row['teams']
    jobs = [(adir, d, t) for d, t in seen.items()]
    if a.limit:
        jobs = jobs[:a.limit]
    out = a.out or os.path.join(adir, 'macro_features.jsonl.gz')
    n = err = 0
    with gzip.open(out, 'wt') as f, Pool(a.threads) as pool:
        for res in pool.imap_unordered(process, jobs, chunksize=1):
            n += 1
            if 'error' in res:
                err += 1
                print('ERR', res['dir'], res['error'], file=sys.stderr)
                continue
            f.write(json.dumps(res) + '\n')
            if n % 50 == 0:
                print(f'{n}/{len(jobs)}', file=sys.stderr)
    print(f'wrote {out}: {n - err} games, {err} errors', file=sys.stderr)


# ---------------------------------------------------------------- report


def load_features(p):
    with gzip.open(p, 'rt') as f:
        return [json.loads(l) for l in f if l.strip()]


def sides(games, by):
    """Yield (label, game, team) for every team side."""
    for g in games:
        for t in (0, 1):
            if by == 'result':
                lab = 'win' if g['winner'] == t else 'lose'
            else:
                lab = g['teams'][t]
            yield lab, g, t


def fmt(v, d=1):
    if v is None:
        return '-'
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return '-'
    return f'{v:.{d}f}'


def table(title, header, rows):
    print(f'\n### {title}\n')
    print('| ' + ' | '.join(header) + ' |')
    print('|' + '---|' * len(header))
    for r in rows:
        print('| ' + ' | '.join(str(x) for x in r) + ' |')


def cmd_report(a):
    games = load_features(a.features)
    if a.min_gap:
        games = [g for g in games if abs(g['gems'][0] - g['gems'][1]) >= a.min_gap]
    by = a.by
    labels = sorted({l for l, _, _ in sides(games, by)}, key=lambda s: (s != 'win', s))
    cols = labels + ['all']
    acc = {l: defaultdict(float) for l in cols}
    hacc = {l: defaultdict(lambda: defaultdict(float)) for l in cols}
    ngames = Counter()
    for l, g, t in sides(games, by):
        for L in (l, 'all'):
            ngames[L] += 1
            for k, v in g['T'][t].items():
                acc[L][k] += v
            for hk, hv in g['H'][t].items():
                if hk == 'gutil':
                    for sr, d in hv.items():
                        for st, v in d.items():
                            hacc[L]['gutil|' + sr][st] += v
                else:
                    for k, v in hv.items():
                        hacc[L][hk][k] += v
    print(f'# Macro report: {len(games)} games, split by {by}: ' + ', '.join(f'{l} {ngames[l]} sides' for l in labels))

    # 1 time budget
    rows = []
    for lb in LABELS:
        rows.append([lb] + [fmt(100 * acc[L]['tb_' + lb] / acc[L]['champ_rounds']) for L in cols]
                    + [fmt(100 * acc[L]['tbE_' + lb] / acc[L]['champ_roundsE']) for L in cols])
    table('1. Champion time budget (% of champion-rounds; E = rounds 1-300)', ['label'] + cols + [c + ' E' for c in cols], rows)
    subs = sorted({k[4:] for L in cols for k in acc[L] if k.startswith('sub_')})
    rows = [[s] + [fmt(100 * acc[L]['sub_' + s] / acc[L]['champ_rounds'], 2) for L in cols] for s in subs]
    table('1b. Sub-labels (% of champion-rounds)', ['sub'] + cols, rows)
    # per type
    types = sorted({k.split('|')[0] for k in hacc['all']['tb_type']})
    rows = []
    for ty in types:
        tot = hacc['all']['type_rounds'][ty]
        rows.append([ty, fmt(tot / 1000, 0)] + [fmt(100 * hacc['all']['tb_type'][ty + '|' + lb] / tot) for lb in LABELS])
    table('1c. Time budget by champion type (all sides, %)', ['type', 'k rounds'] + LABELS, rows)
    # recalls
    rk = ['heal', 'bank', 'shop', 'other']
    rows = []
    for L in cols:
        n = acc[L]['rec_n']
        rows.append([L, fmt(n / ngames[L], 2), fmt(100 * acc[L]['rec_done'] / max(1, n))]
                    + [f"{fmt(acc[L]['rec_' + k] / ngames[L], 2)} ({fmt(100 * acc[L]['rec_' + k + '_done'] / max(1, acc[L]['rec_' + k]), 0)}%)" for k in rk]
                    + [fmt(acc[L]['rec_gems_carried'] / max(1, n), 1)])
    table('1d. Real recalls per team-game (heal: hp<60%; bank: >=10 gems; shop: shop within 3 rounds of arrival); (completed %)',
          ['side', 'recalls', 'done %'] + rk + ['gems carried/recall'], rows)
    rows = []
    for L in cols:
        cr = acc[L]['champ_rounds']
        rows.append([L] + [fmt(100 * acc[L]['recr_' + k] / cr, 2) for k in rk] + [fmt(100 * acc[L]['rec_wasted_rounds'] / cr, 2),
                     fmt(acc[L]['carried_sum'] / cr, 1), fmt(100 * acc[L]['carried30_rounds'] / cr, 1)])
    table('1d2. Recall rounds by kind and cancelled-recall rounds (% of champion-rounds); mean carried gems per champion-round; % rounds carrying >=30',
          ['side'] + rk + ['cancelled', 'mean bag', 'bag>=30 %'], rows)
    for hk, title in (('rec_hp', 'recall start hp%'), ('rec_gems', 'recall start gems'), ('rec_cancel', 'recall cancel cause')):
        ks = sorted({k for L in cols for k in hacc[L][hk]})
        rows = [[L] + [fmt(100 * hacc[L][hk][k] / max(1, sum(hacc[L][hk].values())), 1) for k in ks] for L in cols]
        table(f'1e. {title} (% of recalls)', ['side'] + ks, rows)

    # 2 utilisation
    states = ['up_unworked', 'up_damaged', 'awake', 'cleared_empty', 'cleared_held', 'respawning']
    for w, wt in (('', 'group-rounds'), ('_gw', 'gem-weighted group-rounds'), ('_gwnomono', 'gem-weighted group-rounds, no Monolith')):
        rows = []
        for L in cols:
            for sr in ('own', 'mid', 'enemy'):
                d = hacc[L]['gutil|' + sr + w]
                tot = sum(d.values())
                if tot:
                    rows.append([L, sr] + [fmt(100 * d[s] / tot) for s in states])
        table(f'2. Camp-group state, % of {wt} (side relative to the team)', ['side', 'groups'] + states, rows)
    rows = []
    for pt in PRIMARY:
        d = hacc['all']['gutil|type:' + pt]
        tot = sum(d.values())
        if tot:
            rows.append([pt] + [fmt(100 * d[s] / tot) for s in states])
    table('2a. Camp-group state by primary type (% of group-rounds, all games)', ['type'] + states, rows)
    rows = []
    for pt in PRIMARY:
        rows.append([pt] + [f"{fmt(hacc[L]['cap_ptype_gems'][pt] / ngames[L], 1)} / {fmt(hacc[L]['supply_type'][pt] / ngames[L], 1)} = {fmt(100 * hacc[L]['cap_ptype_gems'][pt] / max(1e-9, hacc[L]['supply_type'][pt]), 0)}%" for L in cols])
    table('2d. Gems captured / half-map supply per team-game, by primary type', ['type'] + cols, rows)
    rows = []
    for L in cols:
        n = ngames[L]
        sup = sum(acc[L]['supply_' + s] for s in ('own', 'mid', 'enemy'))
        rows.append([L] + [fmt(acc[L]['cap_gems_' + s] / n) for s in ('own', 'mid', 'enemy')]
                    + [fmt(acc[L]['cap_gems'] / n), fmt(acc[L]['kill_gems'] / n), fmt(acc[L]['trib_gems'] / n),
                       fmt(100 * acc[L]['cap_gems'] / (sup / 2)),
                       fmt(100 * acc[L]['cap_gems_own'] / max(1, acc[L]['supply_own'])),
                       fmt(100 * acc[L]['cap_gems_mid'] / max(1, acc[L]['supply_mid'] / 2)),
                       fmt(100 * acc[L]['cap_gems_enemy'] / max(1, acc[L]['supply_enemy']))])
    table('2b. Gems per team-game: captured by side, kill gems, tributed; % of supply harvested (team share = half the map; mid = half of mid)',
          ['side', 'cap own', 'cap mid', 'cap enemy', 'cap total', 'kill gems', 'tributed', '% of half-map supply', '% own supply', '% half mid', '% enemy supply'], rows)
    ty = sorted({k for L in cols for k in hacc[L]['cap_type_gems']}, key=lambda k: -hacc['all']['cap_type_gems'][k])
    rows = [[k] + [f"{fmt(hacc[L]['cap_type_n'][k] / ngames[L], 2)} / {fmt(hacc[L]['cap_type_gems'][k] / ngames[L], 1)}" for L in cols] for k in ty[:14]]
    table('2c. Captures per team-game by group type (count / gems)', ['type'] + cols, rows)

    # 3 walking
    pk = sorted({k.rsplit('|', 1)[0] for k in hacc['all']['legs']}, key=lambda k: -hacc['all']['legs'][k + '|n'])
    rows = []
    for k in pk[:16]:
        r_ = [k]
        for L in cols:
            h = hacc[L]['legs']
            n = h[k + '|n']
            r_.append(f"{fmt(n / ngames[L], 1)}: {fmt(h[k + '|rounds'] / max(1, n))}r {fmt(h[k + '|steps'] / max(1, n))}s +{fmt(h[k + '|excess'] / max(1, n))}x")
        rows.append(r_)
    table('3. Walking legs per team-game: count: mean rounds, steps, excess steps over shortest path', ['leg'] + cols, rows)
    rows = []
    for L in cols:
        n = ngames[L]
        rows.append([L, fmt(acc[L]['walk_steps'] / n, 0), fmt(acc[L]['walk_excess'] / n, 0),
                     fmt(100 * acc[L]['walk_excess'] / max(1, acc[L]['walk_steps'])),
                     fmt(acc[L]['turnback_group'] / n, 1), fmt(acc[L]['turnback_group_excess'] / n, 0),
                     fmt(acc[L]['detour_other'] / n, 1),
                     fmt(100 * acc[L]['tocamp_nearer_avail'] / max(1, acc[L]['tocamp_n'])),
                     fmt(100 * acc[L]['tocamp_nearer_avail_val'] / max(1, acc[L]['tocamp_n'])),
                     fmt(acc[L]['tocamp_dist'] / max(1, acc[L]['tocamp_n']))])
    table('3b. Walking waste per team-game', ['side', 'steps', 'excess steps', 'excess %', 'turn-backs at a group',
                                              'their excess', 'other detours', '% to-camp legs with nearer avail group (>=5 closer)',
                                              '... with >= gems', 'mean dist to target'], rows)
    for hk, title in (('turnback_why', 'turn-back group state'), ('turnback_next', 'what the turn-back leg ended in'),
                      ('tocamp_target_state', 'target state at to-camp leg start')):
        ks = sorted({k for L in cols for k in hacc[L][hk]})
        rows = [[L] + [fmt(100 * hacc[L][hk][k] / max(1, sum(hacc[L][hk].values()))) for k in ks] for L in cols]
        table(f'3c. {title} (%)', ['side'] + ks, rows)
    rows = []
    for L in cols:
        tr = max(1, acc[L]['tgt_rounds'])
        rows.append([L, fmt(100 * acc[L]['tgt_walk_walk'] / tr), fmt(100 * acc[L]['tgt_walk_to_ally_work'] / tr),
                     fmt(100 * acc[L]['tgt_cowork'] / tr)])
    table('3d. Ally target overlap (% of champion-rounds with a hindsight camp target)',
          ['side', 'both walking to same group', 'walking to a group an ally works', 'co-working'], rows)

    # 4 banking
    rows = []
    for L in cols:
        n = ngames[L]
        ts = max(1, acc[L]['trib_start'])
        rows.append([L, fmt(acc[L]['trib_start'] / n, 1), fmt(acc[L]['trib_bag_sum'] / ts),
                     fmt(1000 * acc[L]['trib_done'] / acc[L]['alive_rounds'], 2),
                     fmt(acc[L]['walk_steps'] / max(1, acc[L]['trib_done'])),
                     fmt(acc[L]['steps_to_altar'] / max(1, acc[L]['trib_done'])),
                     fmt(100 * acc[L]['trib_cancel'] / ts),
                     f"{fmt(100 * acc[L]['alt_not_nearest'] / max(1, acc[L]['alt_trips']))} (+{fmt(acc[L]['alt_extra_steps'] / max(1, acc[L]['alt_not_nearest']))})",
                     fmt(acc[L]['gemslost_camp'] / n), fmt(acc[L]['gemslost_champ'] / n), fmt(acc[L]['carried_end'] / n)])
    table('4. Banking per team-game', ['side', 'tributes', 'mean bag', 'tributes/champ/1000 alive r', 'steps/tribute',
                                       'altar-leg steps/tribute', 'cancel %', 'not nearest altar % (+steps), multi-altar maps',
                                       'gems lost to camps', 'gems lost to champs', 'carried at end'], rows)
    ks = ['<10', '<20', '<30', '<50', '<100', '<200', '>=200']
    rows = [[L] + [fmt(100 * hacc[L]['trib_bag'][k] / max(1, sum(hacc[L]['trib_bag'].values()))) for k in ks] for L in cols]
    table('4b. Bag at tribute start (% of tributes)', ['side'] + ks, rows)
    rows = []
    for L in cols:
        n = ngames[L]
        rows.append([L, fmt(acc[L]['death_camp'] / n, 2), fmt(acc[L]['death_champ'] / n, 2), fmt(acc[L]['kills'] / n, 2),
                     fmt(acc[L]['deathE_camp'] / n, 2), fmt(acc[L]['deathE_champ'] / n, 2),
                     fmt(acc[L]['gemslostE_camp'] / n, 1), fmt(acc[L]['gemslostE_champ'] / n, 1)])
    table('4c. Deaths per team-game', ['side', 'by camps', 'by champs', 'kills', 'camp E', 'champ E', 'gems lost camp E', 'gems lost champ E'], rows)

    # 5 clears
    ck = sorted({k.rsplit('|', 1)[0] for k in hacc['all']['clears']}, key=lambda k: -hacc['all']['clears'][k + '|n'])
    rows = []
    for k in ck[:22]:
        r_ = [k]
        h = hacc['all']['clears']
        n = h[k + '|n']
        r_ += [fmt(n / ngames['all'], 2), fmt(h[k + '|rounds'] / n), fmt(h[k + '|work_r'] / n), fmt(h[k + '|npart'] / n, 2), fmt(h[k + '|ntaken'] / n, 2),
               fmt(h[k + '|taken'] / n, 0), fmt(h[k + '|taken'] / max(1, h[k + '|gems']), 1), fmt(100 * h[k + '|gems'] / max(1, h[k + '|gemsfull']), 0),
               fmt(100 * h[k + '|lost'] / n, 1), fmt(100 * h[k + '|contested'] / n, 1), fmt(100 * h[k + '|heal'] / n, 1)]
        rows.append(r_)
    table('5. Clears (all sides): per team-game, rounds wake->clear, participants, champions damaged, camp dmg taken, dmg per gem won, % of gems won, % stolen, % enemy hit it too, heal recalls within 20r per clear',
          ['type|mode', 'n/game', 'rounds', 'champ work-rounds (clear+capture)', 'part', 'n hurt', 'dmg taken', 'dmg/gem', 'gems won %', 'stolen %', 'contested %', 'heal rec %'], rows)
    rows = []
    for L in cols:
        n = ngames[L]
        rows.append([L, fmt(acc[L]['clear_n'] / n, 1), fmt(100 * acc[L]['clear_multi'] / max(1, acc[L]['clear_n'])),
                     fmt(acc[L]['clear_stolen'] / n, 2), fmt(acc[L]['clear_heal_after'] / n, 2),
                     fmt(acc[L]['camp_dmg_taken'] / max(1, acc[L]['cap_gems']), 1)] +
                    [fmt(acc[L]['clear_n_' + s] / n, 1) for s in ('own', 'mid', 'enemy')])
    table('5b. Clears per team-game', ['side', 'clears', 'multi %', 'stolen', 'heal recalls after', 'camp dmg/captured gem', 'own', 'mid', 'enemy'], rows)

    # 6 score
    if by == 'result':
        rows = []
        for L in ('win', 'lose'):
            n = ngames[L]
            rows.append([L] + [fmt(acc[L][f'score_{r}'] / n, 0) for r in (200, 400, 600, 800, 1000)])
        table('6. Mean tributed gems by round (final value if over)', ['side', 'r200', 'r400', 'r600', 'r800', 'r1000'], rows)
        Ns = sorted(g['N'] for g in games)
        lf = sorted(g['lead_from'] for g in games)
        l100 = [g['lead100_from'] for g in games if g['lead100_from']]
        gaps = sorted(abs(g['gems'][0] - g['gems'][1]) for g in games)
        q = lambda a, p: a[min(len(a) - 1, int(p * len(a)))] if a else None
        print(f"\nGame length rounds: median {q(Ns, .5)}, p25 {q(Ns, .25)}, p75 {q(Ns, .75)}; at 2000: {sum(1 for x in Ns if x >= 2000)}")
        print(f"Final gap (gems): median {q(gaps, .5)}, p25 {q(gaps, .25)}, p75 {q(gaps, .75)}")
        print(f"Winner leads for good from round: median {q(lf, .5)}, p25 {q(lf, .25)}, p75 {q(lf, .75)}; as share of game: median {fmt(statistics.median(g['lead_from'] / g['N'] for g in games), 2)}")
        print(f"Winner leads by >=100 for good from round: median {q(sorted(l100), .5)} ({len(l100)} games)")
        # side
        print(f"Team A wins {sum(1 for g in games if g['winner'] == 0)} / {len(games)}")
        # separation
        sep = defaultdict(list)
        allkeys = set()
        for g in games:
            allkeys |= set(g['T'][0]) | set(g['T'][1])
        allkeys = {k for k in allkeys if not k.startswith(('score_', 'supply_')) and k not in
                   ('champ_rounds', 'champ_roundsE', 'mono_first_r', 'alive_rounds', 'trib_gems', 'trib_bag_sum')}
        for g in games:
            w = g['winner']
            Tw, Tl = g['T'][w], g['T'][1 - w]
            for k in allkeys:
                sep[k].append(Tw.get(k, 0) - Tl.get(k, 0))
        rows = []
        for k, v in sep.items():
            if len(v) < 20:
                continue
            m = statistics.mean(v)
            sd = statistics.pstdev(v) or 1e-9
            pos_ = sum(1 for x in v if x > 0) / len(v)
            neg = sum(1 for x in v if x < 0) / len(v)
            rows.append((abs(m) / sd, k, m, sd, pos_, neg))
        rows.sort(reverse=True)
        table('6c. Same, rounds 1-300 metrics only (less reverse causality)', ['metric', 'mean W-L', 'sd', 'W>L %', 'W<L %', 'effect'],
              [[k, fmt(m, 2), fmt(sd, 2), fmt(100 * p), fmt(100 * n_), fmt(e, 2)] for e, k, m, sd, p, n_ in rows if 'E_' in k or k.startswith('tbE')][:20])
        # gem-gap decomposition: tributed = captured + kill gems - lost on death - carried at end
        dc = defaultdict(float)
        for g in games:
            w = g['winner']
            Tw, Tl = g['T'][w], g['T'][1 - w]
            f = lambda T_, k: T_.get(k, 0)
            dc['tributed'] += f(Tw, 'trib_gems') - f(Tl, 'trib_gems')
            for s_ in ('own', 'mid', 'enemy'):
                dc['captured ' + s_] += f(Tw, 'cap_gems_' + s_) - f(Tl, 'cap_gems_' + s_)
            dc['  of which monolith'] += f(Tw, 'mono_gems') - f(Tl, 'mono_gems')
            dc['kill gems'] += f(Tw, 'kill_gems') - f(Tl, 'kill_gems')
            dc['minus lost to camps'] -= f(Tw, 'gemslost_camp') - f(Tl, 'gemslost_camp')
            dc['minus lost to champs'] -= f(Tw, 'gemslost_champ') - f(Tl, 'gemslost_champ')
            dc['minus carried at end'] -= f(Tw, 'carried_end') - f(Tl, 'carried_end')
        table('6d. Mean winner-minus-loser gem gap, decomposed', ['term', 'gems/game'], [[k, fmt(v / len(games), 1)] for k, v in dc.items()])
        mg = [g for g in games if g.get('has_mono')]
        if mg:
            wcap = sum(1 for g in mg if g['T'][g['winner']].get('mono_caps', 0) > g['T'][1 - g['winner']].get('mono_caps', 0))
            lcap = sum(1 for g in mg if g['T'][g['winner']].get('mono_caps', 0) < g['T'][1 - g['winner']].get('mono_caps', 0))
            anyc = sum(1 for g in mg if g['T'][0].get('mono_caps', 0) + g['T'][1].get('mono_caps', 0) > 0)
            print(f"\nMonolith maps: {len(mg)} games; any monolith capture in {anyc}; winner captured more {wcap}, loser more {lcap}")
        table('6b. Winner-minus-loser per game, ranked by |mean|/sd (E = rounds 1-300 only; tb_ in champion-rounds)',
              ['metric', 'mean W-L', 'sd', 'W>L %', 'W<L %', 'effect'],
              [[k, fmt(m, 2), fmt(sd, 2), fmt(100 * p), fmt(100 * n_), fmt(e, 2)] for e, k, m, sd, p, n_ in rows[:45]])


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest='cmd', required=True)
    e = sp.add_parser('extract')
    e.add_argument('analysis')
    e.add_argument('--out')
    e.add_argument('--threads', type=int, default=32)
    e.add_argument('--limit', type=int, default=0)
    r = sp.add_parser('report')
    r.add_argument('features')
    r.add_argument('--by', default='result', choices=['result', 'team'])
    r.add_argument('--min-gap', type=int, default=0)
    a = ap.parse_args()
    cmd_extract(a) if a.cmd == 'extract' else cmd_report(a)


if __name__ == '__main__':
    main()
