# Macro report: 582 games, split by result: win 582 sides, lose 582 sides

### 1. Champion time budget (% of champion-rounds; E = rounds 1-300)

| label | win | lose | all | win E | lose E | all E |
|---|---|---|---|---|---|---|
| dead | 3.5 | 7.6 | 5.5 | 2.6 | 4.4 | 3.5 |
| recall | 7.1 | 6.8 | 7.0 | 8.3 | 8.0 | 8.1 |
| tribute | 3.4 | 2.4 | 2.9 | 2.3 | 2.0 | 2.1 |
| teleport | 0.1 | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 |
| fight | 3.7 | 3.7 | 3.7 | 2.9 | 2.8 | 2.8 |
| camp | 17.8 | 16.3 | 17.0 | 24.8 | 24.0 | 24.4 |
| hold | 5.1 | 4.7 | 4.9 | 5.2 | 5.0 | 5.1 |
| spawn | 1.1 | 1.3 | 1.2 | 1.2 | 1.2 | 1.2 |
| walk_empty | 33.1 | 33.4 | 33.2 | 31.8 | 31.7 | 31.8 |
| walk_gems | 18.7 | 18.0 | 18.3 | 16.7 | 16.5 | 16.6 |
| idle | 6.5 | 5.8 | 6.1 | 4.4 | 4.3 | 4.3 |

### 1b. Sub-labels (% of champion-rounds)

| sub | win | lose | all |
|---|---|---|---|
| fight_alone | 1.33 | 1.17 | 1.25 |
| idle_at_altar | 0.24 | 0.18 | 0.21 |
| idle_near_cleared | 0.30 | 0.15 | 0.22 |
| idle_near_respawning | 4.21 | 3.67 | 3.94 |
| idle_near_up | 0.66 | 0.54 | 0.60 |
| idle_other | 1.11 | 1.24 | 1.17 |
| idle_with_gems | 1.84 | 1.85 | 1.84 |
| spawn_shop | 0.01 | 0.01 | 0.01 |
| walk_gems30 | 7.90 | 7.30 | 7.60 |

### 1c. Time budget by champion type (all sides, %)

| type | k rounds | dead | recall | tribute | teleport | fight | camp | hold | spawn | walk_empty | walk_gems | idle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | 379 | 6.0 | 7.1 | 2.0 | 0.0 | 0.9 | 20.7 | 5.0 | 1.3 | 38.5 | 12.4 | 6.1 |
| Heart of Ruin | 980 | 7.0 | 6.1 | 2.5 | 0.0 | 7.2 | 17.3 | 3.9 | 1.1 | 33.9 | 15.1 | 5.9 |
| Issac | 379 | 6.0 | 8.4 | 3.3 | 0.0 | 1.6 | 18.4 | 4.2 | 0.6 | 39.6 | 13.1 | 4.7 |
| Marcella | 1058 | 5.4 | 7.4 | 3.0 | 0.1 | 4.0 | 13.8 | 4.7 | 1.6 | 35.3 | 18.7 | 5.9 |
| Prism | 519 | 4.2 | 5.1 | 2.7 | 0.2 | 2.4 | 19.1 | 9.6 | 1.9 | 8.8 | 38.1 | 8.0 |
| Ren | 12 | 4.7 | 7.5 | 2.5 | 0.1 | 6.7 | 17.5 | 1.9 | 1.6 | 34.0 | 21.8 | 1.9 |
| Ryth | 62 | 8.3 | 6.5 | 3.4 | 0.0 | 9.8 | 10.5 | 5.9 | 1.4 | 30.5 | 20.4 | 3.2 |
| Tavi | 74 | 10.6 | 3.5 | 1.6 | 0.1 | 6.7 | 14.7 | 9.1 | 1.6 | 37.8 | 7.3 | 7.2 |
| Varg | 100 | 2.5 | 7.6 | 3.7 | 0.0 | 0.9 | 19.5 | 3.0 | 1.5 | 39.8 | 16.7 | 4.8 |
| Vendetta | 895 | 4.4 | 9.0 | 4.4 | 0.0 | 2.4 | 16.2 | 4.0 | 0.8 | 33.6 | 19.6 | 5.6 |
| Vesper Vale | 452 | 4.2 | 7.3 | 2.9 | 0.0 | 5.0 | 17.5 | 3.6 | 1.0 | 36.8 | 16.1 | 5.7 |
| Willow | 477 | 6.4 | 5.1 | 1.2 | 0.1 | 1.6 | 19.3 | 4.7 | 1.5 | 38.7 | 12.8 | 8.6 |

### 1d. Real recalls per team-game (heal: hp<60%; bank: >=10 gems; shop: shop within 3 rounds of arrival); (completed %)

| side | recalls | done % | heal | bank | shop | other | gems carried/recall |
|---|---|---|---|---|---|---|---|
| win | 60.22 | 86.6 | 25.72 (86%) | 7.79 (89%) | 20.33 (100%) | 6.39 (45%) | 12.6 |
| lose | 57.05 | 85.3 | 25.12 (85%) | 7.45 (88%) | 17.68 (100%) | 6.80 (45%) | 12.1 |
| all | 58.64 | 86.0 | 25.42 (85%) | 7.62 (88%) | 19.01 (100%) | 6.59 (45%) | 12.3 |

### 1d2. Recall rounds by kind and cancelled-recall rounds (% of champion-rounds); mean carried gems per champion-round; % rounds carrying >=30

| side | heal | bank | shop | other | cancelled | mean bag | bag>=30 % |
|---|---|---|---|---|---|---|---|
| win | 3.09 | 0.92 | 2.49 | 0.68 | 0.70 | 19.5 | 14.9 |
| lose | 3.03 | 0.88 | 2.20 | 0.72 | 0.72 | 15.0 | 13.2 |
| all | 3.06 | 0.90 | 2.34 | 0.70 | 0.71 | 17.2 | 14.1 |

### 1e. recall start hp% (% of recalls)

| side | <25 | <50 | <60 | <75 | <90 | >=90 |
|---|---|---|---|---|---|---|
| win | 7.7 | 28.0 | 7.0 | 10.8 | 13.1 | 33.3 |
| lose | 8.6 | 28.7 | 6.8 | 10.0 | 12.6 | 33.4 |
| all | 8.1 | 28.3 | 6.9 | 10.4 | 12.9 | 33.4 |

### 1e. recall start gems (% of recalls)

| side | <1 | <10 | <30 | <60 | >=60 |
|---|---|---|---|---|---|
| win | 72.3 | 5.9 | 10.8 | 6.2 | 4.7 |
| lose | 71.1 | 6.5 | 11.3 | 6.6 | 4.4 |
| all | 71.7 | 6.2 | 11.1 | 6.4 | 4.6 |

### 1e. recall cancel cause (% of recalls)

| side | damage | death | end | manual | stun |
|---|---|---|---|---|---|
| win | 10.8 | 0.6 | 1.0 | 86.8 | 0.8 |
| lose | 10.6 | 1.1 | 1.5 | 86.2 | 0.6 |
| all | 10.7 | 0.8 | 1.3 | 86.5 | 0.7 |

### 2. Camp-group state, % of group-rounds (side relative to the team)

| side | groups | up_unworked | up_damaged | awake | cleared_empty | cleared_held | respawning |
|---|---|---|---|---|---|---|---|
| win | own | 47.9 | 5.5 | 5.9 | 3.3 | 2.9 | 34.5 |
| win | mid | 56.4 | 9.4 | 7.0 | 4.0 | 1.8 | 21.4 |
| win | enemy | 48.0 | 6.0 | 6.1 | 3.3 | 2.9 | 33.7 |
| lose | own | 48.0 | 6.0 | 6.1 | 3.3 | 2.9 | 33.7 |
| lose | mid | 56.4 | 9.4 | 7.0 | 4.0 | 1.8 | 21.4 |
| lose | enemy | 47.9 | 5.5 | 5.9 | 3.3 | 2.9 | 34.5 |
| all | own | 47.9 | 5.7 | 6.0 | 3.3 | 2.9 | 34.1 |
| all | mid | 56.4 | 9.4 | 7.0 | 4.0 | 1.8 | 21.4 |
| all | enemy | 47.9 | 5.7 | 6.0 | 3.3 | 2.9 | 34.1 |

### 2. Camp-group state, % of gem-weighted group-rounds (side relative to the team)

| side | groups | up_unworked | up_damaged | awake | cleared_empty | cleared_held | respawning |
|---|---|---|---|---|---|---|---|
| win | own | 57.7 | 5.7 | 6.8 | 1.2 | 2.0 | 26.6 |
| win | mid | 64.4 | 9.8 | 8.4 | 3.3 | 0.9 | 13.1 |
| win | enemy | 57.9 | 6.7 | 6.9 | 1.3 | 1.9 | 25.3 |
| lose | own | 57.9 | 6.7 | 6.9 | 1.3 | 1.9 | 25.3 |
| lose | mid | 64.4 | 9.8 | 8.4 | 3.3 | 0.9 | 13.1 |
| lose | enemy | 57.7 | 5.7 | 6.8 | 1.2 | 2.0 | 26.6 |
| all | own | 57.8 | 6.2 | 6.9 | 1.2 | 2.0 | 26.0 |
| all | mid | 64.4 | 9.8 | 8.4 | 3.3 | 0.9 | 13.1 |
| all | enemy | 57.8 | 6.2 | 6.9 | 1.2 | 2.0 | 26.0 |

### 2. Camp-group state, % of gem-weighted group-rounds, no Monolith (side relative to the team)

| side | groups | up_unworked | up_damaged | awake | cleared_empty | cleared_held | respawning |
|---|---|---|---|---|---|---|---|
| win | own | 43.7 | 7.3 | 8.5 | 1.7 | 2.8 | 36.1 |
| win | mid | 44.8 | 15.7 | 12.1 | 5.7 | 1.5 | 20.1 |
| win | enemy | 43.6 | 8.5 | 8.8 | 1.8 | 2.7 | 34.6 |
| lose | own | 43.6 | 8.5 | 8.8 | 1.8 | 2.7 | 34.6 |
| lose | mid | 44.8 | 15.7 | 12.1 | 5.7 | 1.5 | 20.1 |
| lose | enemy | 43.7 | 7.3 | 8.5 | 1.7 | 2.8 | 36.1 |
| all | own | 43.7 | 7.9 | 8.6 | 1.7 | 2.8 | 35.4 |
| all | mid | 44.8 | 15.7 | 12.1 | 5.7 | 1.5 | 20.1 |
| all | enemy | 43.7 | 7.9 | 8.6 | 1.7 | 2.8 | 35.4 |

### 2a. Camp-group state by primary type (% of group-rounds, all games)

| type | up_unworked | up_damaged | awake | cleared_empty | cleared_held | respawning |
|---|---|---|---|---|---|---|
| Monolith | 88.9 | 2.5 | 3.2 | 0.1 | 0.2 | 5.2 |
| Golem | 47.5 | 13.3 | 9.9 | 0.9 | 1.4 | 27.0 |
| Elk | 42.9 | 8.1 | 10.4 | 1.6 | 2.5 | 34.5 |
| Wolf | 56.0 | 8.0 | 7.9 | 1.6 | 2.4 | 24.1 |
| Gem cluster | 36.8 | 1.7 | 3.0 | 4.5 | 4.5 | 49.5 |
| Gold cluster | 50.3 | 3.9 | 1.7 | 7.5 | 2.9 | 33.7 |

### 2d. Gems captured / half-map supply per team-game, by primary type

| type | win | lose | all |
|---|---|---|---|
| Monolith | 42.5 / 256.7 = 17% | 21.0 / 256.7 = 8% | 31.8 / 256.7 = 12% |
| Golem | 130.7 / 251.7 = 52% | 91.3 / 251.7 = 36% | 111.0 / 251.7 = 44% |
| Elk | 348.1 / 567.0 = 61% | 260.4 / 567.0 = 46% | 304.2 / 567.0 = 54% |
| Wolf | 131.8 / 291.5 = 45% | 109.3 / 291.5 = 38% | 120.5 / 291.5 = 41% |
| Gem cluster | 344.8 / 450.0 = 77% | 295.5 / 450.0 = 66% | 320.2 / 450.0 = 71% |
| Gold cluster | 0.0 / 0.0 = 0% | 0.0 / 0.0 = 0% | 0.0 / 0.0 = 0% |

### 2b. Gems per team-game: captured by side, kill gems, tributed; % of supply harvested (team share = half the map; mid = half of mid)

| side | cap own | cap mid | cap enemy | cap total | kill gems | tributed | % of half-map supply | % own supply | % half mid | % enemy supply |
|---|---|---|---|---|---|---|---|---|---|---|
| win | 763.8 | 168.3 | 65.8 | 997.9 | 78.3 | 1006.9 | 54.9 | 50.5 | 55.5 | 4.3 |
| lose | 691.8 | 60.5 | 25.3 | 777.5 | 33.3 | 635.3 | 42.8 | 45.7 | 20.0 | 1.7 |
| all | 727.8 | 114.4 | 45.5 | 887.7 | 55.8 | 821.1 | 48.9 | 48.1 | 37.7 | 3.0 |

### 2c. Captures per team-game by group type (count / gems)

| type | win | lose | all |
|---|---|---|---|
| Gem cluster+3 | 6.67 / 146.8 | 6.07 / 133.0 | 6.37 / 139.9 |
| Elk+1 | 5.13 / 92.5 | 4.47 / 79.1 | 4.80 / 85.8 |
| Elk+3 | 2.42 / 90.7 | 1.93 / 71.5 | 2.17 / 81.1 |
| Elk | 4.86 / 72.8 | 4.00 / 60.0 | 4.43 / 66.4 |
| Gem cluster+2 | 2.91 / 69.4 | 2.52 / 59.8 | 2.72 / 64.6 |
| Gem cluster | 7.54 / 58.0 | 6.94 / 53.1 | 7.24 / 55.6 |
| Gem cluster+1 | 2.93 / 45.6 | 2.63 / 40.9 | 2.78 / 43.3 |
| Golem+2 | 1.16 / 47.0 | 0.88 / 35.2 | 1.02 / 41.1 |
| Wolf | 9.58 / 38.3 | 8.81 / 35.2 | 9.20 / 36.8 |
| Golem | 1.01 / 36.4 | 0.79 / 28.6 | 0.90 / 32.5 |
| Wolf+1 | 4.31 / 33.2 | 3.75 / 28.9 | 4.03 / 31.1 |
| Wolf+2 | 2.65 / 30.6 | 2.26 / 25.5 | 2.46 / 28.0 |
| Elk+2 | 0.88 / 23.8 | 0.81 / 21.9 | 0.85 / 22.9 |
| Golem+4 | 0.26 / 17.4 | 0.21 / 14.1 | 0.23 / 15.8 |

### 3. Walking legs per team-game: count: mean rounds, steps, excess steps over shortest path

| leg | win | lose | all |
|---|---|---|---|
| camp->to_camp(other) | 48.3: 12.3r 11.4s +2.7x | 44.3: 12.5r 11.6s +2.9x | 46.3: 12.4r 11.5s +2.8x |
| camp->to_camp(same) | 35.2: 3.5r 3.0s +1.6x | 33.2: 3.8r 3.2s +1.8x | 34.2: 3.6r 3.1s +1.7x |
| spawn->to_camp | 21.8: 14.1r 13.4s +1.6x | 22.0: 13.9r 13.3s +1.9x | 21.9: 14.0r 13.3s +1.7x |
| altar->to_camp | 24.0: 14.8r 13.9s +3.2x | 19.7: 15.5r 14.7s +3.5x | 21.8: 15.1r 14.2s +3.3x |
| recall->to_camp | 16.6: 14.8r 15.6s +2.1x | 15.4: 14.9r 15.7s +2.6x | 16.0: 14.9r 15.6s +2.3x |
| fight->then_fight | 12.7: 8.3r 8.1s +4.3x | 14.2: 9.1r 9.0s +5.3x | 13.5: 8.7r 8.6s +4.8x |
| camp->to_altar | 13.8: 8.8r 9.4s +1.5x | 10.4: 9.2r 10.0s +1.7x | 12.1: 9.0r 9.7s +1.6x |
| camp->then_fight | 11.4: 10.3r 10.2s +3.8x | 11.0: 11.4r 11.5s +4.9x | 11.2: 10.8r 10.8s +4.4x |
| recall->to_altar | 10.8: 9.7r 11.6s +0.8x | 9.2: 9.8r 11.7s +1.0x | 10.0: 9.8r 11.7s +0.9x |
| fight->to_camp | 10.6: 10.8r 10.1s +4.3x | 9.3: 11.9r 11.4s +5.3x | 10.0: 11.3r 10.7s +4.7x |
| camp->then_recall | 9.1: 4.4r 4.4s +1.2x | 9.5: 4.6r 4.6s +1.3x | 9.3: 4.5r 4.5s +1.3x |
| fight->then_recall | 5.2: 5.4r 5.6s +1.2x | 5.5: 6.0r 6.0s +1.7x | 5.3: 5.7r 5.8s +1.5x |
| spawn->to_altar | 5.7: 10.4r 10.8s +1.1x | 4.7: 10.2r 10.5s +1.2x | 5.2: 10.3r 10.7s +1.1x |
| altar->then_fight | 4.4: 12.8r 12.5s +3.7x | 3.3: 13.5r 13.5s +4.7x | 3.8: 13.1r 12.9s +4.2x |
| spawn->then_fight | 2.5: 21.7r 21.3s +4.2x | 4.0: 18.6r 18.6s +4.5x | 3.2: 19.8r 19.6s +4.4x |
| spawn->to_spawn | 1.0: 4.0r 3.7s +2.7x | 4.5: 2.8r 2.8s +1.7x | 2.7: 3.0r 3.0s +1.9x |

### 3b. Walking waste per team-game

| side | steps | excess steps | excess % | turn-backs at a group | their excess | other detours | % to-camp legs with nearer avail group (>=5 closer) | ... with >= gems | mean dist to target |
|---|---|---|---|---|---|---|---|---|---|
| win | 2587 | 624 | 24.1 | 11.8 | 187 | 19.5 | 10.3 | 5.7 | 9.7 |
| lose | 2571 | 711 | 27.6 | 12.5 | 201 | 22.0 | 10.3 | 5.8 | 9.7 |
| all | 2579 | 667 | 25.9 | 12.2 | 194 | 20.8 | 10.3 | 5.7 | 9.7 |

### 3c. turn-back group state (%)

| side | ally_on_it | awake | cleared | enemy_on_it | respawning | up_unworked |
|---|---|---|---|---|---|---|
| win | 11.4 | 3.5 | 4.4 | 1.6 | 60.2 | 19.0 |
| lose | 10.5 | 4.1 | 5.1 | 2.2 | 59.5 | 18.6 |
| all | 10.9 | 3.8 | 4.7 | 1.9 | 59.8 | 18.8 |

### 3c. what the turn-back leg ended in (%)

| side | end | then_dead | then_fight | then_recall | then_tp | to_altar | to_camp | to_spawn |
|---|---|---|---|---|---|---|---|---|
| win | 1.1 | 0.6 | 27.3 | 5.7 | 0.4 | 8.8 | 54.3 | 1.9 |
| lose | 1.5 | 1.2 | 31.8 | 7.0 | 0.3 | 7.0 | 48.1 | 3.1 |
| all | 1.3 | 0.9 | 29.6 | 6.4 | 0.3 | 7.9 | 51.1 | 2.5 |

### 3c. target state at to-camp leg start (%)

| side | awake | cleared | respawning | up |
|---|---|---|---|---|
| win | 20.9 | 12.8 | 35.9 | 30.3 |
| lose | 21.0 | 12.9 | 34.7 | 31.4 |
| all | 21.0 | 12.8 | 35.3 | 30.8 |

### 3d. Ally target overlap (% of champion-rounds with a hindsight camp target)

| side | both walking to same group | walking to a group an ally works | co-working |
|---|---|---|---|
| win | 22.3 | 4.8 | 18.4 |
| lose | 22.1 | 4.7 | 18.3 |
| all | 22.2 | 4.7 | 18.3 |

### 4. Banking per team-game

| side | tributes | mean bag | tributes/champ/1000 alive r | steps/tribute | altar-leg steps/tribute | cancel % | not nearest altar % (+steps), multi-altar maps | gems lost to camps | gems lost to champs | carried at end |
|---|---|---|---|---|---|---|---|---|---|---|
| win | 39.0 | 32.8 | 8.49 | 68.2 | 8.9 | 2.4 | 2.7 (+7.0) | 5.8 | 32.7 | 30.9 |
| lose | 30.4 | 24.3 | 6.91 | 87.0 | 9.3 | 2.0 | 2.4 (+6.8) | 4.9 | 78.3 | 91.7 |
| all | 34.7 | 29.0 | 7.71 | 76.4 | 9.1 | 2.2 | 2.6 (+7.0) | 5.3 | 55.5 | 61.3 |

### 4b. Bag at tribute start (% of tributes)

| side | <10 | <20 | <30 | <50 | <100 | <200 | >=200 |
|---|---|---|---|---|---|---|---|
| win | 31.3 | 27.4 | 12.0 | 16.8 | 9.2 | 1.0 | 2.2 |
| lose | 34.5 | 28.7 | 11.7 | 15.6 | 8.2 | 0.5 | 0.9 |
| all | 32.7 | 28.0 | 11.9 | 16.2 | 8.8 | 0.8 | 1.6 |

### 4c. Deaths per team-game

| side | by camps | by champs | kills | camp E | champ E | gems lost camp E | gems lost champ E |
|---|---|---|---|---|---|---|---|
| win | 0.55 | 2.15 | 5.01 | 0.27 | 0.37 | 1.1 | 2.0 |
| lose | 0.76 | 5.34 | 1.98 | 0.42 | 0.66 | 1.9 | 3.8 |
| all | 0.66 | 3.74 | 3.49 | 0.34 | 0.52 | 1.5 | 2.9 |

### 5. Clears (all sides): per team-game, rounds wake->clear, participants, champions damaged, camp dmg taken, dmg per gem won, % of gems won, % stolen, % enemy hit it too, heal recalls within 20r per clear

| type|mode | n/game | rounds | champ work-rounds (clear+capture) | part | n hurt | dmg taken | dmg/gem | gems won % | stolen % | contested % | heal rec % |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Gem cluster|solo | 6.83 | 2.0 | 4.2 | 1.00 | 0.00 | 0 | 0.0 | 105 | 1.5 | 0.9 | 5.3 |
| Gold cluster+1|solo | 6.33 | 5.3 | 5.4 | 1.00 | 0.00 | 0 | 0.0 | 0 | 1.2 | 2.3 | 8.1 |
| Gold cluster|solo | 5.95 | 3.0 | 4.3 | 1.00 | 0.00 | 0 | 0.0 | 0 | 1.1 | 0.8 | 7.2 |
| Wolf|multi | 4.67 | 20.7 | 15.4 | 2.31 | 1.46 | 154 | 39.0 | 99 | 0.7 | 2.3 | 20.1 |
| Wolf|solo | 4.58 | 13.5 | 11.2 | 1.00 | 0.94 | 147 | 37.5 | 98 | 1.0 | 3.3 | 13.8 |
| Gem cluster+3|solo | 3.97 | 7.1 | 8.3 | 1.00 | 0.00 | 0 | 0.0 | 111 | 1.5 | 3.5 | 9.2 |
| Elk+1|multi | 3.39 | 26.6 | 25.2 | 2.68 | 1.83 | 732 | 41.4 | 99 | 0.9 | 3.9 | 48.8 |
| Elk|multi | 3.05 | 24.7 | 23.2 | 2.65 | 1.74 | 653 | 44.4 | 98 | 1.2 | 4.4 | 45.8 |
| Wolf+1|multi | 2.59 | 30.2 | 25.9 | 2.61 | 1.96 | 390 | 50.9 | 99 | 0.6 | 3.2 | 31.5 |
| Gem cluster+3|multi | 2.44 | 6.7 | 8.3 | 2.23 | 0.00 | 0 | 0.0 | 112 | 0.9 | 2.4 | 16.9 |
| Gem cluster+1|solo | 2.27 | 3.8 | 5.7 | 1.00 | 0.00 | 0 | 0.0 | 110 | 2.3 | 2.5 | 8.3 |
| Gem cluster+2|solo | 1.90 | 5.8 | 7.0 | 1.00 | 0.00 | 0 | 0.0 | 111 | 1.9 | 3.6 | 8.5 |
| Gold cluster+2|solo | 1.65 | 7.0 | 6.0 | 1.00 | 0.00 | 0 | 0.0 | 0 | 1.5 | 2.8 | 7.6 |
| Elk+3|multi | 1.63 | 33.9 | 28.9 | 2.76 | 1.96 | 967 | 26.6 | 104 | 1.4 | 8.3 | 55.3 |
| Wolf+2|multi | 1.50 | 37.1 | 31.9 | 2.70 | 2.14 | 625 | 54.8 | 99 | 1.4 | 5.1 | 34.1 |
| Wolf+1|solo | 1.46 | 21.4 | 14.7 | 1.00 | 1.00 | 249 | 33.2 | 100 | 1.3 | 6.5 | 19.1 |
| Elk+1|solo | 1.43 | 23.4 | 13.2 | 1.00 | 1.03 | 513 | 29.8 | 99 | 1.1 | 6.9 | 22.3 |
| Elk|solo | 1.40 | 18.0 | 12.5 | 1.00 | 1.00 | 458 | 31.4 | 97 | 1.4 | 6.4 | 20.8 |
| Gold cluster+1|multi | 1.34 | 16.5 | 6.0 | 2.08 | 0.00 | 0 | 0.0 | 0 | 1.0 | 1.2 | 15.3 |
| Wolf+2|solo | 0.96 | 23.7 | 15.0 | 1.00 | 1.02 | 289 | 26.9 | 100 | 2.0 | 6.5 | 19.5 |
| Gem cluster+2|multi | 0.84 | 7.9 | 7.5 | 2.31 | 0.00 | 0 | 0.0 | 111 | 2.0 | 2.0 | 16.4 |
| Golem+2|multi | 0.77 | 56.3 | 36.4 | 2.90 | 2.31 | 2038 | 51.0 | 100 | 0.9 | 7.3 | 62.0 |

### 5b. Clears per team-game

| side | clears | multi % | stolen | heal recalls after | camp dmg/captured gem | own | mid | enemy |
|---|---|---|---|---|---|---|---|---|
| win | 72.9 | 40.2 | 0.76 | 14.54 | 24.9 | 63.2 | 5.3 | 4.4 |
| lose | 65.2 | 40.4 | 1.14 | 13.30 | 29.6 | 59.8 | 3.2 | 2.2 |
| all | 69.0 | 40.3 | 0.95 | 13.92 | 26.9 | 61.5 | 4.3 | 3.3 |

### 6. Mean tributed gems by round (final value if over)

| side | r200 | r400 | r600 | r800 | r1000 |
|---|---|---|---|---|---|
| win | 99 | 266 | 479 | 672 | 820 |
| lose | 87 | 228 | 382 | 489 | 558 |

Game length rounds: median 958, p25 726, p75 1306; at 2000: 44
Final gap (gems): median 314, p25 97, p75 558
Winner leads for good from round: median 571, p25 320, p75 858; as share of game: median 0.66
Winner leads by >=100 for good from round: median 724 (434 games)
Team A wins 297 / 582

### 6c. Same, rounds 1-300 metrics only (less reverse causality)

| metric | mean W-L | sd | W>L % | W<L % | effect |
|---|---|---|---|---|---|
| capE_gems | 26.81 | 84.19 | 63.6 | 30.1 | 0.32 |
| capE_gems_own | 11.88 | 38.49 | 56.7 | 32.0 | 0.31 |
| tbE_dead | -24.84 | 82.68 | 17.9 | 37.6 | 0.30 |
| deathE_champ | -0.30 | 1.17 | 11.7 | 24.6 | 0.25 |
| tbE_tribute | 2.84 | 11.41 | 51.9 | 34.7 | 0.25 |
| tbE_camp | 9.73 | 44.89 | 59.8 | 38.5 | 0.22 |
| capE_gems_enemy | 3.91 | 21.22 | 21.3 | 10.1 | 0.18 |
| capE_gems_mid | 11.03 | 59.95 | 17.2 | 6.4 | 0.18 |
| deathE_camp | -0.15 | 0.91 | 7.7 | 15.1 | 0.16 |
| tbE_recall | 3.56 | 24.89 | 57.6 | 40.0 | 0.14 |
| recE_shop | 0.30 | 2.37 | 43.5 | 36.3 | 0.13 |
| gemslostE_champ | -1.84 | 16.30 | 5.5 | 10.1 | 0.11 |
| tbE_hold | 2.64 | 24.29 | 55.2 | 39.5 | 0.11 |
| gemslostE_camp | -0.76 | 8.87 | 3.1 | 5.8 | 0.09 |
| recE_bank | 0.16 | 1.88 | 37.1 | 28.0 | 0.08 |
| tbE_fight | 0.45 | 6.75 | 28.2 | 24.7 | 0.07 |
| tbE_idle | 1.50 | 28.66 | 50.5 | 47.6 | 0.05 |
| recE_other | 0.07 | 1.59 | 31.4 | 27.3 | 0.04 |
| tbE_walk_gems | 2.57 | 69.66 | 47.6 | 48.8 | 0.04 |
| tbE_spawn | 0.33 | 10.21 | 42.8 | 44.0 | 0.03 |

### 6d. Mean winner-minus-loser gem gap, decomposed

| term | gems/game |
|---|---|
| tributed | 371.5 |
| captured own | 72.1 |
| captured mid | 107.7 |
| captured enemy | 40.6 |
|   of which monolith | 21.5 |
| kill gems | 45.0 |
| minus lost to camps | -0.9 |
| minus lost to champs | 45.6 |
| minus carried at end | 60.8 |

Monolith maps: 141 games; any monolith capture in 61; winner captured more 39, loser more 6

### 6b. Winner-minus-loser per game, ranked by |mean|/sd (E = rounds 1-300 only; tb_ in champion-rounds)

| metric | mean W-L | sd | W>L % | W<L % | effect |
|---|---|---|---|---|---|
| tb_tribute | 50.68 | 53.08 | 94.2 | 5.0 | 0.95 |
| cap_gems | 220.38 | 279.39 | 85.4 | 13.2 | 0.79 |
| trib_start | 8.66 | 11.11 | 82.6 | 11.2 | 0.78 |
| trib_done | 8.37 | 10.84 | 84.9 | 11.2 | 0.77 |
| alt_trips | 6.17 | 8.78 | 73.7 | 14.6 | 0.70 |
| gold_earned | 1556.01 | 2260.39 | 85.6 | 14.3 | 0.69 |
| tb_dead | -191.73 | 291.42 | 13.4 | 68.7 | 0.66 |
| death_champ | -3.18 | 4.84 | 9.5 | 64.1 | 0.66 |
| kills | 3.03 | 4.65 | 63.9 | 9.5 | 0.65 |
| cap_gold | 968.22 | 1639.43 | 77.8 | 20.1 | 0.59 |
| cap_gems_own | 72.08 | 122.19 | 74.7 | 20.1 | 0.59 |
| cap_n | 8.58 | 14.89 | 74.7 | 18.9 | 0.58 |
| clear_work_rounds | 100.14 | 178.17 | 73.0 | 26.6 | 0.56 |
| clear_n | 7.72 | 14.35 | 72.0 | 22.2 | 0.54 |
| steps_to_altar | 60.20 | 113.73 | 74.2 | 24.6 | 0.53 |
| cap_gems_enemy | 40.58 | 81.84 | 50.3 | 12.7 | 0.50 |
| tb_camp | 65.66 | 139.81 | 68.4 | 30.9 | 0.47 |
| cap_gems_mid | 107.72 | 239.65 | 33.2 | 4.6 | 0.45 |
| cap_n_own | 3.81 | 8.53 | 65.8 | 25.6 | 0.45 |
| tocamp_dist | 112.39 | 257.03 | 67.2 | 32.5 | 0.44 |
| cap_n_enemy | 2.38 | 5.50 | 50.5 | 14.4 | 0.43 |
| clear_n_enemy | 2.17 | 5.21 | 50.2 | 15.1 | 0.42 |
| tgt_rounds | 185.05 | 447.13 | 65.8 | 34.0 | 0.41 |
| champ_dmg_dealt | 3763.04 | 9116.29 | 60.8 | 25.8 | 0.41 |
| clear_n_own | 3.41 | 8.35 | 63.9 | 28.5 | 0.41 |
| rec_shop_done | 2.65 | 6.52 | 60.0 | 29.9 | 0.41 |
| rec_shop | 2.65 | 6.52 | 60.0 | 29.9 | 0.41 |
| walk_excess | -87.20 | 218.18 | 33.7 | 66.0 | 0.40 |
| recr_shop | 13.73 | 35.77 | 60.5 | 32.1 | 0.38 |
| rec_done | 3.47 | 9.13 | 58.9 | 34.7 | 0.38 |
| clear_multi | 2.98 | 7.88 | 59.6 | 31.4 | 0.38 |
| carried_max | 52.24 | 140.60 | 57.9 | 24.2 | 0.37 |
| cap_n_mid | 2.39 | 6.52 | 32.8 | 5.2 | 0.37 |
| detour_other_excess | -69.74 | 194.34 | 33.7 | 64.8 | 0.36 |
| gemslost_champ | -45.64 | 130.49 | 12.4 | 43.3 | 0.35 |
| kill_gems | 45.04 | 129.36 | 43.3 | 12.4 | 0.35 |
| clear_n_mid | 2.15 | 6.16 | 31.3 | 6.5 | 0.35 |
| carried_end | -60.76 | 176.74 | 21.0 | 59.5 | 0.34 |
| capE_gems | 26.81 | 84.19 | 63.6 | 30.1 | 0.32 |
| capE_gems_own | 11.88 | 38.49 | 56.7 | 32.0 | 0.31 |
| tb_recall | 17.04 | 55.31 | 59.8 | 38.8 | 0.31 |
| tbE_dead | -24.84 | 82.68 | 17.9 | 37.6 | 0.30 |
| rec_n | 3.17 | 10.72 | 57.6 | 36.3 | 0.30 |
| detour_other | -2.44 | 8.37 | 32.0 | 59.5 | 0.29 |
| camp_dmg_taken | 1829.39 | 6318.80 | 55.5 | 40.4 | 0.29 |
