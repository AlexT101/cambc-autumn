import sys,glob,collections,multiprocessing as mp
sys.path.insert(0,sys.argv[1]); from sumd import load
ch=lambda a,b: max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def work(gf):
    try: hdr,g,br=load(gf)
    except Exception: return []
    dmg=g.champ_damage; out=[]
    byv=collections.defaultdict(list)
    for d in dmg: byv[d[3]].append(d)
    seen=set()
    for c in g.team_of:
        a=g.ch(c)['alive']
        for i in range(1,len(a)):
            if not(a[i-1] and not a[i]): continue
            r=i+1; t=g.team_of[c]
            if g.name_of[c] in ('Issac','Cassi') and (r,t) in seen: continue
            seen.add((r,t))
            hs=[d for d in byv[c] if r-40<d[1]<=r]
            if not hs or hs[-1][1]<r-3: continue
            s=hs[-1][1]
            for d in reversed(hs):
                if s-d[1]>3: break
                s=d[1]
            if r-s<3: continue
            k=hs[-1][2]
            first_k=min(d[1] for d in hs if d[2]==k and d[1]>=s)
            khp=g.ch(k)['hp'][max(0,s-2)]/g.ch(k)['maxHp'][max(0,s-2)]
            # did victim damage killer before killer joined? 
            vk=sum(d[4] for d in dmg if d[2]==c and d[3]==k and s<=d[1]<=r)
            # opening duel partner: first attacker
            first=[d for d in hs if d[1]>=s][0][2]
            out.append((t==g.winner, first_k-s>=2, khp, k==first, r-s))
    return out
if __name__=='__main__':
    files=[f for d in sys.argv[2:4] for f in glob.glob(d+'/games/*.txt') if not f.endswith('.fights.txt')]
    with mp.Pool(32) as p: res=[x for l in p.map(work,files) for x in l]
    print('deaths dur>=3:',len(res))
    print(' killer joined >=2 rounds after first hit:',sum(x[1] for x in res))
    print(' killer was not the first attacker:',sum(not x[3] for x in res))
    print(' killer joined late and hp>70% at start:',sum(1 for x in res if x[1] and x[2]>0.7))
