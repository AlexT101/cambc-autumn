import pickle, collections
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits2.pkl', 'rb'))
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
# wake outcome: visits that woke the group
wv = [v for v in allv if v['woke']]
solo = [v for v in wv if not v['mates']]
print('waking visits', len(wv), 'cleared frac %.2f' % (sum(v['cleared'] for v in wv)/len(wv)), '| solo whole visit', len(solo), 'cleared %.2f' % (sum(v['cleared'] for v in solo)/len(solo)), '| with mates cleared %.2f' % (sum(v['cleared'] for v in wv if v['mates'])/max(1,len([v for v in wv if v['mates']]))))
# WAKE allies4 vs outcome
for name,(fs,wk,D,wh) in games.items():
    pass
res = collections.Counter()
for v in wv:
    fs, wk, D, wh = games[v['game']]
    for r,h,g,k,l in wk:
        if h == v['c'] and g == 'g%d'%v['G'] and v['r0']-1 <= r <= v['r0']:
            a4 = int(k['allies4']) > 0
            hp = float(k['hp'].split('/')[0]); over = float(k['alone']) > hp
            res[(a4, over, v['cleared'])] += 1
print('wake: (allies within reach+4, alone>hp, cleared) ->', sorted(res.items()))
for g, r0 in (('00stampede', 692), ('gen-continent-600102800', 135)):
    for v in allv:
        if v['game'] == g and v['r0'] <= r0 <= v['r1'] + 2:
            k = v['choice'][1][1] if 'choice' in v else {}
            print(g, f"r{v['r0']}-{v['r1']}", v['name'], 'G%d'%v['G'], v['types'][:6], 'cleared' if v['cleared'] else 'chip', 'dealt %.0f taken %.0f hp0 %.0f/%.0f hp1 %s mates %s foes %s woke %d' % (v['dealt'], v['taken'], v['hp0'], v['max'], v['hp1'], v['mates'], v['foes'], v['woke']), 'choice', v['choice'][0] if 'choice' in v else None, k.get('br'), k.get('rsn'), 'alone', k.get('alone'), 'spare', k.get('spare'), 'hp', k.get('hp'), 'line', k.get('line'))
