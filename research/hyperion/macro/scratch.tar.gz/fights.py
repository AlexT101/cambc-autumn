import re,sys,collections
c=collections.Counter(); kills=collections.Counter()
for d in sys.argv[1:]:
  for l in open(d+'/episodes/fights.txt'):
    if not re.search(r'r\d+ \[astraeus\] ',l): continue  # team A view only, avoid double
    m=re.search(r'present (\d+)v(\d+)',l); k=re.search(r'kills (\d+)-(\d+)',l)
    if not m or not k: continue
    a,b=int(m.group(1)),int(m.group(2)); ka,kb=int(k.group(1)),int(k.group(2))
    if ka+kb==0: continue
    diff=a-b
    key='more' if diff>0 else 'less' if diff<0 else 'even'
    c[key]+=1; kills[(key,'own')]+=ka; kills[(key,'opp')]+=kb
print(c, kills)
