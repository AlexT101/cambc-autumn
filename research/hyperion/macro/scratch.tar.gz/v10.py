import pickle, collections, statistics as st
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
T = collections.defaultdict(lambda: [0, 0, 0, 0, [], []])
for name, (fs, wk, D, wh) in games.items():
    for r, h, g, k, l in fs:
        key = k['br'] + '/' + k['rsn']
        hp, mx = map(float, k['hp'].split('/')); A = float(k['alone']); S = hp - float(k['line']) * mx
        t = T[key]; t[0] += 1; t[1] += k['over'] == '1'; t[2] += A > S; t[3] += A > hp
        if A > S: t[4].append(A / max(S, 1)); t[5].append(int(k['engaged']))
print(f"{'branch/reason':16s} {'turns':>6s} {'A>spare_health':>14s} {'A>real spare':>12s} {'A>hp':>6s} {'engaged|A>S':>11s}")
for key, t in sorted(T.items(), key=lambda x: -x[1][2]):
    if t[0] < 20: continue
    print(f"{key:16s} {t[0]:6d} {t[1]:14d} {t[2]:12d} {t[3]:6d} {sum(t[5])/max(len(t[5]),1):11.2f}")
