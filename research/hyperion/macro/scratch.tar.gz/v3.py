import pickle, collections, statistics as st
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits.pkl', 'rb'))
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
def key(v):
    return (v['fs'][2]['br'] + '/' + v['fs'][2]['rsn']) if v['fs'] and v['fs'][1] == v['G'] else 'x'
# calibration: solo cleared visits starting on fresh group (woke)
cal = [v for v in allv if v['cleared'] and not v['mates'] and not v['foes'] and v['woke'] and v['fs'] and v['fs'][1] == v['G']]
print('calibration solo woke+cleared n', len(cal), 'pred alone sum', sum(float(v['fs'][2]['alone']) for v in cal), 'taken sum', sum(v['taken'] for v in cal))
for v in cal[:8]: print('  ', v['game'][:22], v['name'], v['types'], 'pred', v['fs'][2]['alone'], 'taken', v['taken'], 'dealt', v['dealt'])
# why chips end
why = collections.Counter(); whyb = collections.defaultdict(collections.Counter)
for v in allv:
    if v['cleared']: continue
    fs, wk, D, wh = games[v['game']]
    c = v['c']; r1 = v['r1']
    reason = None
    if v['died']: reason = 'died'
    else:
        for r in range(r1 - 1, r1 + 3):
            if r in wh[c]: reason = 'WH-' + wh[c][r]; break
    if not reason:
        d = D[c].get(r1 + 1) or D[c].get(r1 + 2)
        if d:
            reason = 'dec=' + d[0] + (' fg-changed' if d[1] != v['G'] else ' fg-same')
        else: reason = '?'
    why[reason] += 1; whyb[key(v)][reason] += 1
print('chip end reasons', why.most_common())
for k in ['best/a', 'shared/c', 'help/c', 'passing/?']:
    print(' ', k, whyb[k].most_common(6))
