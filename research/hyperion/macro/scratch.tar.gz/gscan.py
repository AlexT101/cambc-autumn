import json,zipfile,re,collections,sys
from concurrent.futures import ProcessPoolExecutor
idx=json.load(open('/home/ubuntu/cambc-autumn/replays/.analysis/index.json'))['games']
rows={}
for r in idx:
    if 'm3-mirror' in r['source'] and r['dir'] not in rows: rows[r['dir']]=r
def f(r):
    z=zipfile.ZipFile('/home/ubuntu/cambc-autumn/'+r['source']); out=[]
    for t in 'ab':
        raw=z.read(f'team-{t}.stdout')
        D=re.findall(rb'^[\s\0]*D \d+ \d+ (\S)',raw,re.M)
        c=collections.Counter(D); n=len(D)
        out.append((c[b'G']/n, c[b'B']/n))
    return r['source'], r['map'], r['rounds'], r['winner'], r['gems'], out
if __name__=='__main__':
  with ProcessPoolExecutor(90) as ex: res=list(ex.map(f, rows.values()))
  hiG=[x for x in res if max(o[0] for o in x[5])>0.25]
  noB=[x for x in res if min(o[1] for o in x[5])<0.01]
  print('games',len(res),'G>25% one side',len(hiG)); 
  for x in sorted(hiG,key=lambda x:-max(o[0] for o in x[5]))[:10]: print(' ',x[1],x[2],x[4],[f'{o[0]:.2f}' for o in x[5]], x[0])
  print('B<1% one side',len(noB))
  for x in noB[:10]: print(' ',x[1],x[2],x[4],[f'{o[1]:.3f}' for o in x[5]])
  