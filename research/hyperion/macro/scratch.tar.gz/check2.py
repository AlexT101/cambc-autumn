import sys, zipfile, glob, os, re, collections
for f in sorted(glob.glob(os.path.join(sys.argv[1], '*.repl26a'))):
    side = re.search(r'-(12|21)\.repl26a$', f).group(1)
    t = 'team-a.stdout' if side == '12' else 'team-b.stdout'
    txt = zipfile.ZipFile(f).read(t).decode(errors='replace')
    posts = {}; c = collections.Counter(); layout = None; ok = bad = 0; br = collections.Counter(); caps_tx = set(); caps_rx = set()
    for line in txt.splitlines():
        p = line.split()
        if not p: continue
        if p[0] == 'DPOST': posts[(int(p[1]), int(p[2]))] = (int(p[3]), int(p[4]), int(p[5]))
        if p[0] == 'LAYOUT' and not layout: layout = ' '.join(p[1:])
        if p[0] == 'CAPTX': caps_tx.add((p[2], p[3]))
        if p[0] == 'CAPRX': caps_rx.add((p[2], p[3]))
        if p[0] == 'D' and len(p) >= 4: br[p[3]] += 1
        if 'error' in line: c['err'] += 1
        c[p[0]] += 1
    for line in txt.splitlines():
        p = line.split()
        if p and p[0] == 'ASSIST':
            r, ally, s, x, y, rr = int(p[1]), int(p[3]), int(p[4]), int(p[6]), int(p[7]), int(p[8])
            px = posts.get((rr, ally))
            # with coarsening the decoded tile is the cell's: compare by cell
            if px and px[2] == s and abs(px[0] - x) <= 1 and abs(px[1] - y) <= 1: ok += 1
            else: bad += 1
    print(os.path.basename(f), '|', layout)
    print('   DPOST', c['DPOST'], 'ASSIST ok/bad', ok, bad, 'Y', br['Y'], 'HELP', c['HELP'], 'CAPTX', c['CAPTX'], 'CAPRX', c['CAPRX'],
          'caps posted', len(caps_tx), 'read', len(caps_rx), 'posted&read', len(caps_tx & caps_rx), 'SECTX', c['SECTX'], 'err', c['err'], 'D', sum(br.values()))
