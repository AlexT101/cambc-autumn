import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
act=collections.Counter(); nd=[]; side=collections.Counter(); hp0=[]; killer_alone=collections.Counter()
tot=0
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    ch=R['champions']; byid={c['id']:c for c in ch}
    ri={r:i for i,r in enumerate(R['round'])}
    campatt=collections.defaultdict(set)
    for e in ev:
        if e['k'] in('attack','cast') and 'a' in e and e.get('cdmg'): campatt[e['a']].add(e['r'])
    sp=mp['spawn']
    for e in ev:
        if e['k']!='death' or e.get('linked') is not None or e.get('camp') is not None: continue
        v=byid[e['v']]; r=e['r']; i=ri.get(r-1,0)
        x,y=e['at']
        # nearest ally distance 10 rounds before
        j=ri.get(r-10,0)
        if v['x'][j] is None: continue
        vx,vy=v['x'][j],v['y'][j]
        def near(i,x,y,team):
            dm=99
            for o in ch:
                if o is v or o['team']!=team or not o['alive'][i] or o['x'][i] is None: continue
                dm=min(dm,max(abs(o['x'][i]-x),abs(o['y'][i]-y)))
            return dm
        da=near(i,x,y,v['team'])
        tot+=1
        if da<=6: continue
        nd.append(min(da,30))
        a10=sum(1 for rr in range(r-10,r) if rr in campatt[v['id']])
        carry=v['gems'][j]>0
        act[('campwork' if a10>=3 else 'other', 'carry' if carry else 'empty')]+=1
        def dsp(t):
            s=sp[t]; return max(max(s['minX']-x,0,x-s['maxX']),max(s['minY']-y,0,y-s['maxY']))
        own=dsp(v['team']); oth=dsp(1-v['team'])
        side['own' if own<oth*0.8 else 'enemy' if oth<own*0.8 else 'mid']+=1
        k=byid.get(e.get('by'))
        if k: killer_alone[near(i,k['x'][i] or 0,k['y'][i] or 0,k['team'])<=6]+=1
        hp0.append(v['hp'][j]/v['maxHp'][j])
print('champ-kill deaths',tot,'alone (no ally within 6):',len(nd))
print('nearest ally dist quantiles', st.quantiles(nd,n=4))
print(act); print(side); print('killer had ally within 6:',killer_alone)
print('victim hp frac 10 rounds before: quartiles', [round(q,2) for q in st.quantiles(hp0,n=4)])
