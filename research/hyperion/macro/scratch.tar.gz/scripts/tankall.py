# Over a batch: camp hits on our champions split by the formation each was in the round before.
import gzip, json, glob, os, sys, collections, re, zipfile
batch, an = sys.argv[1], sys.argv[2]
C = collections.Counter(); W = collections.Counter()
for meta_p in glob.glob(an + '/*/meta.json'):
    d = os.path.dirname(meta_p); meta = json.load(open(meta_p))
    team = next((i for i, t in enumerate(meta['teams']) if t.get('bot') == 0), 0)
    src = meta['source']
    z = zipfile.ZipFile(src if os.path.isabs(src) else os.path.join('/home/ubuntu/cambc-autumn', src))
    out = z.read('team-%s.stdout' % 'ab'[team]).decode(errors='ignore').replace('\0', '')
    tank = collections.defaultdict(dict); dec = {}
    for l in out.splitlines():
        m = re.match(r'TANK (\d+) (\d+) (\d+) (\d+) ([ts])$', l)
        if m: tank[int(m.group(1))][int(m.group(2))] = m.group(5)
        m = re.match(r'D (\d+) (\d+) (\S)', l)
        if m: dec[(int(m.group(1)), int(m.group(2)))] = m.group(3)
    ours = {c['id'] for c in meta['champions'] if c['team'] == team}
    mp = json.load(open(os.path.join(d, meta['mapFile'])))
    cg = {c['id']: c['group'] for c in mp['camps']}
    evs = [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')]
    work = collections.defaultdict(set)
    for e in evs:
        if e['k'] in ('attack', 'cast') and e.get('a') in ours:
            for c in ([e['camp']] if 'camp' in e else []) + [c for c, a in e.get('cdmg') or []]: work[(cg[c], e['r'])].add(e['a'])
    for e in evs:
        if e['k'] != 'camp_attack' or e.get('tgt') not in ours: continue
        g = cg[e['camp']]
        others = set().union(*[work[(g, x)] for x in range(e['r'] - 2, e['r'] + 3)]) - {e['tgt']}
        sh = 'shared' if others else 'solo'
        C[sh + '_' + tank.get(e['r'] - 1, {}).get(e['tgt'], '-')] += 1
        role = tank.get(e['r'] - 1, {}).get(e['tgt'], '-')
        C[role] += 1; W[role] += e['dmg']
        if role == '-': C['dec_' + dec.get((e['r'] - 1, e['tgt']), '?')] += 1
print({k: v for k, v in C.items()}); print({k: round(v) for k, v in W.items()})
