import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
tot=collections.Counter(); legs=collections.defaultdict(list)
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    n=len(R['round'])
    ch=R['champions']
    camp_att=set(); champ_att=set()
    for e in ev:
        if e['k'] in('attack','cast') and 'a' in e:
            if e.get('camp') is not None or e.get('cdmg'): camp_att.add((e['a'],e['r']))
            if e.get('dmg'): champ_att.add((e['a'],e['r']))
    captile=set(tuple(t) for g in mp['groups'] for t in g['tiles'])
    sp=mp['spawn']
    for c in ch:
        t=c['team']; s=sp[t]
        lab=[]
        for i in range(n):
            r=R['round'][i]
            if not c['alive'][i] or c['x'][i] is None: lab.append('dead'); continue
            x,y=c['x'][i],c['y'][i]
            if s['minX']<=x<=s['maxX'] and s['minY']<=y<=s['maxY']: lab.append('spawn'); continue
            if (c['id'],r) in champ_att: lab.append('fight'); continue
            if (c['id'],r) in camp_att: lab.append('camp'); continue
            if c['chan'][i]==2: lab.append('tribute'); continue
            if c['chan'][i]==3: lab.append('teleport'); continue
            moved = i>0 and c['x'][i-1] is not None and (c['x'][i-1],c['y'][i-1])!=(x,y)
            if moved: lab.append('W'+('c' if c['gems'][i]>0 else 'e')); continue
            if c['chan'][i]==1 and i>0 and c['chan'][i-1]==1 and c['chanT'][i]<c['chanT'][i-1]: lab.append('recall'); continue
            if (x,y) in captile: lab.append('hold'); continue
            lab.append('still')
        # walking runs -> next anchor
        i=0
        while i<n:
            if lab[i].startswith('W'):
                j=i
                while j<n and (lab[j].startswith('W') or lab[j]=='still'): j+=1
                nxt=lab[j] if j<n else 'end'
                prev=lab[i-1] if i>0 else 'start'
                kind=lab[i]
                tot[(kind,prev,nxt)]+=j-i
                legs[(kind,nxt)].append(j-i)
                i=j
            else: i+=1
T=sum(tot.values())
print('walking+still-in-walk rounds by (carry,prev,next):')
for k,v in tot.most_common(25): print(k, round(v/T,3))
for k,v in sorted(legs.items(), key=lambda kv:-sum(kv[1]))[:12]: print(k, 'n',len(v),'mean',round(st.mean(v),1),'median',st.median(v))
