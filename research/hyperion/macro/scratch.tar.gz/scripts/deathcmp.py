import json,gzip,sys,os,collections
root=sys.argv[1]; cand=sys.argv[2]
C=[collections.Counter(),collections.Counter()]; n=0
for d in os.listdir(root):
    p=os.path.join(root,d)
    if not os.path.exists(p+'/meta.json'): continue
    m=json.load(open(p+'/meta.json'))
    names=[t.get('name','') for t in m['teams']]
    ci=0 if cand in names[0] else 1 if cand in names[1] else None
    if ci is None: continue
    n+=1
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    R=json.load(gzip.open(p+'/rounds.json.gz')); ri={r:i for i,r in enumerate(R['round'])}
    ch=R['champions']; byid={c['id']:c for c in ch}
    sp=mp['spawn']
    for e in (json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')):
        if e['k']!='death' or e.get('linked') is not None: continue
        v=byid[e['v']]; k=0 if v['team']==ci else 1
        x,y=e['at']; i=ri.get(e['r']-1,0); j=ri.get(e['r']-8,0)
        hp8=v['hp'][j]/v['maxHp'][j] if v['hp'][j] else 0
        def dsp(t):
            s=sp[t]; return max(max(s['minX']-x,0,x-s['maxX']),max(s['minY']-y,0,y-s['maxY']))
        own=dsp(v['team']); oth=dsp(1-v['team'])
        side='own' if own<oth*0.8 else 'enemy' if oth<own*0.8 else 'mid'
        al=sum(1 for o in ch if o is not v and o['team']==v['team'] and o['alive'][i] and o['x'][i] is not None and max(abs(o['x'][i]-x),abs(o['y'][i]-y))<=6)
        cause='camp' if e.get('camp') is not None else 'champ'
        C[k][('cause',cause)]+=1; C[k][('side',side)]+=1
        C[k][('hp8', '<35' if hp8<0.35 else '35-60' if hp8<0.6 else '60+')]+=1
        C[k][('allies6', min(al,2))]+=1
        C[k][('bag', '0' if e.get('gems',0)==0 else '1-20' if e['gems']<=20 else '21+')]+=1
keys=sorted(set(C[0])|set(C[1]))
print('per game: cand vs ref deaths')
for kk in keys: print(kk, round(C[0][kk]/n,2), round(C[1][kk]/n,2))
