import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
tot=collections.Counter(); gu=collections.Counter()
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    rid={r:i for i,r in enumerate(R['round'])}
    n=len(R['round'])
    ch=R['champions']; idx={c['id']:k for k,c in enumerate(ch)}
    camp_att=set(); champ_att=set()
    for e in ev:
        if e['k'] in('attack','cast') and 'a' in e:
            if e.get('camp') is not None or e.get('cdmg'): camp_att.add((e['a'],e['r']))
            if e.get('dmg'): champ_att.add((e['a'],e['r']))
    captile=set()
    for g in mp['groups']:
        for t in g['tiles']: captile.add(tuple(t))
    sp=mp['spawn']
    for c in ch:
        t=c['team']; s=sp[t]
        for i in range(1,n):
            r=R['round'][i]
            if not c['alive'][i] or c['x'][i] is None: tot['dead']+=1; continue
            x,y=c['x'][i],c['y'][i]
            if s['minX']<=x<=s['maxX'] and s['minY']<=y<=s['maxY']: tot['spawn']+=1; continue
            ch_=c['chan'][i]
            if (c['id'],r) in champ_att: tot['fight']+=1; continue
            if (c['id'],r) in camp_att: tot['camp_attack']+=1; continue
            if ch_==2: tot['tribute']+=1; continue
            if ch_==3: tot['teleport']+=1; continue
            moved = c['x'][i-1] is not None and (c['x'][i-1],c['y'][i-1])!=(x,y)
            if moved:
                tot['walk_carry' if c['gems'][i]>0 else 'walk_empty']+=1; continue
            if (x,y) in captile: tot['on_captile_still']+=1; continue
            tot['still_other']+=1
    # group utilization
    gst={}
    rows=R['groups']; cols=R['groupCols']
    cur={}
    byr=collections.defaultdict(list)
    for row in rows: byr[row[0]].append(row)
    for i,r in enumerate(R['round']):
        for row in byr.get(r,[]): cur[row[1]]=row
        for g,row in cur.items():
            gu[('state',row[2])]+=1
            if row[2]==1: gu[('awake',row[6])]+=1
T=sum(tot.values())
for k,v in tot.most_common(): print(f"{k:20s} {v/T:.3f}")
G=sum(v for k,v in gu.items() if k[0]=='state')
for k,v in sorted(gu.items()): print(k, round(v/G,3))
