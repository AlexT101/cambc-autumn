import gzip, json, glob, os, sys, collections, re, zipfile
an = sys.argv[1]
C = collections.Counter()
for meta_p in glob.glob(an + '/*/meta.json'):
    d = os.path.dirname(meta_p); meta = json.load(open(meta_p))
    team = next((i for i, t in enumerate(meta['teams']) if t.get('bot') == 0), 0)
    src = meta['source']
    z = zipfile.ZipFile(src if os.path.isabs(src) else os.path.join('/home/ubuntu/cambc-autumn', src))
    out = z.read('team-%s.stdout' % 'ab'[team]).decode(errors='ignore').replace('\0', '')
    tank = collections.defaultdict(dict); dec = {}; td = {}
    for l in out.splitlines():
        m = re.match(r'TANK (\d+) (\d+) (\d+) (\d+) ([ts])$', l)
        if m: tank[int(m.group(1))][int(m.group(2))] = m.group(5)
        m = re.match(r'D (\d+) (\d+) (\S) (-?\d+) (-?\d+)', l)
        if m: dec[(int(m.group(1)), int(m.group(2)))] = (m.group(3), int(m.group(4)), int(m.group(5)))
        m = re.match(r'TANKD (\d+) (\d+) (\d+) (.*)', l)
        if m: td[(int(m.group(1)), int(m.group(2)))] = (int(m.group(3)), m.group(4))
    ours = {c['id'] for c in meta['champions'] if c['team'] == team}
    mp = json.load(open(os.path.join(d, meta['mapFile'])))
    cg = {c['id']: c['group'] for c in mp['camps']}
    evs = [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')]
    work = collections.defaultdict(set)
    for e in evs:
        if e['k'] in ('attack', 'cast') and e.get('a') in ours:
            for c in ([e['camp']] if 'camp' in e else []) + [c for c, a in e.get('cdmg') or []]: work[(cg[c], e['r'])].add(e['a'])
    for e in evs:
        if e['k'] != 'camp_attack' or e.get('tgt') not in ours: continue
        r, a = e['r'], e['tgt']; g = cg[e['camp']]
        others = set().union(*[work[(g, x)] for x in range(r - 2, r + 3)]) - {a}
        if not others or a in tank.get(r - 1, {}): continue
        dd = dec.get((r - 1, a), ('?', -9, -9))
        if dd[0] != 'F': C['dec ' + dd[0]] += 1; continue
        t = td.get((r - 1, a))
        if dd[1] != g: C['F farm_group differs'] += 1
        elif not t: C['F no TANKD'] += 1
        else:
            fields = re.findall(r'(\d+):(\d)(\d)(\d)', t[1])
            selfw = [w for h, al, v, w in fields if int(h) == a]
            otherw = [(v, w) for h, al, v, w in fields if int(h) != a and w == '1']
            if selfw and selfw[0] == '0': C['F self not working'] += 1
            elif not otherw:
                C['F no ally working'] += 1
                det = re.findall(r'(\d+):(\d)(\d)(\d) c(-?\d+) e(\d+) d(-?\d+)', t[1])
                for h, al, v, w, cl, et, dist in det:
                    if int(h) in others:
                        C[('  other', 'vis' if v == '1' else 'unseen', 'claim g' if int(cl) == g else 'claim none' if cl == '-1' else 'claim other', 'd' + dist if v == '1' else 'e' + et)] += 1
            elif not any(v == '1' for v, w in otherw): C['F allies unseen'] += 1
            else: C['F tank unseen?'] += 1
for k, v in C.most_common(): print(k, v)
