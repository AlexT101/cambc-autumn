import json,os,gzip,statistics as st,collections
root='ana'
GEM={'Wolf':4,'Elk':15,'Golem':36,'Gem cluster':7,'Gold cluster':0,'Monolith':200}
RES={'Wolf':40,'Elk':60,'Golem':80,'Gem cluster':50,'Gold cluster':50,'Monolith':150}
HP={'Wolf':1350,'Elk':2400,'Golem':5000,'Gem cluster':120,'Gold cluster':120,'Monolith':20000}
rows=collections.defaultdict(lambda:[0,0,0]); n=0; tot=[0,0]
for d in os.listdir(root):
    p=os.path.join(root,d)
    if not os.path.exists(p+'/meta.json'): continue
    n+=1
    m=json.load(open(p+'/meta.json'))
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    R=m['result']['rounds']
    got=collections.Counter()
    for e in (json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')):
        if e['k']=='capture': got[e['g']]+=sum(s[1] for s in e['shares'])
    for g in mp['groups']:
        gems=sum(GEM[t] for t in g['types']); res=max(RES[t] for t in g['types']); hp=sum(HP[t] for t in g['types'])
        if 'Monolith' in g['types']: k=('mono',)
        else:
            k=('mid' if g['side']==-1 else 'side', '<15' if gems<15 else '15-29' if gems<30 else '30-59' if gems<60 else '60+', 'gems/khp<10' if gems/hp*1000<10 else 'gems/khp>=10')
        cap=gems/(res+7)*R
        rows[k][0]+=cap; rows[k][1]+=got[g['id']]; rows[k][2]+=1; tot[0]+=cap; tot[1]+=got[g['id']]
for k,v in sorted(rows.items()): print(k, 'groups/game %.2f'%(v[2]/n), 'cap %.0f'%(v[0]/n), 'got %.0f'%(v[1]/n), 'util %.2f'%(v[1]/max(1,v[0])))
print('total cap/game',tot[0]/n,'got',tot[1]/n)
