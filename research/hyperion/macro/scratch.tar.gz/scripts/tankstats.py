# Shared camp clears in extracted batch games, for one bot (by results.json bot index).
import gzip, json, os, sys, glob, collections
root = sys.argv[1]; bot = int(sys.argv[2]) if len(sys.argv) > 2 else 0
an = sys.argv[3] if len(sys.argv) > 3 else None
STRIKERS = {'Wolf', 'Elk', 'Golem'}
tot = collections.Counter(); per_type = collections.defaultdict(collections.Counter)
games = 0
for meta_p in glob.glob(os.path.join(root, '*', 'meta.json')):
    d = os.path.dirname(meta_p)
    meta = json.load(open(meta_p))
    team = next((i for i, t in enumerate(meta['teams']) if t.get('bot') == bot), None)
    if team is None: continue
    games += 1
    mp = json.load(open(os.path.join(d, meta['mapFile'])))
    camp_group = {c['id']: c['group'] for c in mp['camps']}
    camp_type = {c['id']: c['type'] for c in mp['camps']}
    gtypes = collections.defaultdict(set)
    for c in mp['camps']: gtypes[c['group']].add(c['type'])
    ours = {c['id'] for c in meta['champions'] if c['team'] == team}
    rounds = json.load(gzip.open(os.path.join(d, 'rounds.json.gz')))
    ridx = {r: i for i, r in enumerate(rounds['round'])}
    chs = {c['id']: c for c in rounds['champions']}
    ev = [json.loads(l) for l in gzip.open(os.path.join(d, 'events.jsonl.gz'), 'rt')]
    work = collections.defaultdict(list)   # g -> [(r, champ)] our hits
    hits = collections.defaultdict(list)   # g -> [(r, champ, dmg)]
    recalls = []
    start = collections.defaultdict(int)
    clears = []
    for e in ev:
        k = e['k']
        if k in ('attack', 'cast') and e.get('a') in ours:
            cs = []
            if 'camp' in e: cs.append(e['camp'])
            for c, amt in e.get('cdmg') or []: cs.append(c)
            for c in cs:
                if c in camp_group: work[camp_group[c]].append((e['r'], e['a']))
        elif k == 'camp_attack':
            g = camp_group.get(e['camp'], e.get('g'))
            if e.get('tgt') in ours: hits[g].append((e['r'], e['tgt'], e['dmg']))
            for c, amt in e.get('xdmg') or []:
                if c in ours: hits[g].append((e['r'], c, amt))
            if e.get('tgt') in ours: tot['camp_dmg'] += e['dmg']
        elif k == 'recall_end' and e['a'] in ours:
            # A heal trip: home hurt. Dated by its start, 5 turn ends before.
            i = ridx.get(e['r'] - 1)
            c = chs[e['a']]
            if i is not None and c['hp'][i] is not None and c['maxHp'][i] and c['hp'][i] < 0.6 * c['maxHp'][i]:
                recalls.append((e['r'] - 5, e['a']))
                tot['heal_trips'] += 1
        elif k == 'capture' and e['team'] == team:
            for cid, gems, gold in e['shares']: tot['gems'] += gems
        elif k == 'group_clear':
            g = e['g']
            if e.get('by') in ours and (gtypes[g] & STRIKERS):
                R = e['r']; s0 = start[g]
                parts = {a for r, a in work[g] if s0 < r <= R}
                hit = {a for r, a, x in hits[g] if s0 < r <= R}
                dmg = sum(x for r, a, x in hits[g] if s0 < r <= R)
                kind = 'golem' if 'Golem' in gtypes[g] else 'elk' if 'Elk' in gtypes[g] else 'wolf'
                per = collections.Counter()
                for r, a, x in hits[g]:
                    if s0 < r <= R: per[a] += x
                top = max(per.values()) / sum(per.values()) if per else 1.0
                big = sum(1 for a, x in per.items() if x >= 0.25 * sum(per.values()))
                clears.append((R, parts, hit, dmg, kind, top, big))
            start[g] = e['r']
    for R, parts, hit, dmg, kind, top, big in clears:
        back = any(a in parts and R <= r <= R + 20 for r, a in recalls)
        for C in (tot, per_type[kind]):
            C['clears'] += 1
            if len(parts) >= 2:
                C['shared'] += 1; C['shared_parts'] += len(parts); C['shared_hit'] += len(hit & parts)
                C['shared_dmg'] += dmg; C['shared_recall'] += back; C['top'] += top; C['big'] += big
                C['back_parts'] += sum(1 for r, a in recalls if a in parts and R <= r <= R + 20)
            else:
                C['solo'] += 1; C['solo_recall'] += back; C['solo_dmg'] += dmg
def show(name, C):
    s = max(1, C['shared']); o = max(1, C['solo'])
    print(f"{name:6} clears {C['clears']:5} shared {C['shared']:4} ({100*C['shared']/max(1,C['clears']):.0f}%)  parts {C['shared_parts']/s:.2f} hit {C['shared_hit']/s:.2f}  dmg/shared {C['shared_dmg']/s:.0f}  top {C['top']/s:.2f} big {C['big']/s:.2f} trips/shared {C['back_parts']/s:.2f} recall20 shared {100*C['shared_recall']/s:.0f}% solo {100*C['solo_recall']/o:.0f}%  dmg/solo {C['solo_dmg']/o:.0f}")
print('games', games)
show('all', tot)
for k in sorted(per_type): show(k, per_type[k])
print('heal trips', tot['heal_trips'], 'per game', round(tot['heal_trips']/max(1,games),2))
print(f"camp damage per captured gem: {tot['camp_dmg']/max(1,tot['gems']):.2f} ({tot['camp_dmg']:.0f} / {tot['gems']})")
