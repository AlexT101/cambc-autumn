# Per round in a shared clear (TANK lines of one team's stdout): camp hits on the tank vs supports.
import gzip, json, glob, os, sys, collections, re
an, out, team = sys.argv[1], sys.argv[2], int(sys.argv[3])
d = os.path.dirname(glob.glob(an + '/*/meta.json')[0])
meta = json.load(open(d + '/meta.json'))
mp = json.load(open(os.path.join(d, meta['mapFile'])))
camp_group = {c['id']: c['group'] for c in mp['camps']}
tank = collections.defaultdict(dict)  # round -> handle -> (group, tank, role)
for l in open(out, errors='ignore'):
    m = re.match(r'TANK (\d+) (\d+) (\d+) (\d+) ([ts])', l)
    if m: r, h, g, t, role = map(lambda x: x, m.groups()); tank[int(r)][int(h)] = (int(g), int(t), role)
ev = [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')]
ours = {c['id'] for c in meta['champions'] if c['team'] == team}
print('ours', sorted(ours), 'champs', [(c['id'], c['name']) for c in meta['champions'] if c['team'] == team])
C = collections.Counter()
for e in ev:
    if e['k'] != 'camp_attack' or e.get('tgt') not in ours: continue
    r = e['r']
    # The formation set in round r-1 decides the hits at round r's camp phase.
    f = tank.get(r - 1, {})
    tgt = e['tgt']
    if tgt in f:
        g, t, role = f[tgt]
        C['tank' if role == 't' else 'support'] += 1
        C['dmg_' + ('tank' if role == 't' else 'support')] += e['dmg']
    else:
        C['outside'] += 1
print(dict(C))
dec = {}
for l in open(out, errors='ignore'):
    m = re.match(r'D (\d+) (\d+) (\S) (-?\d+) (-?\d+)', l)
    if m: dec[(int(m.group(1)), int(m.group(2)))] = (m.group(3), int(m.group(4)), int(m.group(5)))
work = collections.defaultdict(set)
for e in ev:
    if e['k'] in ('attack', 'cast') and e.get('a') in ours:
        cs = ([e['camp']] if 'camp' in e else []) + [c for c, a in e.get('cdmg') or []]
        for c in cs: work[(camp_group[c], e['r'])].add(e['a'])
O = collections.Counter()
for e in ev:
    if e['k'] != 'camp_attack' or e.get('tgt') not in ours: continue
    r, tgt = e['r'], e['tgt']
    if tgt in tank.get(r - 1, {}): continue
    g = camp_group[e['camp']]
    others = set().union(*[work[(g, x)] for x in range(r - 3, r + 3)]) - {tgt}
    dd = dec.get((r - 1, tgt), ('?', -9, -9))
    O[(dd[0], 'shared' if others else 'solo', 'fg' if dd[1] == g else 'other')] += 1
for k, v in O.most_common(): print(k, v)
rounds = json.load(gzip.open(d + '/rounds.json.gz'))
ridx = {x: i for i, x in enumerate(rounds['round'])}
ch = {c['id']: c for c in rounds['champions']}
camp_pos = {c['id']: (c['x'], c['y']) for c in mp['camps']}
def pos(cid, r):
    i = ridx.get(r); c = ch[cid]
    return None if i is None or c['x'][i] is None else (c['x'][i], c['y'][i])
dist = lambda a, b: max(abs(a[0]-b[0]), abs(a[1]-b[1]))
print('support hits:')
for e in ev:
    if e['k'] != 'camp_attack' or e.get('tgt') not in ours: continue
    r, tgt = e['r'], e['tgt']
    f = tank.get(r - 1, {})
    if tgt not in f or f[tgt][2] != 's': continue
    g, t, role = f[tgt]
    cp = camp_pos[e['camp']]; sp = pos(tgt, r - 1); tp = pos(t, r - 1)
    print(r, 'sup', tgt, sp, 'tank', t, tp, 'camp', e['camp'], cp, 'd_sup', dist(sp, cp) if sp else None, 'd_tank', dist(tp, cp) if tp else None, 'tank_role', f.get(t, (0,0,'-'))[2], 'dec', dec.get((r-1, tgt), '?')[0], 'prio s/t', ch[tgt]['prio'][ridx[r-1]], ch[t]['prio'][ridx[r-1]])
