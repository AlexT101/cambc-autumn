import gzip, json, glob, os, sys, collections, re, zipfile
an = sys.argv[1]
C = collections.Counter()
for meta_p in glob.glob(an + '/*/meta.json'):
    d = os.path.dirname(meta_p); meta = json.load(open(meta_p))
    team = next((i for i, t in enumerate(meta['teams']) if t.get('bot') == 0), 0)
    src = meta['source']
    z = zipfile.ZipFile(src if os.path.isabs(src) else os.path.join('/home/ubuntu/cambc-autumn', src))
    out = z.read('team-%s.stdout' % 'ab'[team]).decode(errors='ignore').replace('\0', '')
    tank = collections.defaultdict(dict)
    for l in out.splitlines():
        m = re.match(r'TANK (\d+) (\d+) (\d+) (\d+) ([ts])$', l)
        if m: tank[int(m.group(1))][int(m.group(2))] = (int(m.group(3)), int(m.group(4)), m.group(5))
    mp = json.load(open(os.path.join(d, meta['mapFile'])))
    cpos = {c['id']: (c['x'], c['y']) for c in mp['camps']}; ctype = {c['id']: c['type'] for c in mp['camps']}
    names = {c['id']: c['name'] for c in meta['champions']}
    rounds = json.load(gzip.open(d + '/rounds.json.gz')); ridx = {x: i for i, x in enumerate(rounds['round'])}
    ch = {c['id']: c for c in rounds['champions']}
    def pos(a, r):
        i = ridx.get(r)
        return None if i is None or ch[a]['x'][i] is None else (ch[a]['x'][i], ch[a]['y'][i])
    D = lambda a, b: max(abs(a[0]-b[0]), abs(a[1]-b[1]))
    for l in gzip.open(d + '/events.jsonl.gz', 'rt'):
        e = json.loads(l)
        if e['k'] != 'camp_attack': continue
        f = tank.get(e['r'] - 1, {}); a = e.get('tgt')
        if a not in f or f[a][2] != 's': continue
        t = f[a][1]
        sp, tp, cp = pos(a, e['r'] - 1), pos(t, e['r'] - 1), cpos[e['camp']]
        if not sp or not tp: C['nopos'] += 1; continue
        ds, dt = D(sp, cp), D(tp, cp)
        trole = f.get(t, (0, 0, '-'))[2]
        kind = 'nearer' if ds < dt else 'tie' if ds == dt else 'farther'
        M = ('Marcella','Heart of Ruin','Vendetta','Ryth','Ren','Varg','Issac')
        C[(kind, 'tank_agrees' if trole == 't' else 'tank_' + trole, 'melee' if names[a] in M else 'ranged', 'Tmelee' if names[t] in M else 'Tranged', ds, dt)] += 1
for k, v in C.most_common(): print(k, v)
