import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
C=collections.Counter(); first=collections.Counter(); gl=collections.Counter()
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    ch=R['champions']; byid={c['id']:c for c in ch}
    ri={r:i for i,r in enumerate(R['round'])}
    for e in ev:
        if e['k']!='death' or e.get('linked') is not None: continue
        v=byid[e['v']]; i=ri.get(e['r']-1, 0)
        x,y=e['at']
        al=en=0
        for o in ch:
            if o is v or not o['alive'][i] or o['x'][i] is None: continue
            dd=max(abs(o['x'][i]-x),abs(o['y'][i]-y))
            if dd<=6:
                if o['team']==v['team']: al+=1
                else: en+=1
        bycamp = e.get('camp') is not None
        key=('camp' if bycamp else 'champ', min(al,3), min(en,3))
        C[key]+=1
        # side of map: distance to own spawn vs enemy spawn
        sp=mp['spawn']
        def dsp(t):
            s=sp[t]; return max(max(s['minX']-x,0,x-s['maxX']),max(s['minY']-y,0,y-s['maxY']))
        own=dsp(v['team']); oth=dsp(1-v['team'])
        gl['own' if own<oth*0.8 else 'enemy' if oth<own*0.8 else 'mid']+=1
T=sum(C.values())
print('deaths by (cause, allies within 6 of victim (cap 3), enemies within 6)')
for k,v in sorted(C.items()): print(k, v, round(v/T,3))
print(gl)
