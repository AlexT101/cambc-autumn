import json,gzip,sys,os,collections,statistics as st
from collections import deque
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
cls=collections.Counter(); save=collections.defaultdict(list); nchamp=0
def bfs(W,H,block,srcs):
    D=[[10**6]*H for _ in range(W)]; q=deque()
    for x,y in srcs: D[x][y]=0; q.append((x,y))
    while q:
        x,y=q.popleft()
        for dx in(-1,0,1):
            for dy in(-1,0,1):
                nx,ny=x+dx,y+dy
                if 0<=nx<W and 0<=ny<H and not block[nx][ny] and D[nx][ny]>D[x][y]+1:
                    D[nx][ny]=D[x][y]+1; q.append((nx,ny))
    return D
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    W,H=mp['width'],mp['height']
    block=[[False]*H for _ in range(W)]
    for t in mp['walls']+mp['holes']: block[t[0]][t[1]]=True
    for t in mp['altars']: block[t[0]][t[1]]=True
    # tiles adjacent to altars as sources
    alt_adj=[(a[0]+dx,a[1]+dy) for a in mp['altars'] for dx in(-1,0,1) for dy in(-1,0,1) if 0<=a[0]+dx<W and 0<=a[1]+dy<H and not block[a[0]+dx][a[1]+dy]]
    DA=bfs(W,H,block,alt_adj)
    R=json.load(gzip.open(p+'/rounds.json.gz')); ri={r:i for i,r in enumerate(R['round'])}
    ch={c['id']:c for c in R['champions']}; nchamp+=len(ch)
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    shop=collections.defaultdict(set); trib=collections.defaultdict(list)
    for e in ev:
        if e['k']=='shop': shop[e['a']].add(e['r'])
        if e['k']=='tribute_start': trib[e['a']].append(e['r'])
    starts={}
    for e in ev:
        if e['k']=='recall_start': starts[e['a']]=e
        if e['k']=='recall_end' and e['a'] in starts:
            s=starts.pop(e['a']); c=ch[e['a']]; i=ri.get(s['r']-1,0)
            hp=c['hp'][i]/c['maxHp'][i] if c['hp'][i] else 0
            sx,sy=s['at']; tx,ty=e['to']
            g=s.get('gems',0)
            sh=any(r in shop[e['a']] for r in range(e['r'],e['r']+3))
            tb=any(e['r']<=r<=e['r']+40 for r in trib[e['a']])
            k=('hurt<50' if hp<0.5 else 'mid50-80' if hp<0.8 else 'healthy80+', 'bag' if g>0 else 'nobag', 'shop' if sh else '-', 'tribute<40r' if tb else '-')
            cls[k]+=1
            if g>0:
                direct=DA[sx][sy]; via=6+DA[tx][ty]
                save[k[0]].append(direct-via)
N=nchamp
print('recalls per champion-game by (hp at start, bag, shopped, tributed within 40 rounds)')
for k,v in cls.most_common(): print(k, round(v/N,2))
for k,v in save.items(): print('bag recalls',k,'steps saved vs walking to altar: median',st.median(v),'quartiles',st.quantiles(v,n=4))
