import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
visits=0; champs=0; reasons=collections.Counter(); hpat=[]; cost=[]; recalls=0; shops=0
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    ch=R['champions']; n=len(R['round'])
    shopr=collections.defaultdict(set)
    for e in ev:
        if e['k']=='shop': shopr[e['a']].add(e['r'])
        if e['k']=='recall_end': recalls+=1
    sp=mp['spawn']
    for c in ch:
        champs+=1; s=sp[c['team']]
        ons=[c['alive'][i] and c['x'][i] is not None and s['minX']<=c['x'][i]<=s['maxX'] and s['minY']<=c['y'][i]<=s['maxY'] for i in range(n)]
        i=1
        while i<n:
            if ons[i] and not ons[i-1] and c['alive'][i-1] and c['alive'][i]:
                visits+=1
                # hp 15 rounds before arrival (pre trip)
                j=max(0,i-15)
                h=c['hp'][j]/c['maxHp'][j] if c['hp'][j] is not None else 1
                hpat.append(h)
                k=i
                while k<n and ons[k]: k+=1
                sh=any(r in shopr[c['id']] for r in R['round'][i-1:k+1])
                g=c['gems'][i]
                reasons[('heal' if h<0.6 else 'healthy', 'shop' if sh else '-', 'bag' if g>0 else '-')]+=1
                i=k
            i+=1
N=len(dirs)
print('home visits per champion-game', visits/champs, 'recall arrivals per champ-game', recalls/champs)
for k,v in reasons.most_common(): print(k, round(v/champs,2))
