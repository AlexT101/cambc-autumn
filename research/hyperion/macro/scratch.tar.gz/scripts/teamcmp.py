import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]; cand=sys.argv[2]
agg=collections.defaultdict(lambda:[0.0,0.0]); n=0
for d in os.listdir(root):
    p=os.path.join(root,d)
    if not os.path.exists(p+'/meta.json'): continue
    m=json.load(open(p+'/meta.json'))
    names=[t.get('name','') for t in m['teams']]
    if cand not in names[0] and cand not in names[1]: continue
    ci=0 if cand in names[0] else 1
    n+=1
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    team={c['id']:c['team'] for c in m['champions']}
    for c in m['champions']:
        k=0 if c['team']==ci else 1
        s=c['stats']
        for f in ['deaths','kills','earnedGold','collectedGems','submittedGems','monsterDamageTaken','championDamageDone']:
            agg[f][k]+=s[f]
    for e in ev:
        if e['k']=='death':
            k=0 if team[e['v']]==ci else 1
            agg['gems_lost_at_death'][k]+=e.get('gems',0)
            if e.get('gems',0)>=10: agg['deaths_with_10+'][k]+=1
        if e['k']=='tribute_end': agg['tributes'][0 if team[e['a']]==ci else 1]+=1
        if e['k']=='recall_end': agg['recalls'][0 if team[e['a']]==ci else 1]+=1
    agg['win'][0]+= m['result']['winner']==ci; agg['rounds'][0]+=m['result']['rounds']
print('games',n)
for k,v in agg.items(): print(f"{k:22s} cand {v[0]/n:9.1f}   ref {v[1]/n:9.1f}")
