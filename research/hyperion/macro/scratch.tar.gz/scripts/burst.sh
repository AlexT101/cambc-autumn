#!/bin/bash
# usage: burst.sh replay.repl26a [team-a|team-b]
d=$(mktemp -d -p /tmp/claude-1000/-home-ubuntu-cambc-autumn/5b6fdea5-8c0c-400c-94d5-cb7146b58518/scratchpad)
unzip -o -q "$1" -d "$d"
t=${2:-team-a}
echo "act errors: $(grep -ac 'act error' $d/$t.stdout)"
grep -a "comms:" $d/$t.stdout | sort | uniq -c | head -3
grep -a "BURST" $d/$t.stdout | awk '{print $4}' | sort | uniq -c | tr '\n' ' '; echo
echo "$d"
