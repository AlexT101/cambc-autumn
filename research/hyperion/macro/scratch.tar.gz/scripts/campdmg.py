import json,gzip,sys,os,collections
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
by_activity=collections.Counter(); bytype=collections.Counter(); gems_t=collections.Counter(); tot=0
grp_dmg=collections.Counter(); grp_capt=collections.Counter(); wasted=0
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    camp_group={c['id']:c['group'] for c in mp['camps']}
    name={c['id']:c['name'] for c in m['champions']}
    team={c['id']:c['team'] for c in m['champions']}
    for c in m['champions']:
        gems_t[c['name']]+=c['stats']['collectedGems']
    # attacks on group by champion per round
    att=collections.defaultdict(set)
    for e in ev:
        if e['k'] in ('attack','cast') and e.get('cdmg') and 'a' in e:
            for cid,_ in e['cdmg']: att[(e['a'],e['r'])].add(camp_group.get(cid))
    # per group life: damage taken by each team until group_clear/respawn
    life_dmg=collections.defaultdict(float)
    for e in ev:
        if e['k']=='camp_attack':
            g=e['g']; t=e['tgt']; dmg=e['dmg']
            tot+=dmg; bytype[name[t]]+=dmg
            a=att.get((t,e['r']),set())|att.get((t,e['r']-1),set())
            by_activity['attacking that group' if g in a else 'attacking other group' if a else 'not attacking camps']+=dmg
            life_dmg[(g,team[t])]+=dmg
        elif e['k']=='capture':
            for tm in (0,1):
                k=(e['g'],tm)
                if tm==e['team']: grp_capt['captured']+=life_dmg[k]
                else: grp_capt['lost to enemy capture']+=life_dmg[k]
                life_dmg[k]=0
        elif e['k']=='group_sleep':
            for tm in (0,1):
                grp_capt['went back to sleep (abandoned)']+=life_dmg[(e['g'],tm)]; life_dmg[(e['g'],tm)]=0
print('camp damage total per game per team', tot/len(dirs)/2)
for k,v in by_activity.most_common(): print(k, round(v/tot,3))
T=sum(grp_capt.values())
for k,v in grp_capt.most_common(): print(k, round(v/T,3))
for k in bytype: print(f"{k:12s} dmg/gem {bytype[k]/max(1,gems_t[k]):6.1f}")
