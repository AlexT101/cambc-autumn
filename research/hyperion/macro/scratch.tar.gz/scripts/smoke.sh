#!/bin/bash
# usage: smoke.sh tag map...   (sequential: one build dir)
S=/tmp/claude-1000/-home-ubuntu-cambc-autumn/5b6fdea5-8c0c-400c-94d5-cb7146b58518/scratchpad
tag=$1; shift
cd /home/ubuntu/cambc-autumn
for m in "$@"; do
  out=$S/smoke-$tag/$(basename $m .map26a)
  rm -rf $out; mkdir -p $out
  res=$(timeout 900 cambc run /home/ubuntu/cambc-wt/macro-2/bots/astraeus /home/ubuntu/cambc-wt/macro-2/bots/variants/m2-base --map $m --fuel 100000000 -o $out 2>&1 | grep -E "error|wins")
  echo "== $m: $res"
  $S/scripts/burst.sh $out/*.repl26a team-a | head -3
done
