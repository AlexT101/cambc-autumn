import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
agg=collections.defaultdict(list)
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile']))) if 'mapFile' in m else None
    n=len(R['round'])
    agg['rounds'].append(m['result']['rounds'])
    agg['to2000'].append(m['result']['rounds']>=2000)
    ch=R['champions']
    sp=mp['spawn']
    def onsp(t,x,y):
        s=sp[t]; return s['minX']<=x<=s['maxX'] and s['minY']<=y<=s['maxY']
    cnt=collections.Counter()
    near3=near6=offalive=0
    for c in ch:
        t=c['team']
        for i in range(n):
            if not c['alive'][i]: cnt['dead']+=1; continue
            x,y=c['x'][i],c['y'][i]
            if x is None: cnt['dead']+=1; continue
            if onsp(t,x,y): cnt['spawn']+=1; continue
            cnt['off']+=1
            if c['chan'][i]==1 and c['chanT'][i] is not None: pass
            if c['chan'][i]==2: cnt['tribute']+=1
            moved = i>0 and c['x'][i-1] is not None and (c['x'][i-1],c['y'][i-1])!=(x,y)
            cnt['moved']+=moved
            cnt['carry']+= c['gems'][i]>0
            dmin=99
            for o in ch:
                if o is c or o['team']!=t or not o['alive'][i] or o['x'][i] is None: continue
                dmin=min(dmin,max(abs(o['x'][i]-x),abs(o['y'][i]-y)))
            near3+=dmin<=3; near6+=dmin<=6
    tot=sum(cnt[k] for k in ['dead','spawn','off'])
    for k in ['dead','spawn','off']: agg['frac_'+k].append(cnt[k]/tot)
    off=max(1,cnt['off'])
    for k in ['tribute','moved','carry']: agg['offfrac_'+k].append(cnt[k]/off)
    agg['near3'].append(near3/off); agg['near6'].append(near6/off)
    deaths=[e for e in ev if e['k']=='death']
    agg['deaths_per_team'].append(len(deaths)/2)
    agg['camp_deaths_per_team'].append(sum(1 for e in deaths if 'camp' in e and e.get('camp') is not None)/2)
    agg['gems_lost_death_per_team'].append(sum(e.get('gems',0) for e in deaths)/2)
    caps=[e for e in ev if e['k']=='capture']
    agg['captures_per_team'].append(len(caps)/2)
    agg['holders'].extend(len(e['shares']) for e in caps)
    # attackers per cleared group: distinct champs damaging camps of group between respawn and clear
    att=collections.defaultdict(set)
    for e in ev:
        if e['k'] in('attack','cast') and e.get('camp') is not None:
            pass
    sg=[c['stats'] for c in m['champions']]
    agg['mdt_per_gem'].append(sum(s['monsterDamageTaken'] for s in sg)/max(1,sum(s['collectedGems'] for s in sg)))
    agg['gold_per_team'].append(sum(s['earnedGold'] for s in sg)/2)
    agg['coll_gems_per_team'].append(sum(s['collectedGems'] for s in sg)/2)
    agg['champ_dmg_per_team'].append(sum(s['championDamageDone'] for s in sg)/2)
    agg['tributes_per_team'].append(sum(1 for e in ev if e['k']=='tribute_end')/2)
    tr=[e['gems'] for e in ev if e['k']=='tribute_end']
    agg['tribute_size'].extend(tr)
    agg['nchamps'].append(len(ch)/2)
for k,v in agg.items():
    v=[float(x) for x in v]
    print(f"{k:28s} mean {st.mean(v):9.3f} median {st.median(v):9.3f} n {len(v)}")
