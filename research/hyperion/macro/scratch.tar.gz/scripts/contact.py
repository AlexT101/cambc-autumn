import json,gzip,sys,os,collections
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
expo=collections.Counter(); die=collections.Counter(); kill=collections.Counter()
for d in dirs:
    p=os.path.join(root,d)
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ch=R['champions']; n=len(R['round'])
    # death rounds per champion
    dr=collections.defaultdict(list)
    for c in ch:
        for i in range(1,n):
            if c['alive'][i-1] and not c['alive'][i]: dr[c['id']].append(i)
    for i in range(0,n,3):
        for c in ch:
            if not c['alive'][i] or c['x'][i] is None: continue
            x,y=c['x'][i],c['y'][i]
            a=1;e=0
            for o in ch:
                if o is c or not o['alive'][i] or o['x'][i] is None: continue
                if max(abs(o['x'][i]-x),abs(o['y'][i]-y))<=6:
                    if o['team']==c['team']: a+=1
                    else: e+=1
            if e==0: continue
            k=(min(a,4),min(e,4))
            expo[k]+=1
            if any(i<j<=i+10 for j in dr[c['id']]): die[k]+=1
print('(us incl self, them) within 6: contact samples, P(die within 10 rounds)')
for k in sorted(expo): print(k, expo[k], round(die[k]/expo[k],3))
