import json,gzip,sys,os,collections,statistics as st
root=sys.argv[1]
dirs=[d for d in os.listdir(root) if os.path.exists(os.path.join(root,d,'meta.json'))]
caps=collections.Counter(); capg=collections.Counter(); avail=collections.Counter(); asleep=collections.Counter(); ngroups=collections.Counter()
side=collections.Counter()
for d in dirs:
    p=os.path.join(root,d)
    m=json.load(open(p+'/meta.json'))
    R=json.load(gzip.open(p+'/rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(p+'/events.jsonl.gz','rt')]
    mp=json.load(open(os.path.join(p,m['mapFile'])))
    G={g['id']:g for g in mp['groups']}
    def kind(g):
        t=tuple(sorted(collections.Counter(g['types']).items()))
        if any(x[0]=='Monolith' for x in t): return 'monolith'
        if any(x[0]=='Golem' for x in t): return 'golem+'
        if any(x[0]=='Elk' for x in t): return 'elk+'
        if any(x[0]=='Wolf' for x in t): return 'wolf+'
        if all(x[0]=='Gold cluster' for x in t): return 'goldcl'
        return 'gemcl'
    for g in G.values(): ngroups[kind(g)]+=1
    for e in ev:
        if e['k']=='capture':
            g=G[e['g']]; k=kind(g)
            caps[k]+=1; capg[k]+=sum(s[1] for s in e['shares'])
            side[(k, 'own' if g['side']==e['team'] else 'mid' if g['side']==-1 else 'enemy')]+=1
    cur={}; byr=collections.defaultdict(list)
    for row in R['groups']: byr[row[0]].append(row)
    for r in R['round']:
        for row in byr.get(r,[]): cur[row[1]]=row
        for g,row in cur.items():
            k=kind(G[g]); avail[k]+=1
            if row[2]==1 and row[6]==0: asleep[k]+=1
N=len(dirs)
tot=sum(capg.values())
for k in ngroups:
    print(f"{k:9s} groups/game {ngroups[k]/N:5.1f} caps/game {caps[k]/N:6.1f} gems/game {capg[k]/N:6.1f} ({capg[k]/tot:.2f}) asleep-frac {asleep[k]/max(1,avail[k]):.2f}")
for k,v in sorted(side.items()): print(k, round(v/N,1))
