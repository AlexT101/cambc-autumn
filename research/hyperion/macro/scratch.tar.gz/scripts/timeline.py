# Timelines of shared clears with spread damage: per round, who hit the group, who was hit, roles.
import gzip, json, glob, os, sys, collections, re, zipfile
an = sys.argv[1]; want = int(sys.argv[2]) if len(sys.argv) > 2 else 4
shown = 0
for meta_p in sorted(glob.glob(an + '/*/meta.json')):
    d = os.path.dirname(meta_p); meta = json.load(open(meta_p))
    team = next((i for i, t in enumerate(meta['teams']) if t.get('bot') == 0), 0)
    src = meta['source']
    z = zipfile.ZipFile(src if os.path.isabs(src) else os.path.join('/home/ubuntu/cambc-autumn', src))
    out = z.read('team-%s.stdout' % 'ab'[team]).decode(errors='ignore').replace('\0', '')
    tank = collections.defaultdict(dict); dec = {}
    for l in out.splitlines():
        m = re.match(r'TANK (\d+) (\d+) (\d+) (\d+) ([ts])$', l)
        if m: tank[int(m.group(1))][int(m.group(2))] = (m.group(5), int(m.group(4)))
        m = re.match(r'D (\d+) (\d+) (\S) (-?\d+)', l)
        if m: dec[(int(m.group(1)), int(m.group(2)))] = m.group(3)
    ours = {c['id']: c['name'][:4] for c in meta['champions'] if c['team'] == team}
    mp = json.load(open(os.path.join(d, meta['mapFile'])))
    cg = {c['id']: c['group'] for c in mp['camps']}; gt = collections.defaultdict(set)
    for c in mp['camps']: gt[c['group']].add(c['type'])
    evs = [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')]
    rounds = json.load(gzip.open(d + '/rounds.json.gz')); ridx = {x: i for i, x in enumerate(rounds['round'])}
    ch = {c['id']: c for c in rounds['champions']}
    last = collections.defaultdict(int); work = collections.defaultdict(lambda: collections.defaultdict(set)); hit = collections.defaultdict(lambda: collections.defaultdict(list))
    for e in evs:
        if e['k'] in ('attack', 'cast') and e.get('a') in ours:
            for c in ([e['camp']] if 'camp' in e else []) + [c for c, a in e.get('cdmg') or []]: work[cg[c]][e['r']].add(e['a'])
        if e['k'] == 'camp_attack' and e.get('tgt') in ours: hit[cg[e['camp']]][e['r']].append(e['tgt'])
        if e['k'] == 'group_clear':
            g = e['g']; R = e['r']; s0 = last[g]; last[g] = R
            if e.get('by') not in ours or 'Elk' not in gt[g]: continue
            per = collections.Counter(a for r in hit[g] if s0 < r <= R for a in hit[g][r])
            parts = set(a for r in work[g] if s0 < r <= R for a in work[g][r])
            if len(parts) < 2 or not per or max(per.values()) / sum(per.values()) > 0.6: continue
            print('==', meta['map']['name'], 'group', g, sorted(gt[g]), 'clear', R, 'parts', [ours[a] for a in parts], dict((ours[a], v) for a, v in per.items()))
            rs = sorted(set(r for r in work[g] if s0 < r <= R) | set(r for r in hit[g] if s0 < r <= R))
            for r in rs:
                i = ridx.get(r - 1)
                info = []
                for a in sorted(ours):
                    if a in work[g].get(r, ()) or a in hit[g].get(r, ()):
                        tr = tank.get(r - 1, {}).get(a)
                        hp = ch[a]['hp'][i] if i is not None else None
                        info.append(f"{ours[a]}({'W' if a in work[g].get(r, ()) else ''}{'H' if a in hit[g].get(r, ()) else ''} {tr[0]+str(tr[1]) if tr else '-'} {dec.get((r-1, a), '?')} hp{hp and round(hp)} @{(ch[a]['x'][i], ch[a]['y'][i]) if i is not None else ''})")
                print('  ', r, ' '.join(info))
            shown += 1
            if shown >= want: sys.exit()
