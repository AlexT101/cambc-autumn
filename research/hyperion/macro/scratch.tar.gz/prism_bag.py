"""Prism's carried gems at checkpoints and its captures, ours (bot 1) vs baseline (bot 2), per game of a batch."""
import gzip, json, os, sys, statistics as st

batch = os.path.abspath(sys.argv[1])
root = sys.argv[2]
index = json.load(open(os.path.join(root, 'index.json')))
checks = [200, 400, 600, 800, 1000]
rows = []
for g in index['games']:
    src = os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', g['source'])) if not os.path.isabs(g['source']) else g['source']
    if not src.startswith(batch):
        continue
    name = os.path.basename(src)
    ours_a = name.endswith('-12.repl26a')
    d = os.path.join(root, g['dir'])
    meta = json.load(open(os.path.join(d, 'meta.json')))
    rounds = json.load(gzip.open(os.path.join(d, 'rounds.json.gz')))
    events = [json.loads(l) for l in gzip.open(os.path.join(d, 'events.jsonl.gz'), 'rt')]
    our_team = 0 if ours_a else 1
    rec = {'map': meta['map']['name'], 'side': 'A' if ours_a else 'B', 'winner_ours': meta['result']['winner'] == our_team,
           'picks': len(meta['draft']['picks'][0]) if meta['draft']['picks'] else None}
    for who, team in (('ours', our_team), ('base', 1 - our_team)):
        prism = [c for c in meta['champions'] if c['team'] == team and 'rism' in str(c['type']) + str(c['name'])]
        if not prism:
            rec[who] = None
            continue
        pid = prism[0]['id']
        idx = [i for i, c in enumerate(rounds['champions']) if c['id'] == pid][0]
        ch = rounds['champions'][idx]
        bag = {}
        for r in checks:
            if r in rounds['round']:
                i = rounds['round'].index(r)
                bag[r] = ch['gems'][i]
        caps = alone = gems_in = 0
        for e in events:
            if e['k'] == 'capture':
                for s in e['shares']:
                    if s[0] == pid and (s[1] > 0 or s[2] > 0):
                        caps += 1
                        alone += len(e['shares']) == 1
                        gems_in += s[1]
        deaths = [e for e in events if e['k'] == 'death' and e['v'] == pid]
        lost = sum(e.get('gems', 0) for e in deaths)
        peak = max(ch['gems'])
        team_caps = sum(1 for e in events if e['k'] == 'capture' and e['team'] == team)
        rec[who] = {'bag': bag, 'caps': caps, 'alone': alone, 'gems_in': gems_in, 'team_caps': team_caps,
                    'tributed': rounds['gems'][team][-1],
                    'deaths': len(deaths), 'lost': lost, 'peak': peak}
    rows.append(rec)

both = [r for r in rows if r['ours'] and r['base']]
print(f'games {len(rows)}, with Prism on both sides {len(both)}, ours won {sum(r["winner_ours"] for r in rows)}/{len(rows)}')
print(f'Prism games: ours won {sum(r["winner_ours"] for r in both)}/{len(both)}')
for who in ('ours', 'base'):
    line = [who]
    for r in checks:
        v = [x[who]['bag'][r] for x in both if r in x[who]['bag']]
        if v:
            line.append(f'r{r} mean {st.mean(v):.1f} med {st.median(v):.0f}')
    print('  '.join(line))
    print(f'   captures {st.mean(x[who]["caps"] for x in both):.1f} (alone {st.mean(x[who]["alone"] for x in both):.1f}),'
          f' gems from captures {st.mean(x[who]["gems_in"] for x in both):.1f}, team captures {st.mean(x[who]["team_caps"] for x in both):.1f},'
          f' tributed {st.mean(x[who]["tributed"] for x in both):.0f}')
    print(f'   Prism deaths {st.mean(x[who]["deaths"] for x in both):.2f}, gems lost dying {st.mean(x[who]["lost"] for x in both):.1f}, peak bag {st.mean(x[who]["peak"] for x in both):.0f}')
    for r in checks:
        alive = [x for x in both if r in x['ours']['bag'] and r in x['base']['bag']]
        if who == 'ours' and alive:
            d = [x['ours']['bag'][r] - x['base']['bag'][r] for x in alive]
            print(f'   r{r}: {len(alive)} games still on, ours-base mean {st.mean(d):+.1f}, ours bigger in {sum(v > 0 for v in d)}, smaller in {sum(v < 0 for v in d)}')
if '-v' in sys.argv:
    for r in both:
        print(r['map'], r['side'], r['picks'], 'W' if r['winner_ours'] else 'L',
              'ours', r['ours']['bag'], r['ours']['caps'], 'base', r['base']['bag'], r['base']['caps'])
