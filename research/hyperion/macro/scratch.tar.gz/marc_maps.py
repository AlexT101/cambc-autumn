import json, os, sys
root = sys.argv[1]
index = json.load(open(os.path.join(root, 'index.json')))
for batch in sys.argv[2:]:
    batch = os.path.abspath(batch); res = {}
    for g in index['games']:
        src = g['source'] if os.path.isabs(g['source']) else os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', g['source']))
        if not src.startswith(batch): continue
        meta = json.load(open(os.path.join(root, g['dir'], 'meta.json')))
        our = 0 if src.endswith('-12.repl26a') else 1
        mine = [str(c['type']).lower() + str(c['name']).lower() for c in meta['champions'] if c['team'] == our]
        if any('prism' in m for m in mine) or not any('marcella' in m for m in mine): continue
        res[(meta['map']['name'], 'AB'[our])] = (len(meta['draft']['picks'][our]), meta['result']['winner'] == our, meta['result']['gems'][our], meta['result']['gems'][1-our], meta['result']['rounds'])
    print(batch[-22:]); by = {}
    for k, v in sorted(res.items()):
        by.setdefault(v[0], [0, 0]); by[v[0]][0] += v[1]; by[v[0]][1] += 1
    print(' picks: ' + ', '.join(f'{p}: {w}/{n}' for p, (w, n) in sorted(by.items())))
    yield_ = res
    globals().setdefault('all', []).append(res)
a, b = all
print('map side picks | prism-only build W, gems | marcella build W, gems')
for k in sorted(a):
    if a[k][1] != b[k][1]: print(k, a[k][0], '|', 'W' if a[k][1] else 'L', a[k][2], a[k][3], '|', 'W' if b[k][1] else 'L', b[k][2], b[k][3])
