F = "economy/farm.cc"
wait0 = [(F, "if (wait > params::max_wait) continue;", "if (wait > 0) continue;")]
nocrew = [
    (F, "    float unclaimed_partner_output = 0;\n    for (const auto& a : world.allies)\n        if (!a.is_self && a.alive && a.visible && dist(here, a.pos) <= params::partner_radius && comms::claim_of(world, a.index) < 0)\n            unclaimed_partner_output = std::max(unclaimed_partner_output, camp_output(a));\n",
        "    // lab nocrew: no ally joins as crew, so no unclaimed partner either.\n    const float unclaimed_partner_output = 0;\n"),
    (F, "    if (shared >= 0 && (best < 0 || shared_value > best_value))", "    if (false && shared >= 0 && (best < 0 || shared_value > best_value))"),
    (F, "    if (help_group >= 0) best = help_group,", "    if (false && help_group >= 0) best = help_group,"),
]
noshop = [("economy/shop.cc",
    "[[gnu::flatten]] bool wants_shop(const World& world, Pathing& pathing, Safety& safety, const Memory& memory) {\n",
    "[[gnu::flatten]] bool wants_shop(const World& world, Pathing& pathing, Safety& safety, const Memory& memory) {\n    if (true) return false; // lab noshop\n")]
noQ = [("economy/capture.cc",
    "bool capture_recall(const World& world, Pathing& pathing, Safety& safety, Memory& memory) {\n",
    "bool capture_recall(const World& world, Pathing& pathing, Safety& safety, Memory& memory) {\n    if (true) return false; // lab noQ\n"),
    # farm's bank term assumed the recall overlaps the capture hold; now it starts after payout.
    (F, "->rounds(walk, capture, static_cast<std::uint32_t>(", "->rounds(walk, 0, static_cast<std::uint32_t>(")]
bigbag = [("params.h", "chain_bag_limit = 45;", "chain_bag_limit = 90;"), ("params.h", "brake_bag = 11;", "brake_bag = 22;")]
def walk(W):
    w = f"{W}f"
    return [
    (F, "constexpr float stickiness = 1.2f;\n", f"constexpr float stickiness = 1.2f;\n// lab walk: walking rounds to a group (from here or from an altar) count this much in farm's rate.\nconstexpr float walk_factor = {w};\n"),
    (F, "rate(world, worth, static_cast<float>(walk) + cap + cycle_bank + fastest)", "rate(world, worth, walk_factor * static_cast<float>(walk) + cap + cycle_bank + fastest)"),
    (F, "if (rated_below(worth, static_cast<float>(near + near_wait(belief, near)), fastest)) continue;", "if (rated_below(worth, walk_factor * static_cast<float>(near) + static_cast<float>(near_wait(belief, near)), fastest)) continue;"),
    (F, "unweighed_beaten(group, belief, g, static_cast<float>(near + near_wait(belief, near)))", "unweighed_beaten(group, belief, g, walk_factor * static_cast<float>(near) + static_cast<float>(near_wait(belief, near)))"),
    (F, "const float trip = std::max(0.0f, static_cast<float>(near + near_wait(belief, near)) - bank_now + bank);", "const float trip = std::max(0.0f, walk_factor * static_cast<float>(near) + static_cast<float>(near_wait(belief, near)) - bank_now + bank);"),
    (F, "worth / (static_cast<float>(walk + capture) + cycle_bank + known.fastest) <= from_altar_value", "worth / (walk_factor * static_cast<float>(walk) + cap_rounds + cycle_bank + known.fastest) <= from_altar_value"),
    (F, "rate(world, worth, std::max(0.0f, static_cast<float>(near) - bank_now) + cap_rounds)", "rate(world, worth, std::max(0.0f, walk_factor * static_cast<float>(near) - bank_now) + cap_rounds)"),
    (F, "return rate(world, worth, static_cast<float>(near + capture)) * 1.0001f < best_value;", "return rate(world, worth, walk_factor * static_cast<float>(near) + cap_rounds) * 1.0001f < best_value;"),
    (F, "return rate(world, worth, static_cast<float>(walk) + cap_rounds) * 1.0001f < tested_value;", "return rate(world, worth, walk_factor * static_cast<float>(walk) + cap_rounds) * 1.0001f < tested_value;"),
    (F, "const float trip = std::max(0.0f, static_cast<float>(steps + wait) - bank_now + bank);", "const float trip = std::max(0.0f, walk_factor * static_cast<float>(steps) + static_cast<float>(wait) - bank_now + bank);"),
    (F, "(gems + gold) / (static_cast<float>(walk + capture) + cycle_bank + fastest) <= from_altar_value", "(gems + gold) / (walk_factor * static_cast<float>(walk) + cap_rounds + cycle_bank + fastest) <= from_altar_value"),
    (F, "worth / (static_cast<float>(walk) + cycle_bank + quickest + capture) <= from_altar_value", "worth / (walk_factor * static_cast<float>(walk) + cycle_bank + quickest + cap_rounds) <= from_altar_value"),
    (F, "const float from_altar = static_cast<float>(walk) + cycle_bank + via_altar + clear_rounds + capture;", "const float from_altar = walk_factor * static_cast<float>(walk) + cycle_bank + via_altar + clear_rounds + cap_rounds;"),
    ]
walk15 = walk(1.5)
noshared = [nocrew[1]]
nohelp = [nocrew[2]]
nopartner = [nocrew[0]]
def crew(x):
    return [(F, "const float value = rate(world, worth * part, trip + rounds);", f"const float value = {x}f * rate(world, worth * part, trip + rounds); // lab crew weight")]
crew125 = crew(1.25); crew08 = crew(0.8); crew15 = crew(1.5)
def chain(x):
    # Bank only when the cycle from the altar beats chaining by x: from_altar_value is kept divided by
    # x, so every prune against it stays conservative (prunes less).
    return [(F, "from_altar_value = std::max(from_altar_value, rate(world, worth, from_altar));", f"from_altar_value = std::max(from_altar_value, rate(world, worth, from_altar) / {x}f); // lab chain bias")]
chain125 = chain(1.25)
combo1 = wait0 + bigbag
help12 = [("params.h", "help_radius = 8;", "help_radius = 12;")]
help16 = [("params.h", "help_radius = 8;", "help_radius = 16;")]
wait2 = [("params.h", "max_wait = 5;", "max_wait = 2;")]
wait10 = [("params.h", "max_wait = 5;", "max_wait = 10;")]
stick10 = [(F, "constexpr float stickiness = 1.2f;", "constexpr float stickiness = 1.0f;")]
stick15 = [(F, "constexpr float stickiness = 1.2f;", "constexpr float stickiness = 1.5f;")]
HZ = "float cycle_horizon(const StaticMap& map) { return 100 * "
hor2 = [("bot_parts.h", HZ, "float cycle_horizon(const StaticMap& map) { return 200 * ")]
hor05 = [("bot_parts.h", HZ, "float cycle_horizon(const StaticMap& map) { return 50 * ")]
combo2 = wait0 + bigbag + chain125 + crew08
chainbig15 = bigbag + chain(1.5)
chainbig2 = bigbag + chain(2.0)
nohome = [("params.h", "home_power = 2.0f;", "home_power = 0.0f;")]
prism60 = [("params.h", "prism_retain_cap = 150;", "prism_retain_cap = 60;")]
prism300 = [("params.h", "prism_retain_cap = 150;", "prism_retain_cap = 300;")]
combo3 = wait0 + crew08
