# Turn budget: 3212 games from /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-fresh-6035, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-fresh-6036, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-fresh-6037, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-fresh-6038, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-fresh-gen-s1, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-gen, /home/ubuntu/cambc-autumn/replays/batch-20261030-120859-ab-m3-a2-ladder

Trace: 12 of 6424 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 0.0% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all astraeus-ef8f0b8 | all m3-a2 | r1-150 astraeus-ef8f0b8 | r1-150 m3-a2 | r151-400 astraeus-ef8f0b8 | r151-400 m3-a2 | r401-800 astraeus-ef8f0b8 | r401-800 m3-a2 | r801+ astraeus-ef8f0b8 | r801+ m3-a2 | r1-300 astraeus-ef8f0b8 | r1-300 m3-a2 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 6.1 | 5.6 | 3.1 | 2.9 | 4.9 | 4.5 | 6.0 | 5.7 | 8.7 | 7.7 | 3.9 | 3.7 |
| fight | 3.7 | 3.8 | 2.8 | 2.8 | 2.9 | 2.9 | 3.6 | 3.6 | 5.0 | 5.1 | 2.8 | 2.9 |
| tribute | 2.9 | 2.9 | 1.8 | 1.7 | 2.8 | 2.8 | 3.5 | 3.5 | 2.9 | 2.9 | 2.2 | 2.2 |
| recall | 3.9 | 3.9 | 3.9 | 3.9 | 4.5 | 4.5 | 3.9 | 3.9 | 3.3 | 3.3 | 4.3 | 4.3 |
| hold+recall | 3.1 | 3.1 | 3.6 | 3.6 | 4.2 | 4.2 | 3.3 | 3.2 | 1.9 | 1.8 | 3.9 | 3.9 |
| teleport | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.1 | 0.1 | 0.1 | 0.1 | 0.0 | 0.0 |
| camp | 17.2 | 17.1 | 27.6 | 27.3 | 21.0 | 20.8 | 16.2 | 16.1 | 9.8 | 9.9 | 24.7 | 24.5 |
| hold | 4.6 | 4.6 | 5.2 | 5.2 | 4.8 | 4.8 | 4.4 | 4.4 | 4.3 | 4.4 | 5.0 | 5.0 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 11.7 | 11.7 | 8.7 | 8.6 | 12.8 | 12.9 | 13.3 | 13.1 | 10.6 | 10.5 | 10.6 | 10.6 |
| bag->camp | 4.6 | 4.6 | 3.8 | 3.8 | 5.6 | 5.6 | 4.9 | 5.0 | 3.6 | 3.7 | 4.7 | 4.7 |
| bag-other | 2.5 | 2.5 | 1.4 | 1.3 | 2.2 | 2.2 | 2.7 | 2.7 | 3.2 | 3.1 | 1.8 | 1.7 |
| empty->camp | 23.2 | 23.7 | 27.6 | 27.9 | 22.1 | 22.4 | 22.7 | 23.0 | 22.6 | 23.4 | 24.9 | 25.2 |
| empty->spawn | 3.2 | 3.2 | 2.2 | 2.3 | 2.3 | 2.3 | 2.9 | 2.9 | 4.6 | 4.6 | 2.3 | 2.3 |
| empty-other | 7.0 | 7.4 | 4.8 | 5.2 | 4.9 | 5.4 | 6.5 | 6.9 | 10.4 | 10.9 | 4.8 | 5.2 |
| idle-off | 6.1 | 5.8 | 3.4 | 3.3 | 4.8 | 4.6 | 6.0 | 5.8 | 8.6 | 8.1 | 4.0 | 3.9 |
| idle-spawn | 0.2 | 0.2 | 0.1 | 0.1 | 0.1 | 0.1 | 0.1 | 0.1 | 0.4 | 0.4 | 0.1 | 0.1 |

By attack type (all rounds):

| class | melee astraeus-ef8f0b8 | melee m3-a2 | ranged astraeus-ef8f0b8 | ranged m3-a2 |
|---|---|---|---|---|
| dead | 6.1 | 5.6 | 6.1 | 5.6 |
| fight | 4.1 | 4.2 | 2.9 | 3.0 |
| tribute | 3.3 | 3.3 | 2.1 | 2.2 |
| recall | 4.1 | 4.1 | 3.5 | 3.5 |
| hold+recall | 3.5 | 3.5 | 2.5 | 2.5 |
| teleport | 0.1 | 0.1 | 0.1 | 0.1 |
| camp | 16.3 | 16.2 | 18.9 | 18.6 |
| hold | 4.1 | 4.1 | 5.5 | 5.5 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 11.8 | 11.7 | 11.6 | 11.6 |
| bag->camp | 3.7 | 3.7 | 6.1 | 6.2 |
| bag-other | 2.5 | 2.4 | 2.7 | 2.7 |
| empty->camp | 24.3 | 24.8 | 21.3 | 21.6 |
| empty->spawn | 3.1 | 3.1 | 3.2 | 3.2 |
| empty-other | 7.4 | 7.8 | 6.2 | 6.8 |
| idle-off | 5.5 | 5.3 | 7.0 | 6.7 |
| idle-spawn | 0.2 | 0.2 | 0.2 | 0.2 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | astraeus-ef8f0b8 | 1088311 | 6.8 | 1.4 | 20.2 | 4.7 | 1.9 | 3.4 | 0.0 | 0.1 | 6.8 | 51.2 |
| Cassi | m3-a2 | 1088311 | 6.1 | 1.5 | 20.0 | 4.9 | 1.9 | 3.4 | 0.0 | 0.1 | 6.3 | 52.1 |
| Heart of Ruin | astraeus-ef8f0b8 | 2659376 | 7.7 | 6.9 | 18.0 | 3.8 | 2.4 | 3.4 | 0.0 | 0.2 | 5.4 | 49.4 |
| Heart of Ruin | m3-a2 | 2659376 | 6.8 | 7.1 | 17.9 | 3.7 | 2.5 | 3.4 | 0.0 | 0.3 | 5.3 | 50.3 |
| Issac | astraeus-ef8f0b8 | 1088311 | 6.8 | 1.6 | 17.8 | 4.6 | 3.3 | 3.8 | 0.0 | 0.0 | 4.8 | 53.0 |
| Issac | m3-a2 | 1088311 | 6.1 | 1.7 | 17.8 | 4.6 | 3.3 | 3.7 | 0.0 | 0.0 | 4.5 | 53.8 |
| Marcella | astraeus-ef8f0b8 | 2877579 | 5.6 | 4.0 | 13.9 | 4.3 | 3.1 | 4.4 | 0.0 | 0.2 | 5.9 | 55.4 |
| Marcella | m3-a2 | 2877579 | 5.5 | 4.0 | 13.8 | 4.4 | 3.1 | 4.4 | 0.0 | 0.2 | 5.7 | 55.9 |
| Prism | astraeus-ef8f0b8 | 1380097 | 4.6 | 2.3 | 19.7 | 9.5 | 2.5 | 3.4 | 0.0 | 0.2 | 7.7 | 48.0 |
| Prism | m3-a2 | 1380097 | 4.0 | 2.3 | 19.9 | 9.1 | 2.7 | 3.4 | 0.0 | 0.3 | 7.3 | 48.9 |
| Ren | astraeus-ef8f0b8 | 29391 | 5.9 | 3.2 | 14.9 | 2.9 | 1.5 | 3.1 | 0.0 | 0.2 | 4.2 | 61.9 |
| Ren | m3-a2 | 29391 | 3.9 | 3.5 | 16.0 | 2.7 | 1.8 | 3.4 | 0.0 | 0.3 | 3.9 | 62.2 |
| Ryth | astraeus-ef8f0b8 | 136108 | 11.4 | 10.7 | 10.1 | 7.0 | 2.7 | 3.3 | 0.0 | 0.2 | 3.6 | 49.0 |
| Ryth | m3-a2 | 136108 | 9.3 | 10.6 | 10.6 | 6.3 | 2.9 | 3.7 | 0.0 | 0.2 | 3.6 | 50.9 |
| Tavi | astraeus-ef8f0b8 | 248372 | 12.6 | 7.0 | 13.3 | 5.1 | 1.5 | 2.3 | 0.0 | 0.3 | 6.4 | 49.8 |
| Tavi | m3-a2 | 248372 | 10.8 | 7.7 | 12.5 | 6.1 | 1.4 | 2.2 | 0.0 | 0.2 | 5.3 | 52.3 |
| Varg | astraeus-ef8f0b8 | 226611 | 2.2 | 1.0 | 20.3 | 3.1 | 4.2 | 3.2 | 0.0 | 0.0 | 5.7 | 55.5 |
| Varg | m3-a2 | 226611 | 1.9 | 1.0 | 20.3 | 3.0 | 4.2 | 3.2 | 0.0 | 0.0 | 5.6 | 56.0 |
| Vendetta | astraeus-ef8f0b8 | 2519767 | 4.7 | 2.3 | 16.5 | 3.9 | 4.5 | 4.6 | 0.0 | 0.1 | 5.6 | 53.2 |
| Vendetta | m3-a2 | 2519767 | 4.3 | 2.4 | 16.4 | 3.9 | 4.5 | 4.7 | 0.0 | 0.1 | 5.4 | 53.7 |
| Vesper Vale | astraeus-ef8f0b8 | 1283162 | 4.6 | 4.9 | 17.8 | 3.7 | 2.9 | 4.2 | 0.0 | 0.1 | 5.2 | 53.4 |
| Vesper Vale | m3-a2 | 1283162 | 4.3 | 5.2 | 17.7 | 3.6 | 2.8 | 4.2 | 0.0 | 0.1 | 5.1 | 53.9 |
| Willow | astraeus-ef8f0b8 | 1256038 | 7.4 | 1.9 | 19.0 | 3.9 | 1.3 | 3.4 | 0.0 | 0.4 | 8.6 | 52.4 |
| Willow | m3-a2 | 1256038 | 7.1 | 1.9 | 18.3 | 4.0 | 1.2 | 3.4 | 0.0 | 0.4 | 8.3 | 53.6 |

Bot branch (D lines), % of champion-rounds:

| branch | all astraeus-ef8f0b8 | all m3-a2 | r1-300 astraeus-ef8f0b8 | r1-300 m3-a2 |
|---|---|---|---|---|
| `-` | 6.2 | 5.7 | 3.9 | 3.7 |
| `?` | 0.0 | 0.1 | 0.0 | 0.0 |
| `B` | 19.9 | 19.8 | 18.5 | 18.5 |
| `C` | 2.3 | 2.2 | 1.6 | 1.5 |
| `E` | 0.1 | 0.1 | 0.0 | 0.0 |
| `F` | 51.9 | 51.1 | 57.8 | 57.1 |
| `G` | 1.8 | 1.9 | 0.3 | 0.3 |
| `H` | 0.9 | 0.9 | 1.0 | 1.0 |
| `K` | 1.3 | 1.3 | 1.8 | 1.8 |
| `P` | 4.5 | 4.5 | 5.1 | 5.1 |
| `Q` | 2.4 | 2.4 | 3.1 | 3.1 |
| `R` | 6.2 | 5.7 | 4.9 | 4.6 |
| `S` | 0.1 | 0.1 | 0.1 | 0.0 |
| `T` | 1.4 | 1.4 | 0.9 | 0.9 |
| `W` | 0.0 | 0.0 | 0.0 | 0.0 |
| `X` | 0.1 | 0.1 | 0.1 | 0.1 |
| `Y` | 0.0 | 1.9 | 0.0 | 1.5 |
| `h` | 0.2 | 0.2 | 0.3 | 0.3 |
| `k` | 0.8 | 0.8 | 0.5 | 0.6 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 1747210 | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |
| `?` | 13442 | 4 | 3 | 26 |  |  |  |  | 4 |  | 2 |  | 2 | 3 | 2 | 2 | 50 |  |
| `B` | 5866723 |  | 2 | 4 | 1 |  |  | 15 |  |  | 49 | 14 | 7 |  |  |  | 6 |  |
| `C` | 663060 |  | 17 |  |  |  |  |  |  |  | 11 | 4 | 12 | 18 | 5 | 31 |  |  |
| `E` | 27849 |  | 43 |  |  |  |  |  |  |  | 8 |  | 7 | 3 | 3 | 32 | 2 | 1 |
| `F` | 15229199 |  | 3 | 1 |  |  |  | 27 | 1 |  | 3 | 3 |  | 40 | 2 | 10 | 8 |  |
| `G` | 550293 |  | 3 |  |  |  |  | 15 |  |  | 1 |  |  | 28 | 6 | 16 | 27 | 2 |
| `H` | 256497 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 389041 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 1320571 |  | 1 |  |  | 12 |  | 2 | 85 |  |  |  |  |  |  |  |  |  |
| `Q` | 711540 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 1758665 |  | 22 |  | 7 |  |  |  |  |  | 3 | 4 | 9 | 20 | 26 | 7 | 1 |  |
| `S` | 15750 |  | 2 | 45 | 4 |  |  |  |  |  | 3 | 2 | 6 | 12 | 27 |  |  |  |
| `T` | 420011 |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `W` | 4888 |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  | 90 |  |
| `X` | 20122 |  | 7 |  |  |  |  |  | 20 |  | 2 |  | 1 | 25 | 2 | 42 |  |  |
| `Y` | 275047 |  | 3 | 1 |  |  |  |  |  |  |  |  |  | 35 | 10 | 46 | 4 |  |
| `h` | 69858 |  | 1 |  |  |  |  | 6 |  |  |  |  |  | 21 | 11 | 13 | 46 |  |
| `k` | 245256 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 1224 |  | 21 |  |  |  |  | 3 |  |  | 14 | 7 | 14 | 3 | 7 | 2 | 29 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 1727276 | `-` 100, `?` 0, `F` 0, `B` 0 |
| fight | 1102908 | `F` 40, `R` 35, `C` 10, `B` 10 |
| tribute | 858370 | `T` 49, `B` 26, `F` 23, `S` 1 |
| recall | 1146794 | `K` 34, `H` 22, `k` 21, `R` 10 |
| hold+recall | 928366 | `Q` 77, `P` 17, `F` 5, `B` 1 |
| teleport | 18432 | `F` 64, `B` 33, `C` 1, `R` 1 |
| camp | 5072446 | `F` 80, `B` 17, `G` 2, `P` 1 |
| hold | 1362279 | `P` 82, `F` 14, `B` 3, `R` 1 |
| spawn-heal | 251 | `H` 52, `F` 33, `B` 14, `R` 1 |
| bag->altar | 3460698 | `B` 83, `F` 13, `C` 2, `R` 2 |
| bag->camp | 1351999 | `B` 61, `F` 32, `R` 5, `C` 2 |
| bag-other | 746139 | `B` 53, `R` 22, `F` 13, `C` 11 |
| empty->camp | 6936513 | `F` 89, `R` 5, `G` 2, `C` 2 |
| empty->spawn | 934093 | `R` 50, `F` 38, `G` 3, `C` 3 |
| empty-other | 2129108 | `F` 72, `C` 10, `Y` 6, `R` 6 |
| idle-off | 1757376 | `F` 66, `B` 20, `G` 8, `h` 2 |
| idle-spawn | 53198 | `F` 69, `G` 18, `B` 11, `E` 1 |

## 2. Earnings (per game per side unless noted)

| metric | astraeus-ef8f0b8 | m3-a2 |
|---|---|---|
| gems captured | 883 | 879 |
| gems tributed | 813 | 819 |
| gems taken by kills | 45.2 | 47.2 |
| gems lost at death to champions | 47.0 | 44.8 |
| gems lost at death to camps | 6.8 | 7.4 |
| gold earned (lifetime) | 5160 | 5167 |
| r1-300 gems captured | 233 | 233 |
| r1-300 gems tributed | 164 | 165 |
| r1-300 gems lost at death | 5.4 | 4.7 |
| gems captured per camp-hit round | 1.1 | 1.1 |
| gems captured per hold round | 4.2 | 4.1 |
| gems captured per (camp+hold) round | 0.9 | 0.9 |
| gems tributed per 100 alive rounds | 18.8 | 18.8 |
| mean bag carried per alive round | 16.9 | 16.8 |
| % alive rounds carrying 30+ | 14.2 | 14.3 |
| tributes per 1000 alive rounds | 8.0 | 7.9 |
| mean bag at tribute | 23.6 | 24.0 |
| walk steps per tributed gem | 3.6 | 3.7 |
| bag-walk rounds per tributed gem | 1.1 | 1.1 |
| bag-walk rounds just before a tribute (mean trip) | 6.8 | 6.8 |
| idle-off rounds in stretches of 50+ (% of idle-off) | 14.8 | 14.2 |
| idle-off rounds in 50+ stretches by branch at its start, per game | `F` 19.0, `G` 10.9, `B` 9.3, `R` 1.2 | `F` 15.7, `B` 10.8, `G` 10.0, `R` 1.0 |
| altar locks placed / tribute attempts blocked, per game | 3.61 / 0.00 | 3.60 / 0.00 |
| real recalls per game (completed) | 59.5 (51.3) | 59.2 (51.2) |
| tribute cancels per game (cause) | death 0.01, lock 0.22, manual 0.19, stun 0.17 | death 0.01, lock 0.23, manual 0.17, stun 0.18 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | astraeus-ef8f0b8 | 103 | 230 | 342 | 207 |
| gems captured | m3-a2 | 103 | 230 | 339 | 208 |
| gems tributed | astraeus-ef8f0b8 | 62.1 | 185 | 336 | 230 |
| gems tributed | m3-a2 | 62.2 | 187 | 335 | 236 |
| alive champion-rounds | astraeus-ef8f0b8 | 650 | 1062 | 1411 | 1203 |
| alive champion-rounds | m3-a2 | 651 | 1066 | 1416 | 1216 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `R` | `F` | `B` | `S` | `G` | `C` | `Y` | `E` | `X` | `?` | `W` | `H` |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 24.3/g, 93.8% done, 23.9% bag, 18.7 from spawn | 16.7/g, 81.5% done, 27.7% bag, 20.6 from spawn | 11.1/g, 75.7% done, 8.0% bag, 23.6 from spawn | 5.5/g, 90.6% done, 100.0% bag, 22.1 from spawn | 1.0/g, 94.9% done, 0.2% bag, 37.5 from spawn | 0.6/g, 68.6% done, 4.5% bag, 21.5 from spawn | 0.3/g, 70.1% done, 63.4% bag, 32.1 from spawn | - | 0.0/g, 80.0% done, 76.0% bag, 34.4 from spawn | 0.0/g, 50.0% done, 33.3% bag, 20.8 from spawn | - | 0.0/g, 100.0% done, 100.0% bag, 20.0 from spawn | - |
| m3-a2 | 23.9/g, 94.6% done, 24.5% bag, 18.7 from spawn | 16.7/g, 81.4% done, 27.5% bag, 21.0 from spawn | 10.9/g, 75.9% done, 8.0% bag, 23.9 from spawn | 5.5/g, 90.4% done, 100.0% bag, 22.5 from spawn | 1.0/g, 94.3% done, 0.2% bag, 38.3 from spawn | 0.6/g, 69.6% done, 4.6% bag, 22.1 from spawn | 0.3/g, 69.7% done, 65.0% bag, 34.2 from spawn | 0.1/g, 52.1% done, 0.6% bag, 25.2 from spawn | 0.0/g, 85.0% done, 70.0% bag, 36.2 from spawn | 0.0/g, 72.7% done, 9.1% bag, 23.7 from spawn | 0.0/g, 66.7% done, 6.7% bag, 11.0 from spawn | 0.0/g, 60.0% done, 100.0% bag, 24.2 from spawn | 0.0/g, 100.0% done, 100.0% bag, 2.0 from spawn |

Bag size at tribute (% of tributes): astraeus-ef8f0b8: 0-19 63.2, 20-39 21.2, 40-59 10.3, 60-79 3.0, 80-99 0.9, 100+ 1.4; m3-a2: 0-19 62.7, 20-39 21.3, 40-59 10.7, 60-79 3.0, 80-99 0.8, 100+ 1.5

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | r1-300 turns/gem (n) | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 1 | 26 | 17.0 | 125 | 0.10 | - | 13.1 | 92.3 | 7.7 | 0.0 | 1.2 | 8.5 | 0.12 | 65.4 |
| Monolith | 2 | 103 | 36.6 | 81.4 | 0.19 | - | 21.7 | 90.3 | 6.8 | 2.9 | 1.4 | 4.7 | 0.05 | 35.0 |
| Monolith | 3+ | 687 | 88.9 | 75.1 | 0.42 | - | 26.4 | 97.5 | 1.5 | 1.0 | 1.6 | 6.0 | 0.03 | 30.3 |
| Golem | 1 | 3913 | 14.3 | 31.0 | 0.35 | 0.23 (18) | 27.4 | 96.1 | 2.7 | 1.2 | 1.0 | 5.7 | 0.03 | 12.4 |
| Golem | 2 | 4986 | 24.2 | 41.6 | 0.57 | 0.82 (142) | 35.9 | 97.7 | 1.6 | 0.7 | 1.0 | 5.6 | 0.03 | 8.9 |
| Golem | 3+ | 8603 | 46.6 | 75.3 | 0.97 | 1.55 (2524) | 62.2 | 98.0 | 1.4 | 0.6 | 1.1 | 6.1 | 0.05 | 10.5 |
| Elk | 1 | 26991 | 12.3 | 21.8 | 0.61 | 0.84 (1710) | 25.5 | 97.6 | 1.5 | 0.9 | 1.0 | 6.5 | 0.03 | 7.3 |
| Elk | 2 | 32205 | 20.5 | 28.6 | 0.96 | 1.38 (8226) | 35.2 | 98.5 | 1.1 | 0.4 | 1.0 | 6.3 | 0.03 | 5.7 |
| Elk | 3+ | 30735 | 28.9 | 28.5 | 1.16 | 1.54 (15417) | 37.1 | 98.4 | 1.3 | 0.3 | 1.0 | 6.4 | 0.06 | 7.0 |
| Wolf | 1 | 46957 | 11.1 | 16.4 | 1.30 | 2.42 (7276) | 22.5 | 98.1 | 1.3 | 0.7 | 1.0 | 6.6 | 0.02 | 4.2 |
| Wolf | 2 | 37873 | 16.8 | 24.3 | 1.76 | 2.73 (11072) | 28.8 | 98.6 | 1.0 | 0.4 | 1.0 | 6.5 | 0.05 | 3.6 |
| Wolf | 3+ | 21933 | 25.0 | 29.6 | 2.18 | 2.83 (10559) | 35.6 | 98.8 | 0.9 | 0.3 | 1.0 | 6.5 | 0.04 | 4.4 |
| GemCl | 1 | 98313 | 3.1 | 3.2 | 0.22 | 0.24 (33660) | 0.0 | 97.1 | 1.8 | 1.1 | 1.0 | 7.9 | 0.05 | 2.3 |
| GemCl | 2 | 21422 | 4.3 | 7.1 | 0.23 | 0.27 (8089) | 0.0 | 97.7 | 1.6 | 0.7 | 1.0 | 6.7 | 0.10 | 2.7 |
| GemCl | 3+ | 4302 | 5.7 | 5.3 | 0.23 | 0.25 (1634) | 0.0 | 97.6 | 1.7 | 0.8 | 1.1 | 7.1 | 0.10 | 4.7 |
| GoldCl | 1 | 87343 | 2.7 | 3.8 | 0.63 | 1.03 (32919) | 0.0 | 96.5 | 1.5 | 2.0 | 1.0 | 9.6 | 0.03 | 1.8 |
| GoldCl | 2 | 14148 | 3.5 | 19.7 | 0.89 | 1.43 (6145) | 0.0 | 96.8 | 1.1 | 2.1 | 1.0 | 9.2 | 0.04 | 1.7 |
| GoldCl | 3+ | 1158 | 4.7 | 20.7 | 0.77 | 0.73 (622) | 0.0 | 97.2 | 1.4 | 1.4 | 1.0 | 8.6 | 0.06 | 3.2 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 69.1 | 59.8 | 0.78 | 21.7 | 97.5 | 1.5 | 0.92 | 1.0 | 7.5 | 0.05 | 0.01 | 0.008 |
| m3-a2 | 68.5 | 59.6 | 0.78 | 21.8 | 97.6 | 1.4 | 1.05 | 1.0 | 7.5 | 0.04 | 0.00 | 0.008 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 15.08 | 12.13 | 2.34 | 0.08 | 16.47 | 14.45 | 0.87 | 0.99 | 0.21 | 0.03 | 1.30 | 0.71 | 0.83 | 0.91 | 0.20 | 0.02 | 1.60 | 0.84 |
| m3-a2 | 14.81 | 12.02 | 2.33 | 0.08 | 16.38 | 14.33 | 0.81 | 1.07 | 0.19 | 0.03 | 1.26 | 0.78 | 0.84 | 0.88 | 0.19 | 0.02 | 1.62 | 0.84 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 60.9 | 7.3 | 1.9 | 2.1 | 27.8 |
| astraeus-ef8f0b8 | mid | 75.8 | 7.2 | 1.9 | 1.0 | 14.1 |
| astraeus-ef8f0b8 | enemy | 61.3 | 7.3 | 1.7 | 2.1 | 27.6 |
| m3-a2 | own | 61.3 | 7.3 | 1.7 | 2.1 | 27.6 |
| m3-a2 | mid | 75.8 | 7.2 | 1.9 | 1.0 | 14.1 |
| m3-a2 | enemy | 60.9 | 7.3 | 1.9 | 2.1 | 27.8 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 68.6 | 7.2 | 1.3 | 2.1 | 20.8 |
| astraeus-ef8f0b8 | mid | 86.3 | 5.2 | 1.0 | 0.8 | 6.8 |
| astraeus-ef8f0b8 | enemy | 68.8 | 7.2 | 1.3 | 2.1 | 20.6 |
| m3-a2 | own | 68.8 | 7.2 | 1.3 | 2.1 | 20.6 |
| m3-a2 | mid | 86.3 | 5.2 | 1.0 | 0.8 | 6.8 |
| m3-a2 | enemy | 68.6 | 7.2 | 1.3 | 2.1 | 20.8 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | Wolf | 63.2 | 8.1 | 1.6 | 78.0 | 5.8 | 1.5 | 63.6 | 8.1 | 1.6 |
| m3-a2 | Wolf | 63.6 | 8.1 | 1.6 | 78.0 | 5.8 | 1.5 | 63.2 | 8.1 | 1.6 |
| astraeus-ef8f0b8 | Elk | 46.5 | 10.7 | 1.6 | 60.5 | 11.1 | 1.9 | 46.8 | 10.7 | 1.6 |
| m3-a2 | Elk | 46.8 | 10.7 | 1.6 | 60.5 | 11.1 | 1.9 | 46.5 | 10.7 | 1.6 |
| astraeus-ef8f0b8 | Golem | 59.5 | 9.8 | 0.9 | 72.5 | 10.2 | 0.7 | 59.6 | 9.8 | 0.9 |
| m3-a2 | Golem | 59.6 | 9.8 | 0.9 | 72.5 | 10.2 | 0.7 | 59.5 | 9.8 | 0.9 |
| astraeus-ef8f0b8 | Monolith | 91.9 | 3.1 | 0.1 | 93.3 | 2.1 | 0.2 | 91.6 | 3.1 | 0.1 |
| m3-a2 | Monolith | 91.6 | 3.1 | 0.1 | 93.3 | 2.1 | 0.2 | 91.9 | 3.1 | 0.1 |
| astraeus-ef8f0b8 | GemCl | 37.2 | 2.9 | 4.1 | 48.3 | 3.4 | 9.0 | 37.6 | 2.9 | 4.0 |
| m3-a2 | GemCl | 37.6 | 2.9 | 4.0 | 48.3 | 3.4 | 9.0 | 37.2 | 2.9 | 4.1 |
| astraeus-ef8f0b8 | GoldCl | 54.6 | 1.8 | 7.0 | 69.7 | 1.5 | 6.1 | 55.0 | 1.8 | 6.8 |
| m3-a2 | GoldCl | 55.0 | 1.8 | 6.8 | 69.7 | 1.5 | 6.1 | 54.6 | 1.8 | 7.0 |

Upper bound on gems left asleep per game (each asleep round = 1/(respawn+15) of a farm cycle): astraeus-ef8f0b8: own 1106, mid 556, enemy 1105; m3-a2: own 1105, mid 556, enemy 1106

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| astraeus-ef8f0b8 | 59.9 (723) | 4.0 (90) | 4.3 (70) | 19.6/0.8/0.8 |
| m3-a2 | 59.4 (718) | 4.1 (92) | 4.3 (69) | 19.4/0.9/0.8 |

## 5. Deaths

| metric | astraeus-ef8f0b8 | m3-a2 |
|---|---|---|
| deaths/game (to champions + camps) | 3.7 + 0.70 | 3.4 + 0.71 |
| median first-death round (none = length+1) | 360 | 380 |
| % of games this side died first | 43.8 | 40.6 |
| % alone (no ally within 8) | 29.8 | 29.2 |
| % ally within 4 | 47.7 | 49.5 |
| % 2+ enemies within 8 | 67.1 | 62.9 |
| % on own ground | 59.7 | 55.9 |
| % on mid ground | 19.1 | 19.5 |
| % on enemy ground | 21.3 | 24.7 |
| % walking toward spawn (last 4 rounds) | 36.6 | 35.3 |
| % branch R in last 4 rounds | 89.2 | 88.8 |
| % carrying 30+ gems | 10.1 | 10.3 |
| mean enemies within 8 | 2.2 | 2.1 |
| mean gems carried at death | 11.7 | 12.4 |
| r1-300 deaths/game | 0.85 | 0.81 |

Gems lost at death by champion type, per game (% of the side's loss): astraeus-ef8f0b8: Prism 24.1 (46.5%), Marcella 7.6 (14.7%), Vendetta 6.3 (12.1%), Heart of Ruin 5.8 (11.1%); m3-a2: Prism 25.2 (49.9%), Marcella 7.2 (14.2%), Vendetta 6.7 (13.2%), Heart of Ruin 4.9 (9.7%)

Deaths carrying 100+ gems: astraeus-ef8f0b8 0.11/game holding 51.6% of gems lost; m3-a2 0.10/game holding 54.2% of gems lost

Branch at death (last D line): astraeus-ef8f0b8: `R` 83.5%, `F` 7.0%, `E` 6.0%, `B` 1.3%, `K` 0.9%, `C` 0.3%; m3-a2: `R` 83.2%, `F` 6.6%, `E` 6.0%, `B` 1.4%, `K` 1.0%, `C` 0.4%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0 | 0.9 | 4.5 | 4.1 | 3.7 |
| astraeus-ef8f0b8 | 1 | 1.6 | 3.1 | 3.8 | 4.1 |
| astraeus-ef8f0b8 | 2 | 1.2 | 1.7 | 2.6 | 4.5 |
| astraeus-ef8f0b8 | 3+ | 0.7 | 0.9 | 1.4 | 5.5 |
| m3-a2 | 0 | 0.8 | 4.5 | 3.7 | 2.8 |
| m3-a2 | 1 | 1.6 | 3.4 | 3.8 | 3.5 |
| m3-a2 | 2 | 1.1 | 2.0 | 2.5 | 3.6 |
| m3-a2 | 3+ | 0.7 | 0.9 | 1.4 | 4.4 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 3.4 | 0.44 | 28.4 | 49.6 | 10.5 | 11.6 | -1.5 |
| m3-a2 | 3.7 | 0.50 | 28.4 | 50.4 | 11.6 | 10.5 | 1.5 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 17.08 / -0.00 | 2.64 / -0.13 | 0.65 / -0.23 | 2.43 / +0.11 | 1.89 / -0.02 | 0.93 / -0.13 | 0.46 / +0.24 | 0.80 / +0.05 | 1.52 / -0.08 |
| m3-a2 | 17.08 / +0.00 | 2.43 / -0.11 | 0.46 / -0.24 | 2.64 / +0.13 | 1.89 / +0.02 | 0.80 / -0.05 | 0.65 / +0.23 | 0.93 / +0.13 | 1.52 / +0.08 |
| pooled | 17.08 / +0.00 | 2.53 / -0.12 | 0.55 / -0.24 | 2.53 / +0.12 | 1.89 / +0.00 | 0.86 / -0.09 | 0.55 / +0.24 | 0.86 / +0.09 | 1.52 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0.62 / -0.06 / 11.8 | 2.10 / -0.02 / 10.8 | 6.16 / -0.02 / 9.5 | 11.17 / -0.01 / 9.6 | 5.86 / -0.00 / 11.2 | 1.94 / -0.00 / 13.4 | 0.55 / -0.01 / 17.5 |
| m3-a2 | 0.55 / +0.01 / 15.5 | 1.94 / +0.00 / 12.3 | 5.86 / +0.00 / 10.9 | 11.17 / +0.01 / 10.6 | 6.16 / +0.02 / 12.0 | 2.10 / +0.02 / 14.1 | 0.62 / +0.06 / 19.6 |
| pooled | 0.58 / -0.03 / 13.5 | 2.02 / -0.01 / 11.5 | 6.01 / -0.01 / 10.2 | 11.17 / +0.00 / 10.1 | 6.01 / +0.01 / 11.6 | 2.02 / +0.01 / 13.8 | 0.58 / +0.03 / 18.6 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 3212 | 487 | 60.0 | 58.0 (n=2094) | 65.5 (n=589) | 81.0 (n=42) |
| tributed r400 | 3167 | 203 | 65.2 | 57.8 (n=1603) | 70.7 (n=1065) | 85.8 (n=296) |
| tributed r600 | 2802 | 121 | 71.1 | 58.1 (n=1122) | 75.5 (n=979) | 89.0 (n=580) |
| tributed+carried r200 | 3212 | 426 | 63.4 | 59.8 (n=2202) | 75.5 (n=506) | 87.2 (n=78) |
| tributed+carried r400 | 3167 | 183 | 71.6 | 61.7 (n=1649) | 80.2 (n=964) | 93.5 (n=371) |
| tributed+carried r600 | 2802 | 92 | 77.6 | 63.5 (n=1119) | 82.7 (n=904) | 93.9 (n=687) |

| predictor | win % |
|---|---|
| team that did not die first wins | 64.1 (n=2710) |
| more kills wins | 85.3 (n=2237) |
| more r1-300 kills wins | 71.4 (n=1137) |
| more gems captured wins | 88.6 (n=3186) |
| more r1-300 gems captured wins | 66.3 (n=2950) |
| fewer gems lost at death wins | 79.6 (n=1862) |
| more mid-group captures wins | 83.8 (n=1159) |

Games where neither side tributes 200: 29 (gen-archipelago-603502017, gen-arena-603502615, gen-arena-603502620, gen-arena-603602603, gen-atoll-603801911, gen-shared-gems-600201600, gen-shared-gems-603601600, mut-gift-wrapping-603701845).

Game length: median 958, quartiles 727-1296, min 283, max 2000; 8.0% reach round 2000; 92.0% end on 1000 gems.

## Examples

**bagdeath** (1051 in all, largest first, one per game):

- `replays/batch-20261030-120859-ab-m3-a2-gen/227-gen-fortress-600102222-12.repl26a` (b37ec1df5748abb4) r1907 team A (m3-a2): Prism died with 2390 gems (champ, allies<=8 0, enemies<=8 1, branch R)
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/019-gen-archipelago-603502017-12.repl26a` (b2175c6299ca8522) r1817 team A (m3-a2): Vendetta died with 2036 gems (champ, allies<=8 0, enemies<=8 2, branch E)
- `replays/batch-20261030-120859-ab-m3-a2-gen/228-gen-fortress-600102222-21.repl26a` (a88ee4fba5928dcf) r1209 team B (m3-a2): Prism died with 1907 gems (camp, allies<=8 0, enemies<=8 0, branch R)
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6038/509-mut-treasure-box-603801856-12.repl26a` (7e7ccc48b3fee916) r1206 team A (m3-a2): Prism died with 1237 gems (champ, allies<=8 2, enemies<=8 2, branch B)
- `replays/batch-20261030-120859-ab-m3-a2-ladder/074-01boss-battle-21.repl26a` (251b26b1d95a20bd) r641 team A (astraeus-ef8f0b8): Vesper Vale died with 1063 gems (champ, allies<=8 0, enemies<=8 2, branch R)
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6037/191-gen-dungeon-603702426-12.repl26a` (de0340c65dea512c) r764 team A (m3-a2): Prism died with 1013 gems (champ, allies<=8 2, enemies<=8 1, branch T)

**stolen** (6348 in all, largest first, one per game):

- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/039-gen-arena-603502615-12.repl26a` (0fee013937a66a29) r641 team A (m3-a2): GoldCl (428 gems, enemy) cleared r622 stolen
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/040-gen-arena-603502615-21.repl26a` (11a698721c11fe80) r1656 team B (m3-a2): GoldCl (428 gems, enemy) cleared r1630 stolen
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/295-gen-huge-shared-603505208-12.repl26a` (237e7e787689abff) r195 team B (astraeus-ef8f0b8): GemCl (400 gems, mid) cleared r174 stolen
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/296-gen-huge-shared-603505208-21.repl26a` (7bbd61603320e424) r386 team A (astraeus-ef8f0b8): GemCl (400 gems, mid) cleared r370 stolen
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6036/033-gen-arena-603602603-12.repl26a` (3d6afadfc22824f6) r1829 team A (m3-a2): GoldCl (400 gems, enemy) cleared r1773 stolen
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6036/034-gen-arena-603602603-21.repl26a` (d12228d18c7e4d7d) r155 team B (m3-a2): GoldCl (400 gems, enemy) cleared r140 stolen

**idle-off30** (2608 in all, largest first, one per game):

- `replays/batch-20261030-120859-ab-m3-a2-fresh-gen-s1/391-gen-shared-gems-600201600-12.repl26a` (c8b8f680117cbe15) r27 team A (m3-a2): Willow#2 idle off spawn 1974 rounds at (24, 18) branch G
- `replays/batch-20261030-120859-ab-m3-a2-fresh-gen-s1/392-gen-shared-gems-600201600-21.repl26a` (cdc20a7ac530d546) r27 team A (astraeus-ef8f0b8): Willow#2 idle off spawn 1974 rounds at (24, 18) branch G
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6037/478-mut-gift-wrapping-603701845-21.repl26a` (0104a5e77124ca57) r59 team A (astraeus-ef8f0b8): Prism#0 idle off spawn 1942 rounds at (13, 11) branch F
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/015-gen-archipelago-603502014-12.repl26a` (0f0ddf0863bb6ee8) r225 team A (m3-a2): Prism#0 idle off spawn 1776 rounds at (21, 10) branch F
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/016-gen-archipelago-603502014-21.repl26a` (45036734d2656509) r225 team A (astraeus-ef8f0b8): Prism#0 idle off spawn 1776 rounds at (21, 10) branch F
- `replays/batch-20261030-120859-ab-m3-a2-fresh-6035/503-mut-the-line-603501835-12.repl26a` (45ab4c1954d23267) r230 team B (astraeus-ef8f0b8): Issac#5 idle off spawn 1771 rounds at (10, 24) branch F

