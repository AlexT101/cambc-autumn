import gzip,json,sys,os
d=sys.argv[1]
g=[x for x in os.listdir(d) if len(x)==16][0]
R=json.load(gzip.open(f"{d}/{g}/rounds.json.gz"))
meta=json.load(open(f"{d}/{g}/meta.json"))
rounds=R['round']
for c,m in zip(R['champions'],meta['champions']):
    best=(0,0,None)
    run=0;start=0
    for i in range(1,len(rounds)):
        same=c['x'][i]==c['x'][i-1] and c['y'][i]==c['y'][i-1] and c['alive'][i]
        if same:
            run+=1
            if run>best[0]: best=(run,rounds[start],(c['x'][i],c['y'][i]),c['gems'][i],c['chan'][i])
        else: run=0;start=i
    print(m['team'],m['name'],best)
print("locks end", R['locks'][-1])
print("gems", R['gems'][0][-1], R['gems'][1][-1])
