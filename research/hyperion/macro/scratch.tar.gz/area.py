import json,sys,os
d=sys.argv[1]; cx,cy,r=map(int,sys.argv[2:5])
mp=json.load(open(f"{d}/maps/"+os.listdir(f"{d}/maps")[0]))
def S(k): return {tuple(p) for p in mp[k]}
W,H,A,B=S('walls'),S('holes'),S('altars'),S('bushes')
camps={(c['x'],c['y']):c['type'][0] for c in mp['camps']}
for y in range(cy+r,cy-r-1,-1):
    row=f"{y:3} "
    for x in range(cx-r,cx+r+1):
        p=(x,y); row+= '#' if p in W else 'o' if p in H else 'A' if p in A else '"' if p in B else camps.get(p,'.')
    print(row)
print('    '+''.join(str(x%10) for x in range(cx-r,cx+r+1)))
