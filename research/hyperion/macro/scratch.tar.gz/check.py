import sys, zipfile, glob, os, re, collections
for f in sorted(glob.glob(os.path.join(sys.argv[1], '*.repl26a'))):
    side = re.search(r'-(12|21)\.repl26a$', f).group(1)
    ours = 'team-a.stdout' if side == '12' else 'team-b.stdout'
    txt = zipfile.ZipFile(f).read(ours).decode(errors='replace')
    posts = {}  # (round, ally) -> (x, y, sev)
    for line in txt.splitlines():
        p = line.split()
        if p and p[0] == 'DPOST': posts[(int(p[1]), int(p[2]))] = (int(p[3]), int(p[4]), int(p[5]))
    ok = bad = 0; age = collections.Counter(); sev = collections.Counter(); steps = collections.Counter(); badex = []
    for line in txt.splitlines():
        p = line.split()
        if p and p[0] == 'ASSIST':
            r, ally, s, st, x, y, rr = int(p[1]), int(p[3]), int(p[4]), int(p[5]), int(p[6]), int(p[7]), int(p[8])
            age[r - rr] += 1; sev[s] += 1; steps[st] += 1
            if posts.get((rr, ally)) == (x, y, s): ok += 1
            else: bad += 1; badex.append((r, ally, rr, x, y, s, posts.get((rr, ally))))
    nposts = len(posts)
    print(os.path.basename(f), 'posts', nposts, 'assist ok', ok, 'bad', bad, 'age', dict(age), 'sev', dict(sev), 'steps', dict(sorted(steps.items())))
    for b in badex[:3]: print('  bad', b)
