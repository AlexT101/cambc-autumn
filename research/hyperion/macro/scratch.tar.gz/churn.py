import sys, glob, zipfile, collections
for label in sys.argv[2:]:
    turns = changes = branch = 0; bc = collections.Counter(); own = collections.Counter(); needs = 0; noclaim = 0
    for d in glob.glob(f'{sys.argv[1]}/{label}/*'):
        side = d[-1]
        rep = glob.glob(f'{d}/*.repl26a')[0]
        with zipfile.ZipFile(rep) as z: L = z.read(f'team-{side}.stdout').replace(b'\0', b'').decode(errors='replace').splitlines()
        last = {}
        byround = collections.defaultdict(list)
        for l in L:
            p = l.split()
            if len(p) < 6 or p[0] != 'D': continue
            r, h, br, cl = int(p[1]), p[2], p[3], int(p[5])
            turns += 1; bc[br] += 1
            if cl < 0: noclaim += 1
            if h in last and last[h] != cl: changes += 1
            last[h] = cl
            if len(p) >= 9:
                needs += p[7] == '1'
                if cl >= 0: byround[r].append((cl, p[8]))
        for r, v in byround.items():
            c = collections.defaultdict(list)
            for cl, o in v: c[cl].append(o)
            for cl, os_ in c.items():
                if len(os_) >= 2: own[os_.count('1')] += 1
    print(f'{label}: turns {turns} claim-changes/100 turns {100*changes/turns:.1f} noclaim {100*noclaim/turns:.0f}% need {100*needs/turns:.1f}% shared-claim owners-count {dict(own)} branches {dict(bc.most_common(8))}')
