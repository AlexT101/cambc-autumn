import sys, glob, re, os, subprocess, json
root = sys.argv[1]
for label in sys.argv[2:]:
    tot = dict(n=0, win=0, gems=0, deaths=0, kills=0, dup=0, rounds=0)
    for d in sorted(glob.glob(f'{root}/{label}/*')):
        side = d[-1]
        log = open(f'{d}/log.txt').read()
        rows = {m.group(1): m.groups() for m in re.finditer(r'^\s+([AB])\s+(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)', log, re.M)}
        me, them = ('A', 'B') if side == 'a' else ('B', 'A')
        if me not in rows: print('fail', d); continue
        won = re.search(r'Team (\w) \(', log)
        tot['n'] += 1
        tot['win'] += bool(won and won.group(1) == me)
        tot['gems'] += int(rows[me][2]); tot['kills'] += int(rows[me][3]); tot['deaths'] += int(rows[me][4])
        rep = glob.glob(f'{d}/*.repl26a')[0]
        o = subprocess.run(['python3', os.path.dirname(__file__) + '/dup.py', rep, 'team-a' if side == 'a' else 'team-b'], capture_output=True, text=True).stdout
        m = re.search(r'rounds (\d+) dup-rounds (\d+)', o)
        tot['rounds'] += int(m.group(1)); tot['dup'] += int(m.group(2))
    n = max(tot['n'], 1)
    print(f"{label}: games {tot['n']} wins {tot['win']} mean gems {tot['gems']/n:.0f} deaths {tot['deaths']/n:.1f} kills {tot['kills']/n:.1f} dup-rounds {100*tot['dup']/max(tot['rounds'],1):.0f}%")
