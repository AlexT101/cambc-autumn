import pickle, collections, statistics as st, re
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits.pkl', 'rb'))
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
fsidx = {}
for name, (fs, wk, D, wh) in games.items():
    d = collections.defaultdict(dict)
    for r, h, g, k, l in fs: d[h][r] = (int(g[1:]), k, l)
    fsidx[name] = d
def choice(v):
    d = fsidx[v['game']][v['c']]
    for r in range(v['r0'], v['r0'] - 15, -1):
        if r in d and d[r][0] == v['G'] and d[r][1]['br'] not in ('passing',):
            return r, d[r]
    for r in range(v['r0'], v['r0'] - 15, -1):
        if r in d and d[r][0] == v['G']: return r, d[r]
    return None, None
rows = collections.defaultdict(lambda: {'chip': [], 'clear': []})
for v in allv:
    r, c = choice(v)
    if not c: key = 'no-FS'
    else:
        k = c[1]; key = k['br'] + '/' + k['rsn']
        if key == 'cut-short/?': key = 'after-strike-walk-on'
        v['choice'] = (r, c)
    rows[key]['chip' if not v['cleared'] else 'clear'].append(v)
print(f"{'choice branch':24s} {'chips':>5s} {'solo':>5s} {'dealt':>7s} {'taken':>7s} {'d/t':>5s} | {'clears':>6s} {'d/t':>5s} | chip: A>realS  A>hp  med A  med realS  med hp")
for key, d in sorted(rows.items(), key=lambda x: -len(x[1]['chip'])):
    ch, cl = d['chip'], d['clear']
    dl = sum(v['dealt'] for v in ch); tk = sum(v['taken'] for v in ch)
    dl2 = sum(v['dealt'] for v in cl); tk2 = sum(v['taken'] for v in cl)
    A=[];S=[];H=[]
    for v in ch:
        if 'choice' not in v: continue
        k = v['choice'][1][1]; hp, mx = map(float, k['hp'].split('/')); A.append(float(k['alone'])); S.append(hp - float(k['line'])*mx); H.append(hp)
    extra = f"{sum(a>s for a,s in zip(A,S))/max(len(A),1):6.2f} {sum(a>h for a,h in zip(A,H))/max(len(A),1):5.2f} {st.median(A) if A else 0:6.0f} {st.median(S) if S else 0:8.0f} {st.median(H) if H else 0:6.0f}"
    print(f"{key:24s} {len(ch):5d} {sum(not v['mates'] for v in ch)/max(len(ch),1):5.2f} {dl:7.0f} {tk:7.0f} {dl/max(tk,1):5.2f} | {len(cl):6d} {dl2/max(tk2,1):5.2f} | {extra}")
tot = [v for v in allv if not v['cleared']]
print('total chips', len(tot), 'dealt', sum(v['dealt'] for v in tot), 'taken', sum(v['taken'] for v in tot))
pickle.dump(allv, open('/tmp/claude-1000/m4-diag/visits2.pkl', 'wb'))
