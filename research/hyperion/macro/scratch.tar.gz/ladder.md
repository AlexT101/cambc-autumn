# Turn budget: 70 games from replays/batch-20261030-094349-ab-m3-mirror-ladder

Mirror mode: identical replays (a map pair swapped between two copies of one bot) count once; sides are the game winner (W) and loser (L).

Trace: 0 of 140 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 0.0% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all W | all L | r1-150 W | r1-150 L | r151-400 W | r151-400 L | r401-800 W | r401-800 L | r801+ W | r801+ L | r1-300 W | r1-300 L |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 3.9 | 9.1 | 1.6 | 3.4 | 3.3 | 6.3 | 4.3 | 10.8 | 5.4 | 13.2 | 2.3 | 4.3 |
| fight | 4.8 | 4.8 | 4.7 | 4.5 | 4.4 | 4.4 | 4.5 | 4.6 | 5.7 | 5.8 | 4.6 | 4.4 |
| tribute | 3.3 | 1.6 | 1.3 | 1.0 | 2.3 | 1.6 | 4.2 | 1.9 | 4.4 | 1.6 | 1.7 | 1.3 |
| recall | 3.6 | 3.5 | 3.4 | 3.3 | 4.1 | 4.0 | 3.7 | 3.8 | 3.0 | 2.8 | 3.9 | 3.6 |
| hold+recall | 2.6 | 2.4 | 2.9 | 2.6 | 3.3 | 3.1 | 2.7 | 2.5 | 1.6 | 1.3 | 3.1 | 2.9 |
| teleport | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| camp | 16.6 | 14.9 | 23.7 | 23.8 | 18.9 | 17.6 | 16.2 | 14.1 | 10.8 | 7.9 | 21.6 | 21.1 |
| hold | 6.4 | 5.7 | 5.6 | 4.9 | 6.7 | 5.9 | 5.8 | 5.1 | 7.2 | 6.6 | 6.1 | 5.4 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 15.0 | 13.6 | 9.8 | 10.4 | 15.6 | 15.2 | 17.3 | 15.2 | 14.2 | 11.8 | 12.5 | 12.8 |
| bag->camp | 4.4 | 4.4 | 3.5 | 3.7 | 5.2 | 5.6 | 5.0 | 4.7 | 3.2 | 3.3 | 4.4 | 4.7 |
| bag-other | 2.7 | 3.4 | 1.5 | 1.8 | 2.9 | 3.2 | 3.2 | 3.8 | 2.7 | 4.0 | 2.1 | 2.2 |
| empty->camp | 22.8 | 21.3 | 31.2 | 29.2 | 21.7 | 21.0 | 20.8 | 19.4 | 21.7 | 19.3 | 27.0 | 25.5 |
| empty->spawn | 3.1 | 3.5 | 3.2 | 2.9 | 3.0 | 2.9 | 2.7 | 3.4 | 3.7 | 4.8 | 3.0 | 2.9 |
| empty-other | 5.1 | 6.8 | 4.7 | 5.7 | 4.6 | 5.4 | 4.3 | 6.5 | 6.7 | 9.4 | 4.6 | 5.7 |
| idle-off | 5.2 | 4.4 | 2.9 | 2.7 | 3.9 | 3.5 | 5.0 | 4.0 | 8.3 | 6.7 | 3.2 | 3.2 |
| idle-spawn | 0.4 | 0.5 | 0.0 | 0.1 | 0.0 | 0.1 | 0.2 | 0.2 | 1.4 | 1.6 | 0.0 | 0.0 |

By attack type (all rounds):

| class | melee W | melee L | ranged W | ranged L |
|---|---|---|---|---|
| dead | 4.1 | 9.6 | 3.7 | 8.5 |
| fight | 5.9 | 5.8 | 3.1 | 3.4 |
| tribute | 3.5 | 2.1 | 3.1 | 0.8 |
| recall | 3.8 | 3.8 | 3.2 | 3.2 |
| hold+recall | 3.1 | 2.7 | 2.0 | 1.8 |
| teleport | 0.0 | 0.0 | 0.0 | 0.0 |
| camp | 15.6 | 13.6 | 18.3 | 16.9 |
| hold | 5.2 | 4.7 | 8.2 | 7.1 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 14.6 | 13.2 | 15.5 | 14.2 |
| bag->camp | 3.2 | 3.2 | 6.2 | 6.2 |
| bag-other | 2.7 | 3.0 | 2.8 | 3.9 |
| empty->camp | 24.0 | 22.7 | 21.0 | 19.2 |
| empty->spawn | 3.3 | 3.7 | 2.8 | 3.3 |
| empty-other | 5.8 | 7.6 | 3.9 | 5.6 |
| idle-off | 5.0 | 3.8 | 5.5 | 5.1 |
| idle-spawn | 0.1 | 0.3 | 0.8 | 0.8 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | W | 17346 | 4.6 | 2.2 | 18.0 | 7.3 | 1.5 | 2.6 | 0.0 | 0.0 | 6.3 | 54.5 |
| Cassi | L | 17346 | 9.6 | 2.3 | 17.2 | 8.5 | 1.5 | 2.5 | 0.0 | 0.0 | 4.9 | 50.7 |
| Heart of Ruin | W | 60584 | 4.5 | 8.4 | 18.0 | 4.4 | 3.2 | 3.5 | 0.0 | 0.0 | 6.1 | 48.7 |
| Heart of Ruin | L | 60584 | 11.1 | 7.8 | 15.5 | 2.5 | 1.7 | 3.3 | 0.0 | 0.0 | 5.0 | 50.4 |
| Issac | W | 17346 | 4.6 | 2.2 | 19.1 | 5.2 | 3.1 | 3.4 | 0.0 | 0.0 | 4.0 | 55.1 |
| Issac | L | 17346 | 9.6 | 2.2 | 17.0 | 2.8 | 2.0 | 3.3 | 0.0 | 0.1 | 3.8 | 56.0 |
| Marcella | W | 57120 | 3.6 | 5.6 | 12.6 | 7.9 | 3.5 | 4.2 | 0.0 | 0.2 | 5.5 | 54.0 |
| Marcella | L | 57120 | 9.2 | 5.3 | 11.5 | 6.6 | 2.0 | 4.0 | 0.0 | 0.8 | 4.3 | 53.9 |
| Prism | W | 47329 | 2.3 | 3.3 | 17.1 | 10.0 | 4.8 | 2.9 | 0.0 | 1.7 | 4.8 | 51.3 |
| Prism | L | 47329 | 6.3 | 3.7 | 17.6 | 11.6 | 0.4 | 3.2 | 0.0 | 1.6 | 5.0 | 49.0 |
| Ren | W | 2836 | 4.3 | 6.9 | 14.3 | 1.4 | 1.7 | 2.7 | 0.0 | 0.0 | 2.9 | 63.5 |
| Ren | L | 2836 | 4.3 | 8.2 | 10.6 | 1.2 | 2.7 | 4.3 | 0.0 | 3.2 | 1.8 | 61.4 |
| Ryth | W | 15649 | 5.3 | 10.5 | 12.1 | 2.9 | 3.8 | 3.7 | 0.0 | 0.4 | 4.2 | 54.6 |
| Ryth | L | 15649 | 10.9 | 10.5 | 7.6 | 14.1 | 4.0 | 3.9 | 0.0 | 0.1 | 2.0 | 44.5 |
| Tavi | W | 2946 | 16.6 | 4.6 | 13.9 | 4.5 | 2.9 | 2.3 | 0.0 | 4.5 | 6.6 | 43.6 |
| Tavi | L | 2946 | 20.1 | 5.3 | 15.7 | 2.2 | 0.9 | 2.6 | 0.0 | 3.9 | 4.7 | 43.9 |
| Varg | W | 6402 | 0.0 | 1.1 | 18.8 | 2.2 | 3.8 | 2.5 | 0.0 | 0.1 | 3.3 | 64.8 |
| Varg | L | 6402 | 2.5 | 1.2 | 17.8 | 1.7 | 1.6 | 3.1 | 0.0 | 0.0 | 1.8 | 67.7 |
| Vendetta | W | 36723 | 4.1 | 3.0 | 15.4 | 4.1 | 4.0 | 4.4 | 0.0 | 0.1 | 3.8 | 57.5 |
| Vendetta | L | 36723 | 8.7 | 3.4 | 14.2 | 3.2 | 2.5 | 4.5 | 0.0 | 0.0 | 2.5 | 57.7 |
| Vesper Vale | W | 24514 | 2.7 | 5.8 | 18.9 | 5.4 | 3.6 | 3.8 | 0.0 | 0.0 | 3.4 | 53.5 |
| Vesper Vale | L | 24514 | 9.1 | 5.8 | 15.4 | 4.9 | 1.3 | 3.6 | 0.0 | 0.1 | 4.1 | 53.5 |
| Willow | W | 37037 | 4.7 | 1.4 | 19.9 | 8.4 | 1.3 | 3.5 | 0.0 | 0.3 | 7.3 | 51.8 |
| Willow | L | 37037 | 9.5 | 1.9 | 16.8 | 2.5 | 0.6 | 3.2 | 0.0 | 0.3 | 6.2 | 57.6 |

Bot branch (D lines), % of champion-rounds:

| branch | all W | all L | r1-300 W | r1-300 L |
|---|---|---|---|---|
| `-` | 4.0 | 9.2 | 2.3 | 4.3 |
| `?` | 0.0 | 0.0 | 0.0 | 0.0 |
| `B` | 18.7 | 17.9 | 16.2 | 17.6 |
| `C` | 3.2 | 2.4 | 2.5 | 2.1 |
| `E` | 0.1 | 0.4 | 0.0 | 0.0 |
| `F` | 51.0 | 48.0 | 59.2 | 56.6 |
| `G` | 2.9 | 1.7 | 0.3 | 0.2 |
| `H` | 0.8 | 0.7 | 0.9 | 0.8 |
| `K` | 1.2 | 1.4 | 1.5 | 1.5 |
| `P` | 5.9 | 5.5 | 5.9 | 5.2 |
| `Q` | 2.0 | 1.8 | 2.4 | 2.2 |
| `R` | 6.3 | 8.9 | 6.2 | 7.2 |
| `S` | 0.1 | 0.0 | 0.1 | 0.0 |
| `T` | 2.1 | 0.9 | 0.8 | 0.6 |
| `W` | 0.0 | 0.0 | 0.0 | 0.0 |
| `X` | 0.4 | 0.2 | 0.3 | 0.3 |
| `h` | 0.4 | 0.4 | 0.7 | 0.7 |
| `k` | 0.8 | 0.6 | 0.7 | 0.5 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 42763 | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `?` | 279 | 4 | 1 | 28 |  |  |  |  | 4 |  |  |  |  |  |  |  | 61 | 1 |
| `B` | 119284 |  | 3 | 3 |  |  |  | 11 |  |  | 58 | 11 | 6 |  |  |  | 5 |  |
| `C` | 18244 |  | 19 |  |  |  |  |  |  |  | 14 | 5 | 13 | 18 | 6 | 24 |  |  |
| `E` | 1727 |  | 30 |  |  |  |  |  |  |  | 5 | 1 | 2 | 7 | 3 | 51 |  |  |
| `F` | 322622 |  | 3 |  |  |  |  | 27 | 1 |  | 5 | 4 |  | 39 | 2 | 8 | 7 |  |
| `G` | 14746 |  | 7 |  |  |  |  | 18 |  |  | 6 |  |  | 36 | 2 | 13 | 13 |  |
| `H` | 5073 |  | 2 |  | 98 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 8424 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 37035 |  | 2 |  |  | 8 |  | 2 | 89 |  |  |  |  |  |  |  |  |  |
| `Q` | 12436 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 49710 |  | 21 |  | 5 |  |  |  |  |  | 6 | 5 | 15 | 15 | 26 | 7 |  |  |
| `S` | 319 |  | 5 | 42 | 5 |  |  |  |  |  | 6 | 4 | 8 | 10 | 19 |  |  |  |
| `T` | 9750 |  | 2 | 98 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `W` | 59 |  | 24 |  |  |  |  |  |  |  | 2 |  |  |  |  |  | 75 |  |
| `X` | 1824 |  | 3 |  |  |  |  |  | 67 |  | 1 | 1 | 2 | 13 |  | 11 |  |  |
| `h` | 2574 |  | 1 |  |  |  |  | 8 |  |  |  |  |  | 23 | 11 | 10 | 45 |  |
| `k` | 4728 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 67 |  | 25 |  | 1 |  |  | 6 |  |  | 15 | 7 | 7 | 1 | 10 |  | 25 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 42606 | `-` 100, `?` 0, `B` 0, `F` 0 |
| fight | 31484 | `F` 35, `R` 33, `B` 13, `C` 11 |
| tribute | 16084 | `T` 60, `B` 20, `F` 17, `S` 1 |
| recall | 23183 | `K` 36, `H` 21, `k` 20, `R` 11 |
| hold+recall | 16262 | `Q` 76, `P` 18, `F` 5, `B` 1 |
| teleport | 144 | `F` 73, `B` 23, `P` 2, `C` 1 |
| camp | 102733 | `F` 84, `B` 13, `G` 3, `P` 1 |
| hold | 39251 | `P` 84, `F` 11, `X` 3, `B` 1 |
| spawn-heal | 16 | `H` 88, `F` 12 |
| bag->altar | 93057 | `B` 74, `F` 19, `R` 3, `C` 3 |
| bag->camp | 28626 | `F` 44, `B` 44, `R` 8, `C` 3 |
| bag-other | 19980 | `B` 38, `R` 37, `F` 12, `C` 12 |
| empty->camp | 143729 | `F` 88, `R` 5, `G` 4, `C` 2 |
| empty->spawn | 21642 | `R` 59, `F` 32, `C` 5, `G` 1 |
| empty-other | 38687 | `F` 70, `C` 12, `R` 8, `G` 5 |
| idle-off | 31223 | `F` 67, `B` 21, `G` 6, `h` 4 |
| idle-spawn | 2957 | `F` 93, `B` 6, `-` 1, `H` 0 |

## 2. Earnings (per game per side unless noted)

| metric | W | L |
|---|---|---|
| gems captured | 1018 | 652 |
| gems tributed | 1020 | 459 |
| gems taken by kills | 134 | 78.7 |
| gems lost at death to champions | 78.7 | 134 |
| gems lost at death to camps | 1.7 | 2.2 |
| gold earned (lifetime) | 6080 | 4108 |
| r1-300 gems captured | 234 | 184 |
| r1-300 gems tributed | 144 | 109 |
| r1-300 gems lost at death | 4.3 | 6.2 |
| gems captured per camp-hit round | 1.3 | 0.9 |
| gems captured per hold round | 3.4 | 2.5 |
| gems captured per (camp+hold) round | 0.9 | 0.7 |
| gems tributed per 100 alive rounds | 22.8 | 10.8 |
| mean bag carried per alive round | 30.0 | 23.8 |
| % alive rounds carrying 30+ | 19.7 | 17.9 |
| tributes per 1000 alive rounds | 6.4 | 4.2 |
| mean bag at tribute | 35.4 | 26.1 |
| walk steps per tributed gem | 3.0 | 6.5 |
| bag-walk rounds per tributed gem | 1.0 | 2.2 |
| real recalls per game (completed) | 53.9 (44.7) | 51.3 (41.0) |
| tribute cancels per game (cause) | death 0.04, lock 0.39, manual 0.41, stun 0.87 | death 0.03, lock 0.24, manual 0.16, stun 0.33 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | W | 106 | 227 | 422 | 263 |
| gems captured | L | 85.1 | 168 | 266 | 133 |
| gems tributed | W | 55.9 | 165 | 450 | 349 |
| gems tributed | L | 39.0 | 116 | 197 | 106 |
| alive champion-rounds | W | 696 | 1139 | 1530 | 1107 |
| alive champion-rounds | L | 683 | 1104 | 1427 | 1015 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `R` | `F` | `B` | `S` | `G` | `C` | `E` |
|---|---|---|---|---|---|---|---|---|
| W | 21.3/g, 91.7% done, 27.3% bag, 26.2 from spawn | 16.1/g, 84.3% done, 32.3% bag, 28.5 from spawn | 9.9/g, 64.9% done, 23.8% bag, 25.3 from spawn | 3.6/g, 82.1% done, 100.0% bag, 31.8 from spawn | 1.3/g, 92.2% done, 3.3% bag, 26.9 from spawn | 1.1/g, 64.5% done, 21.1% bag, 29.1 from spawn | 0.6/g, 56.4% done, 61.5% bag, 42.7 from spawn | - |
| L | 18.8/g, 93.3% done, 30.7% bag, 24.3 from spawn | 18.1/g, 77.0% done, 35.4% bag, 26.7 from spawn | 9.3/g, 57.5% done, 16.9% bag, 27.1 from spawn | 3.5/g, 82.4% done, 100.0% bag, 32.2 from spawn | 0.8/g, 100.0% done, 1.9% bag, 33.6 from spawn | 0.6/g, 73.8% done, 28.6% bag, 23.9 from spawn | 0.3/g, 60.0% done, 70.0% bag, 39.5 from spawn | 0.0/g, 100.0% done, 100.0% bag, 58.0 from spawn |

Bag size at tribute (% of tributes): W: 0-19 44.2, 20-39 30.2, 40-59 14.0, 60-79 5.2, 80-99 2.4, 100+ 4.1; L: 0-19 53.2, 20-39 25.1, 40-59 14.2, 60-79 5.0, 80-99 1.0, 100+ 1.5

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 3+ | 23 | 76.3 | 86.8 | 0.35 | 26.7 | 87.0 | 8.7 | 4.3 | 1.4 | 6.1 | 0.22 | 39.1 |
| Golem | 1 | 14 | 14.4 | 105 | 0.29 | 21.2 | 92.9 | 7.1 | 0.0 | 1.1 | 6.3 | 0.07 | 50.0 |
| Golem | 2 | 18 | 28.4 | 70.5 | 0.51 | 26.9 | 100 | 0.0 | 0.0 | 1.2 | 5.2 | 0.00 | 16.7 |
| Golem | 3+ | 43 | 44.9 | 69.6 | 0.78 | 39.4 | 95.3 | 4.7 | 0.0 | 1.3 | 6.5 | 0.33 | 30.2 |
| Elk | 1 | 427 | 14.7 | 30.9 | 0.49 | 22.7 | 95.8 | 2.8 | 1.4 | 1.0 | 6.9 | 0.10 | 11.9 |
| Elk | 2 | 595 | 24.3 | 43.8 | 0.74 | 31.2 | 98.5 | 1.0 | 0.5 | 1.0 | 6.7 | 0.04 | 11.4 |
| Elk | 3+ | 564 | 36.2 | 43.3 | 0.87 | 36.4 | 98.0 | 1.6 | 0.4 | 1.1 | 6.2 | 0.05 | 12.9 |
| Wolf | 1 | 1061 | 13.9 | 22.0 | 0.91 | 14.9 | 96.6 | 2.9 | 0.5 | 1.0 | 7.3 | 0.08 | 8.5 |
| Wolf | 2 | 723 | 19.7 | 31.9 | 1.36 | 22.3 | 96.8 | 2.6 | 0.6 | 1.0 | 7.0 | 0.12 | 5.9 |
| Wolf | 3+ | 347 | 29.7 | 34.8 | 1.83 | 29.2 | 96.8 | 2.0 | 1.2 | 1.1 | 6.9 | 0.07 | 8.9 |
| GemCl | 1 | 1610 | 2.7 | 3.6 | 0.20 | 0.0 | 92.9 | 5.1 | 2.0 | 1.0 | 11.0 | 0.11 | 4.6 |
| GemCl | 2 | 206 | 4.8 | 12.9 | 0.19 | 0.0 | 97.1 | 1.5 | 1.5 | 1.0 | 8.4 | 0.13 | 6.8 |
| GemCl | 3+ | 33 | 12.9 | 9.8 | 0.15 | 0.0 | 90.9 | 6.1 | 3.0 | 1.2 | 29.5 | 0.58 | 33.3 |
| GoldCl | 1 | 1652 | 3.3 | 6.5 | 3.97 | 0.0 | 95.8 | 2.4 | 1.8 | 1.0 | 9.5 | 0.07 | 5.2 |
| GoldCl | 2 | 297 | 3.9 | 14.1 | 23.37 | 0.0 | 97.0 | 2.0 | 1.0 | 1.0 | 7.8 | 0.10 | 7.4 |
| GoldCl | 3+ | 21 | 6.5 | 38.6 | nan | nan | 90.5 | 9.5 | 0.0 | 1.1 | 32.1 | 0.81 | 9.5 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| W | 59.9 | 62.2 | 0.69 | 19.8 | 97.0 | 2.0 | 2.00 | 1.0 | 8.5 | 0.09 | 0.01 | 0.004 |
| L | 49.2 | 62.6 | 0.85 | 22.1 | 94.4 | 4.1 | 1.20 | 1.0 | 8.6 | 0.09 | 0.01 | 0.004 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| W | 12.77 | 8.90 | 0.49 | 0.10 | 8.90 | 11.50 | 1.63 | 1.99 | 0.07 | 0.14 | 3.26 | 1.39 | 2.07 | 1.56 | 0.20 | 0.04 | 2.96 | 1.91 |
| L | 11.46 | 8.06 | 0.27 | 0.04 | 7.59 | 10.97 | 1.24 | 1.21 | 0.03 | 0.01 | 1.56 | 1.33 | 1.27 | 0.94 | 0.01 | 0.01 | 2.16 | 1.04 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| W | own | 61.2 | 9.0 | 2.6 | 2.0 | 25.2 |
| W | mid | 67.7 | 8.6 | 5.4 | 1.3 | 17.0 |
| W | enemy | 65.2 | 7.9 | 2.5 | 1.8 | 22.5 |
| L | own | 65.2 | 7.9 | 2.5 | 1.8 | 22.5 |
| L | mid | 67.7 | 8.6 | 5.4 | 1.3 | 17.0 |
| L | enemy | 61.2 | 9.0 | 2.6 | 2.0 | 25.2 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| W | own | 67.7 | 8.5 | 3.5 | 2.0 | 18.4 |
| W | mid | 77.7 | 7.0 | 2.1 | 1.3 | 11.9 |
| W | enemy | 69.4 | 8.0 | 1.4 | 2.0 | 19.3 |
| L | own | 69.4 | 8.0 | 1.4 | 2.0 | 19.3 |
| L | mid | 77.7 | 7.0 | 2.1 | 1.3 | 11.9 |
| L | enemy | 67.7 | 8.5 | 3.5 | 2.0 | 18.4 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| W | Wolf | 61.5 | 8.8 | 1.5 | 72.7 | 7.3 | 1.7 | 63.0 | 8.7 | 1.7 |
| L | Wolf | 63.0 | 8.7 | 1.7 | 72.7 | 7.3 | 1.7 | 61.5 | 8.8 | 1.5 |
| W | Elk | 51.3 | 12.2 | 1.3 | 47.4 | 17.2 | 1.7 | 51.4 | 12.4 | 1.6 |
| L | Elk | 51.4 | 12.4 | 1.6 | 47.4 | 17.2 | 1.7 | 51.3 | 12.2 | 1.3 |
| W | Golem | 67.6 | 10.1 | 0.6 | 88.0 | 3.3 | 0.2 | 65.4 | 9.4 | 1.0 |
| L | Golem | 65.4 | 9.4 | 1.0 | 88.0 | 3.3 | 0.2 | 67.6 | 10.1 | 0.6 |
| W | Monolith | 86.1 | 5.2 | 0.3 | 87.5 | 4.0 | 0.2 | 90.4 | 3.9 | 0.1 |
| L | Monolith | 90.4 | 3.9 | 0.1 | 87.5 | 4.0 | 0.2 | 86.1 | 5.2 | 0.3 |
| W | GemCl | 42.6 | 2.4 | 7.8 | 43.0 | 3.7 | 21.0 | 44.5 | 2.4 | 7.6 |
| L | GemCl | 44.5 | 2.4 | 7.6 | 43.0 | 3.7 | 21.0 | 42.6 | 2.4 | 7.8 |
| W | GoldCl | 56.1 | 2.2 | 8.3 | 63.8 | 1.6 | 8.2 | 57.6 | 2.5 | 5.5 |
| L | GoldCl | 57.6 | 2.5 | 5.5 | 63.8 | 1.6 | 8.2 | 56.1 | 2.2 | 8.3 |

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| W | 42.6 (599) | 8.4 (265) | 9.2 (154) | 14.4/2.3/2.1 |
| L | 37.4 (473) | 5.2 (104) | 5.1 (76) | 13.5/1.3/1.5 |

## 5. Deaths

| metric | W | L |
|---|---|---|
| deaths/game (to champions + camps) | 2.7 + 0.26 | 6.6 + 0.41 |
| median first-death round (none = length+1) | 370 | 298 |
| % of games this side died first | 38.6 | 57.1 |
| % alone (no ally within 8) | 32.7 | 28.7 |
| % ally within 4 | 34.1 | 42.5 |
| % 2+ enemies within 8 | 65.9 | 69.4 |
| % on own ground | 55.1 | 60.7 |
| % on mid ground | 25.9 | 20.4 |
| % on enemy ground | 19.0 | 18.8 |
| % walking toward spawn (last 4 rounds) | 38.5 | 34.2 |
| % branch R in last 4 rounds | 88.8 | 81.8 |
| % carrying 30+ gems | 14.6 | 12.8 |
| mean enemies within 8 | 2.1 | 2.2 |
| mean gems carried at death | 26.3 | 19.1 |
| r1-300 deaths/game | 0.61 | 1.06 |

Branch at death (last D line): W: `R` 78.0%, `F` 7.8%, `E` 5.9%, `K` 4.9%, `T` 1.5%, `B` 1.0%; L: `R` 74.9%, `E` 13.4%, `F` 6.7%, `K` 1.6%, `B` 1.6%, `P` 0.6%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| W | 0 | 0.4 | 3.9 | 3.3 | 2.0 |
| W | 1 | 1.0 | 2.7 | 3.1 | 3.0 |
| W | 2 | 0.0 | 1.3 | 2.4 | 2.7 |
| W | 3+ | 0.1 | 0.6 | 0.3 | 2.4 |
| L | 0 | 0.9 | 7.1 | 6.1 | 6.1 |
| L | 1 | 0.7 | 7.3 | 8.4 | 7.6 |
| L | 2 | 0.3 | 3.7 | 5.0 | 7.1 |
| L | 3+ | 0.0 | 1.6 | 2.1 | 6.4 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| W | 6.6 | 0.91 | 40.3 | 51.5 | 14.5 | 5.6 | 56.7 |
| L | 2.7 | 0.53 | 40.3 | 48.5 | 5.6 | 14.5 | -56.7 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| W | 25.57 / +0.04 | 3.66 / +0.02 | 0.64 / +0.02 | 2.89 / +0.26 | 2.97 / +0.15 | 1.41 / +0.21 | 0.46 / +0.53 | 1.01 / +0.30 | 1.69 / +0.46 |
| L | 25.57 / -0.04 | 2.89 / -0.26 | 0.46 / -0.53 | 3.66 / -0.02 | 2.97 / -0.15 | 1.01 / -0.30 | 0.64 / -0.02 | 1.41 / -0.21 | 1.69 / -0.46 |
| pooled | 25.57 / +0.00 | 3.27 / -0.10 | 0.55 / -0.21 | 3.27 / +0.10 | 2.97 / +0.00 | 1.21 / +0.00 | 0.55 / +0.21 | 1.21 / +0.00 | 1.69 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| W | 0.66 / +0.11 / 17.4 | 2.60 / +0.09 / 12.6 | 9.74 / +0.10 / 14.5 | 15.96 / +0.09 / 13.9 | 8.30 / +0.09 / 13.9 | 2.57 / +0.16 / 20.0 | 0.47 / +0.27 / 24.2 |
| L | 0.47 / -0.27 / 6.1 | 2.57 / -0.16 / 5.0 | 8.30 / -0.09 / 6.0 | 15.96 / -0.09 / 5.1 | 9.74 / -0.10 / 5.4 | 2.60 / -0.09 / 7.1 | 0.66 / -0.11 / 13.0 |
| pooled | 0.56 / -0.05 / 12.7 | 2.59 / -0.03 / 8.8 | 9.02 / +0.01 / 10.6 | 15.96 / +0.00 / 9.5 | 9.02 / -0.01 / 9.3 | 2.59 / +0.03 / 13.5 | 0.56 / +0.05 / 17.7 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 70 | 11 | 50.8 | 39.5 (n=43) | 78.6 (n=14) | 100.0 (n=2) |
| tributed r400 | 70 | 7 | 69.8 | 60.0 (n=30) | 68.2 (n=22) | 100.0 (n=11) |
| tributed r600 | 61 | 4 | 75.4 | 47.1 (n=17) | 84.2 (n=19) | 90.5 (n=21) |
| tributed+carried r200 | 70 | 7 | 71.4 | 64.3 (n=42) | 83.3 (n=18) | 100.0 (n=3) |
| tributed+carried r400 | 70 | 3 | 73.1 | 60.0 (n=25) | 70.4 (n=27) | 100.0 (n=15) |
| tributed+carried r600 | 61 | 2 | 79.7 | 53.3 (n=15) | 73.3 (n=15) | 96.6 (n=29) |

| predictor | win % |
|---|---|
| team that did not die first wins | 59.7 (n=67) |
| more kills wins | 87.5 (n=64) |
| more r1-300 kills wins | 62.5 (n=40) |
| more gems captured wins | 87.1 (n=70) |
| more r1-300 gems captured wins | 66.2 (n=68) |
| fewer gems lost at death wins | 71.9 (n=57) |
| more mid-group captures wins | 93.1 (n=29) |

Game length: median 945, quartiles 703-1205, min 441, max 2000; 4.3% reach round 2000; 95.7% end on 1000 gems.

## Examples

**bagdeath** (47 in all, largest first):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/127-02treasure-box-12.repl26a` (cc4217505b90a637) r1171 team B (W): Prism died with 1384 gems (champ, allies<=8 2, enemies<=8 2, branch T)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/091-01shortcut-12.repl26a` (b714855345688d11) r1223 team A (L): Prism died with 820 gems (champ, allies<=8 1, enemies<=8 1, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r606 team A (L): Vendetta died with 596 gems (champ, allies<=8 1, enemies<=8 5, branch E)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1283 team B (L): Marcella died with 581 gems (champ, allies<=8 0, enemies<=8 1, branch C)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/127-02treasure-box-12.repl26a` (cc4217505b90a637) r1000 team A (L): Prism died with 511 gems (champ, allies<=8 2, enemies<=8 2, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1335 team A (W): Marcella died with 476 gems (champ, allies<=8 0, enemies<=8 1, branch R)

**stolen** (224 in all, largest first):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r481 team B (W): Monolith (400 gems, mid) cleared r459 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/069-00vault-12.repl26a` (fcc8e1c0dd6d4d9e) r440 team B (L): GemCl (343 gems, enemy) cleared r31 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/009-00contest-12.repl26a` (3674b10bf9072918) r1085 team A (W): Monolith (200 gems, own) cleared r1079 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/067-00the-line-12.repl26a` (7a1fd1c74e67afe3) r163 team A (L): GemCl (161 gems, own) cleared r156 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/067-00the-line-12.repl26a` (7a1fd1c74e67afe3) r1126 team A (L): Wolf (161 gems, own) cleared r1100 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/063-00stampede-12.repl26a` (a24747cafef96c1b) r1360 team B (L): Elk (160 gems, mid) cleared r1355 stolen

**idle-off30** (67 in all, largest first):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1336 team A (W): Heart of Ruin#2 idle off spawn 665 rounds at (11, 30) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1341 team B (L): Heart of Ruin#5 idle off spawn 660 rounds at (36, 11) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1361 team B (L): Marcella#4 idle off spawn 640 rounds at (38, 10) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1415 team A (W): Marcella#1 idle off spawn 586 rounds at (6, 34) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r879 team B (L): Heart of Ruin#5 idle off spawn 404 rounds at (36, 13) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r880 team B (L): Prism#3 idle off spawn 393 rounds at (35, 24) branch F

