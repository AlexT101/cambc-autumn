import pickle, collections, glob, zipfile, re
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits2.pkl', 'rb'))
sw = collections.defaultdict(dict)
for z in glob.glob('/tmp/claude-1000/m4-diag/run2/*/*.repl26a'):
    name = z.split('/')[-2]
    if name == '00interlock': name = 'interlock'
    out = zipfile.ZipFile(z).read('team-a.stdout').decode('latin1')
    for m in re.finditer(r'SWITCH (\d+) (\d+) (.*)', out):
        sw[name][(int(m.group(1)), int(m.group(2)))] = dict(re.findall(r'(\w+)=(\S+)', m.group(3)))
cnt = collections.Counter(); ex = []
for v in allv:
    if v['cleared'] or 'choice' not in v: continue
    k = v['choice'][1][1]; key = k['br'] + '/' + k['rsn']
    for r in range(v['r0'], v['r1'] + 2):
        s = sw[v['game']].get((r, v['c']))
        if s and s['from'] == 'g%d' % v['G']:
            cnt[(key, s['prev_rsn'], s['br'], s['to_rsn'])] += 1
            if key == 'best/a': ex.append((v['game'], r, v['name'], s))
            break
for k_, n in cnt.most_common(25): print(n, k_)
for e in ex[:8]: print(e[0], e[1], e[2], {k: e[3][k] for k in ('from','prev_rsn','prev_alone','spare','hp','line','to','br','to_rsn')})
