import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    team={c['id']:c['team'] for c in meta['champions']}
    names=[t['name'] for t in meta['teams']]
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k']=='death' and not e.get('linked'):
            return (e['r'], team[e['v']], meta['result']['winner'], 'camp' in e, names)
    return (None,None,meta['result']['winner'],None,names)
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    rs=sorted(r for r,*_ in res if r)
    print(len(res),'games; first death round quantiles', [rs[int(q*len(rs))] for q in (0.1,0.25,0.5,0.75,0.9)], 'none', sum(1 for r,*_ in res if not r))
    for lo,hi in ((0,100),(100,200),(200,400),(400,2001)):
        sel=[x for x in res if x[0] and lo<=x[0]<hi]
        if sel: print(lo,hi,len(sel),'victim team loses %.2f'%(sum(1 for r,v,w,c,n in sel if v!=w)/len(sel)))
    if len(sys.argv)>2:
        bot=sys.argv[2]
        sel=[x for x in res if x[0]]
        print('first victim is',bot, sum(1 for r,v,w,c,n in sel if n[v]==bot)/len(sel))
