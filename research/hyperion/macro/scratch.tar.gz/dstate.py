"""Per-death state of champions killed by enemy champions: features at the first enemy hit of the fatal chain."""
import sys, re, zipfile, pickle, os
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0, '/home/ubuntu/cambc-autumn/tools/replay')
from analysis.data import resolve, load_index, chebyshev, ROOT, load_map
from narrative.mapinfo import MapInfo
from narrative.game import View

GAP = 5  # rounds between enemy hits on the victim that still chain into one engagement
D_RE = re.compile(rb'^[\s\0]*D (\d+) (\d+) (\S) (-?\d+) (-?\d+)\s*$', re.M)
INF = 1 << 30
_maps = {}


def mapinfo(h):
    if h not in _maps:
        raw = load_map(h).raw
        for grp in raw['groups']:
            grp.setdefault('mirror', grp['id'])
        _maps[h] = MapInfo(raw)
    return _maps[h]


def trace(source):
    out = {}
    with zipfile.ZipFile(ROOT / source) as z:
        for fn in ('team-a.stdout', 'team-b.stdout'):
            for m in D_RE.finditer(z.read(fn)):
                out[(int(m.group(2)), int(m.group(1)))] = m.group(3).decode()
    return out


def work(task):
    d, source, batch = task
    from analysis.data import Game
    g0 = Game(d)
    M = mapinfo(g0.meta['map']['hash'])
    v = View(d, M)
    g = v.g
    br = trace(source)
    team = v.team
    W = g.winner
    # enemy hits incl. stun-only
    hits = defaultdict(list)  # victim -> [(s, r, attacker, amt)]
    for s, r, a, x, amt, *_ in g.champ_damage:
        hits[x].append((s, r, a, amt))
    for e in g.events:
        if e['k'] in ('attack', 'cast') and e.get('stun'):
            hit = {x for x, _ in e.get('dmg', [])}
            for x in e['stun']:
                if x in team and team[x] != team[e['a']] and x not in hit:
                    hits[x].append((e['s'], e['r'], e['a'], 0.0))
    for x in hits:
        hits[x].sort()
    campd = defaultdict(list)  # victim -> [(s, r, amt)]
    for s, r, x, amt in g.camp_damage:
        campd[x].append((s, r, amt))
    champd_in = defaultdict(list)
    for s, r, a, x, amt, *_ in g.champ_damage:
        champd_in[x].append((s, r, amt))
    camphit = defaultdict(set)  # champ -> rounds it hit a camp
    moved = defaultdict(set)
    ev_by = defaultdict(list)
    for e in g.events:
        a = e.get('a')
        if e['k'] in ('attack', 'cast') and (e.get('camp') is not None or e.get('cdmg')):
            camphit[a].add(e['r'])
        if e['k'] == 'move' or (e['k'] == 'cast' and e.get('moved')):
            moved[a].add(e['r'])
        if e['k'] in ('recall_start', 'recall_end', 'recall_cancel', 'tribute_start', 'tribute_end', 'tribute_cancel',
                      'teleport_start'):
            ev_by[a].append(e)
    cap_tiles = {}
    for grp in M.raw['groups']:
        for t in grp['tiles']:
            cap_tiles[tuple(t)] = grp['id']

    def branch_at(c, r, s):
        if v.turn_step(c, r) < s and (c, r) in br:
            return br[(c, r)]
        return br.get((c, r - 1), '-')

    out = []
    for e in g.deaths:
        if e.get('linked') is not None:
            continue
        c, rD, sD = e['v'], e['r'], e['s']
        if 'camp' in e or e.get('by') not in team or team[e['by']] == team[c]:
            continue
        t = team[c]
        hs = [h for h in hits[c] if h[0] <= sD]
        if not hs:
            continue
        # walk the chain back from the death
        i = len(hs) - 1
        while i > 0 and hs[i][1] - hs[i - 1][1] <= GAP:
            i -= 1
        s1, r1, a1, amt1 = hs[i]
        chain = hs[i:]
        # hp before the first hit
        i_prev = r1 - 2  # rounds index: end of round r1-1
        col = v.col[c]
        hp0 = col['hp'][i_prev] if i_prev >= 0 else col['maxHp'][0]
        mx = col['maxHp'][max(i_prev, 0)]
        lost = sum(a for s, r, a in campd[c] if r == r1 and s < s1) + sum(a for s, r, a in champd_in[c] if r == r1 and s < s1)
        hp = max(0.0, hp0 - lost)
        hpf = hp / mx if mx else 0
        cd30 = sum(a for s, r, a in campd[c] if r1 - 30 <= r and s < s1)
        chd30 = sum(a for s, r, a in champd_in[c] if r1 - 30 <= r and s < s1)
        # hp 30 rounds before (to see if the drop is from camps)
        hp30 = col['hp'][max(0, r1 - 32)] / col['maxHp'][max(0, r1 - 32)]
        clearing = bool(camphit[c] & {r1, r1 - 1}) or any(r1 - 1 <= r <= r1 and s < s1 for s, r, a in campd[c])
        p = v.pos_at(c, r1, s1)
        half = M.half_of(p) if p else -1
        ground = 'mid' if half == -1 else 'own' if half == t else 'enemy'
        dsp = M.dspawn[t].get(p, INF) if p else INF
        bch = branch_at(c, r1, s1)
        sees = v.sees_before(c, r1, s1)
        # who is near
        near = {0: [], 1: []}
        near12 = []
        allies = []
        for x in v.ids:
            q = v.pos_at(x, r1, s1)
            if q is None or p is None:
                continue
            dd = chebyshev(p, q)
            if dd <= 8:
                near[team[x]].append(x)
            if team[x] == t and x != c and dd <= 12:
                act = 'camp' if camphit[x] & {r1, r1 - 1} else ('hold' if cap_tiles.get(q) is not None and q not in M.spawn_set[t]
                                                               and r1 not in moved[x] else 'walk' if (r1 in moved[x] or r1 - 1 in moved[x]) else 'idle')
                allies.append((x, dd, act, branch_at(x, r1, s1)))
        ally8 = sum(1 for a in allies if a[1] <= 8)
        ally12 = len(allies)
        nk, nv = len(near[1 - t]), len(near[t])
        # recalls between the first hit and death
        rec_active = col['chan'][i_prev] == 1 if i_prev >= 0 else False
        rstart = [x for x in ev_by[c] if x['k'] == 'recall_start' and s1 <= x['s'] <= sD]
        rcancel = [x for x in ev_by[c] if x['k'] == 'recall_cancel' and s1 - 1 <= x['s'] <= sD]
        rcancel_dmg = [x for x in rcancel if x.get('cause') == 'damage']
        # branch history
        hist = ''.join(br.get((c, rr), '.') for rr in range(r1 - 10, rD + 1))
        trib = col['chan'][i_prev] == 2 if i_prev >= 0 else False
        pre5 = ''.join(br.get((c, rr), '.') for rr in range(r1 - 5, r1))
        own_r1 = br.get((c, r1)) if v.turn_step(c, r1) < s1 else None
        after = br.get((c, r1)) if v.turn_step(c, r1) > s1 else br.get((c, r1 + 1), '.')
        win = ''.join(br.get((c, rr), '.') for rr in range(r1, rD + 1))
        seen5 = g.seen_recently(c, r1 - 1, 5) if r1 > 1 else False
        sawatk = any(a1 in (col['sees'][j] or []) for j in range(max(0, r1 - 6), r1 - 1))
        kept_at_hit = br.get((c, r1 - 1)) == 'K' or own_r1 == 'K'
        hp_min30 = min(col['hp'][j] / col['maxHp'][j] for j in range(max(0, r1 - 32), max(1, r1 - 1)))
        ally_hit = sum(1 for x in v.ids if team[x] == t and x != c and any(h[1] >= r1 - 1 and h[1] <= r1 for h in hits[x]))
        out.append(dict(dir=d, batch=batch, map=g.map_name, src=source, r1=r1, rD=rD, c=c, type=g.name_of[c], team=t,
                        won=(t == W), hpf=hpf, hp30=hp30, cd30=cd30, cd30f=cd30 / mx, chd30=chd30, chd30f=chd30 / mx,
                        clearing=clearing, ground=ground, dsp=dsp, branch=bch, blind=a1 not in sees, sees=len(sees),
                        nk=nk, nv=nv, ally8=ally8, ally12=ally12, allies=allies, dur=rD - r1, nhits=len(chain),
                        attackers=len({h[2] for h in chain}), rec_active=rec_active, rstart=len(rstart),
                        rcancel=len(rcancel), rcancel_dmg=len(rcancel_dmg), hist=hist, gems=e.get('gems', 0), trib=trib,
                        pre5=pre5, after=after, win=win, seen5=seen5, sawatk=sawatk, kept_at_hit=kept_at_hit, hp_min30=hp_min30, ally_hit=ally_hit, kwin=('K' in win), moved=(r1 in moved[c] or r1 - 1 in moved[c]), N=v.N, ncamp_death=0))
    ndeaths = {tt: sum(1 for e in g.deaths if e.get('linked') is None and team[e['v']] == tt) for tt in (0, 1)}
    ncamp = {tt: sum(1 for e in g.deaths if e.get('linked') is None and team[e['v']] == tt and 'camp' in e) for tt in (0, 1)}
    return d, batch, W, v.N, out, ndeaths, ncamp


def main():
    idx = load_index()
    tasks = []
    for b in ('ladder', 'gen', 'fresh-gen-s1'):
        src = f'replays/batch-20261030-094349-ab-m3-mirror-{b}'
        dirs = resolve([src], idx)
        rows = {r['dir']: r['source'] for r in idx if r['source'].startswith(src + '/')}
        for d in dirs:
            tasks.append((d, rows[d], b))
    res = []
    with ProcessPoolExecutor(int(sys.argv[1]) if len(sys.argv) > 1 else 12) as ex:
        for x in ex.map(work, tasks, chunksize=4):
            res.append(x)
    pickle.dump(res, open('/tmp/claude-1000/-home-ubuntu-cambc-autumn/5b6fdea5-8c0c-400c-94d5-cb7146b58518/scratchpad/dstate.pkl', 'wb'))
    print(len(res), sum(len(x[4]) for x in res))


if __name__ == '__main__':
    main()
