import json,glob,collections,sys
A=collections.defaultdict(lambda: collections.Counter())
n=0
role=sys.argv[2] if len(sys.argv)>2 else 'ref'
for f in glob.glob(f'replays/solo/{sys.argv[1]}/analysis/*/meta.json'):
    m=json.load(open(f))
    if f'-{role}/' not in m['source']: continue
    n+=1
    us=[i for i,t in enumerate(m['teams']) if t['name']!='idle'][0]
    for c in m['champions']:
        if c['team']!=us: continue
        s=c['stats']; k=c['name']
        A[k]['n']+=1; A[k]['gems']+=s['collectedGems']; A[k]['dmg']+=s['monsterDamageDone']; A[k]['taken']+=s['monsterDamageTaken']; A[k]['gold']+=s['earnedGold']; A[k]['deaths']+=c['deaths']; A[k]['rounds']+=m.get('rounds',0) or 0
print(n,'games')
for k,v in sorted(A.items(), key=lambda kv:-kv[1]['n']):
    N=v['n']; print(f"{k:15s} n={N:4d} gems={v['gems']/N:6.0f} dmg={v['dmg']/N:7.0f} taken={v['taken']/N:6.0f} gold={v['gold']/N:6.0f} deaths={v['deaths']/N:.2f}")
