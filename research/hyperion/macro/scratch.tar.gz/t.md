Champion strength b_c by pick count (win points, x25 logit, on the average map):
  ryth            3:  -3.8  4:  -2.1  5:  -4.0
  vesper_vale     3:   3.0  4:  -3.0  5:   0.2
  vendetta        3:   7.3  4:   6.0  5:   3.2
  cassi_and_issac 3:   5.3  4:   4.3  5:   8.6
  stellar         3: -15.4  4:  -8.1  5:  -8.4
  prism           3:  13.5  4:  10.5  5:  -0.5
  marcella        3:  10.8  4:   7.8  5:   6.1
  willow          3: -15.5  4:  -7.1  5:   1.3
  ren             3:  -5.4  4:  -3.9  5:  -5.0
  varg            3:  -0.7  4:  -6.3  5:  -4.2
  tavi            3:  -4.0  4:  -2.6  5:  -5.7
  heart_of_ruin   3:   4.9  4:   4.5  5:   8.2

Best arms against the model's choice on the average map (win points); a negative best means the model's choice
wins. maps: the share of pool maps where some arm beats it (100% or 0% without map terms). boot: how often
bootstrap refits agree on the best arm, and the 10th percentile of its gain.

3 picks. Model choice term MD by ordinal k0 0.153, k1 0.062, k2 0.048, k3 0.010
  ryth           k0  monster-health -0.7, jungle-health -1.1, monster-strength -1.3, prospector-health -1.5  | worst capture-focus -5.9 | maps 0% boot 50% p10 -2.1
  ryth           k1  jungle-health 1.4, jungle-strength 1.0, hunter-health 0.4, skirmish-health 0.3  | worst power-focus -2.9 | maps 100% boot 75% p10 -0.5
  ryth           k2  collectors-health 1.6, home-health 1.6, collectors-strength 0.8, home-strength 0.8  | worst durability-focus -3.3 | maps 100% boot 25% p10 -1.6
  ryth           k3+ jungle-health 2.4, skirmish-health 2.4, collectors-health 2.2, prospector-health 1.6  | worst power-strength -1.1 | maps 100% boot 50% p10 1.6
  vesper_vale    k0  monster-strength -0.1, monster-health -1.4, jungle-strength -1.8, prospector-strength -1.8  | worst power-focus -9.5 | maps 0% boot 100% p10 -0.6
  vesper_vale    k1  monster-strength 1.1, jungle-strength 1.0, prospector-strength 0.3, skirmish-strength 0.0  | worst power-focus -7.5 | maps 100% boot 25% p10 -0.1
  vesper_vale    k2  monster-strength 0.9, tribute-strength 0.5, home-strength 0.0, capture-strength -0.0  | worst durability-focus -8.2 | maps 100% boot 50% p10 -0.4
  vesper_vale    k3+ skirmish-strength 1.4, jungle-strength 1.3, prospector-strength 0.9, monster-strength 0.7  | worst hunter-focus -5.6 | maps 100% boot 50% p10 0.7
  vendetta       k0  monster-strength 0.1, monster-health 0.1, prospector-strength -1.8, prospector-health -1.9  | worst skirmish-focus -7.9 | maps 100% boot 75% p10 -1.5
  vendetta       k1  monster-strength 1.3, monster-health 0.9, jungle-strength 0.4, prospector-strength 0.2  | worst home-focus -5.6 | maps 100% boot 25% p10 -0.3
  vendetta       k2  monster-health 1.3, monster-strength 1.2, collectors-health 0.7, collectors-strength 0.6  | worst durability-focus -5.6 | maps 100% boot 25% p10 0.2
  vendetta       k3+ monster-health 1.3, collectors-health 1.3, prospector-health 1.3, jungle-health 1.0  | worst home-focus -3.6 | maps 100% boot 0% p10 0.5
  cassi          k0  monster-health -2.1, prospector-health -2.3, jungle-health -2.4, monster-strength -2.6  | worst home-focus -7.3 | maps 0% boot 25% p10 -6.2
  cassi          k1  jungle-health 0.1, jungle-strength -0.1, prospector-health -0.6, prospector-strength -0.7  | worst collectors-focus -5.3 | maps 100% boot 25% p10 -1.9
  cassi          k2  jungle-health -0.7, prospector-health -0.7, monster-health -0.9, tribute-health -1.1  | worst durability-focus -5.6 | maps 0% boot 0% p10 -2.7
  cassi          k3+ jungle-health 1.1, prospector-health 0.8, skirmish-health 0.7, jungle-focus 0.7  | worst hunter-strength -3.8 | maps 100% boot 50% p10 0.1
  issac          k0  monster-health -0.7, jungle-health -1.6, monster-focus -1.7, prospector-health -1.7  | worst durability-strength -5.9 | maps 0% boot 50% p10 -2.9
  issac          k1  tribute-health 1.2, skirmish-health 1.0, jungle-health 0.9, capture-health 0.8  | worst durability-strength -4.4 | maps 100% boot 0% p10 -0.4
  issac          k2  tribute-health 2.5, capture-health 2.0, tribute-focus 1.5, home-health 1.2  | worst durability-strength -5.9 | maps 100% boot 0% p10 0.1
  issac          k3+ skirmish-health 3.1, skirmish-focus 3.0, capture-health 2.3, capture-focus 2.2  | worst durability-strength -4.1 | maps 100% boot 50% p10 1.4
  prism          k0  monster-health -0.5, jungle-health -0.6, monster-strength -1.5, prospector-health -1.6  | worst treasure-focus -6.6 | maps 0% boot 50% p10 -3.1
  prism          k1  jungle-health 1.8, jungle-focus 1.1, jungle-strength 1.1, monster-health 0.3  | worst treasure-strength -4.3 | maps 100% boot 0% p10 -1.2
  prism          k2  home-health 1.4, jungle-health 1.1, monster-health 0.7, home-focus 0.3  | worst skirmish-strength -4.0 | maps 100% boot 25% p10 0.2
  prism          k3+ jungle-health 2.8, jungle-focus 2.5, prospector-health 1.6, jungle-strength 1.4  | worst power-strength -3.3 | maps 100% boot 25% p10 0.9
  marcella       k0  monster-strength -0.5, monster-health -0.7, monster-focus -0.9, prospector-strength -1.2  | worst hunter-focus -6.1 | maps 0% boot 75% p10 -2.5
  marcella       k1  jungle-strength 1.4, jungle-focus 1.2, skirmish-strength 1.2, skirmish-focus 1.0  | worst collectors-health -3.4 | maps 100% boot 25% p10 0.2
  marcella       k2  capture-strength 0.8, home-strength 0.7, capture-health 0.7, capture-focus 0.6  | worst hunter-focus -3.6 | maps 100% boot 25% p10 -1.3
  marcella       k3+ skirmish-focus 3.5, skirmish-health 2.7, jungle-focus 2.6, skirmish-strength 2.5  | worst hunter-strength -3.4 | maps 100% boot 75% p10 2.8
  willow         k0  prospector-focus -0.3, prospector-health -0.6, durability-focus -1.3, monster-focus -1.5  | worst skirmish-strength -6.2 | maps 0% boot 0% p10 -2.2
  willow         k1  prospector-focus 1.9, prospector-health 1.1, jungle-focus 1.1, hunter-focus 1.1  | worst collectors-strength -4.8 | maps 100% boot 25% p10 0.3
  willow         k2  home-focus 1.9, capture-focus 1.5, home-health 1.5, prospector-focus 1.4  | worst skirmish-strength -3.9 | maps 100% boot 0% p10 1.5
  willow         k3+ prospector-focus 3.8, skirmish-focus 3.0, capture-focus 2.7, treasure-focus 2.6  | worst monster-strength -3.1 | maps 100% boot 50% p10 3.7
  ren            k0  monster-health 2.2, prospector-health 1.3, monster-strength 0.7, prospector-strength -0.2  | worst treasure-focus -6.0 | maps 100% boot 50% p10 0.8
  ren            k1  monster-health 3.0, prospector-health 3.0, jungle-health 1.9, monster-strength 1.9  | worst treasure-focus -3.7 | maps 100% boot 25% p10 2.2
  ren            k2  monster-health 3.3, home-health 2.9, prospector-health 2.9, collectors-health 2.8  | worst durability-focus -4.1 | maps 100% boot 25% p10 2.1
  ren            k3+ prospector-health 4.4, monster-health 3.4, collectors-health 3.4, skirmish-health 3.4  | worst hunter-strength -1.6 | maps 100% boot 50% p10 4.4
  varg           k0  monster-health -1.4, durability-health -1.9, monster-strength -2.4, monster-focus -2.7  | worst skirmish-focus -6.7 | maps 0% boot 25% p10 -5.2
  varg           k1  monster-health -0.6, durability-health -0.8, hunter-health -0.8, jungle-health -1.0  | worst collectors-focus -5.2 | maps 0% boot 25% p10 -3.6
  varg           k2  home-health -0.2, monster-health -0.2, tribute-health -0.3, treasure-health -0.5  | worst skirmish-focus -4.2 | maps 0% boot 0% p10 -2.2
  varg           k3+ skirmish-health 0.4, durability-health 0.3, treasure-health 0.2, prospector-health 0.0  | worst power-strength -3.3 | maps 100% boot 0% p10 -1.6
  tavi           k0  monster-strength -2.0, monster-focus -2.1, monster-health -2.2, jungle-strength -2.2  | worst capture-health -6.4 | maps 0% boot 75% p10 -4.0
  tavi           k1  jungle-focus 0.6, jungle-strength 0.6, jungle-health 0.1, tribute-focus -0.7  | worst treasure-health -3.9 | maps 100% boot 25% p10 -0.6
  tavi           k2  tribute-focus 0.1, home-focus 0.1, tribute-strength 0.0, tribute-health -0.0  | worst durability-health -3.5 | maps 100% boot 25% p10 -2.2
  tavi           k3+ jungle-focus 2.0, skirmish-focus 1.5, jungle-health 1.1, jungle-strength 0.8  | worst capture-strength -2.4 | maps 100% boot 0% p10 -0.2
  heart_of_ruin  k0  monster-health -1.3, jungle-health -1.3, durability-health -1.4, monster-focus -1.7  | worst home-strength -6.1 | maps 0% boot 50% p10 -2.9
  heart_of_ruin  k1  jungle-focus 1.3, jungle-health 1.1, skirmish-focus 0.8, skirmish-health 0.7  | worst collectors-strength -4.5 | maps 100% boot 25% p10 0.6
  heart_of_ruin  k2  tribute-health 1.7, tribute-focus 1.4, capture-health 0.7, bruiser-health 0.5  | worst durability-strength -3.2 | maps 100% boot 75% p10 1.7
  heart_of_ruin  k3+ skirmish-focus 3.3, skirmish-health 2.7, jungle-focus 2.7, jungle-health 2.1  | worst home-strength -3.2 | maps 100% boot 50% p10 2.0

4 picks. Model choice term MD by ordinal k0 0.117, k1 0.059, k2 0.021, k3 0.033
  ryth           k0  monster-strength 1.3, monster-health 0.8, jungle-strength 0.4, durability-strength -0.1  | worst skirmish-focus -6.0 | maps 100% boot 25% p10 -0.9
  ryth           k1  jungle-health 2.7, collectors-health 1.6, treasure-health 1.4, jungle-strength 1.3  | worst home-focus -3.5 | maps 100% boot 75% p10 1.2
  ryth           k2  collectors-health 4.2, collectors-strength 3.7, tribute-health 3.1, tribute-strength 2.6  | worst skirmish-focus -4.3 | maps 100% boot 50% p10 -0.8
  ryth           k3+ home-health 1.9, home-strength 1.7, tribute-health 1.6, hunter-health 1.5  | worst skirmish-focus -2.8 | maps 100% boot 50% p10 0.7
  vesper_vale    k0  monster-strength 3.9, monster-health 2.0, jungle-strength 1.0, prospector-strength 0.6  | worst power-focus -9.1 | maps 100% boot 100% p10 2.2
  vesper_vale    k1  jungle-health 2.0, jungle-strength 2.0, monster-health 1.8, monster-strength 1.7  | worst power-focus -6.5 | maps 100% boot 50% p10 0.9
  vesper_vale    k2  monster-strength 4.0, tribute-strength 3.8, collectors-strength 3.2, monster-health 3.1  | worst skirmish-focus -5.1 | maps 100% boot 0% p10 1.6
  vesper_vale    k3+ monster-strength 2.7, tribute-strength 2.6, hunter-strength 1.9, jungle-strength 1.7  | worst power-focus -5.1 | maps 100% boot 25% p10 2.4
  vendetta       k0  monster-strength 1.3, monster-health -0.1, bruiser-strength -1.2, durability-strength -1.6  | worst skirmish-focus -8.7 | maps 100% boot 25% p10 -0.4
  vendetta       k1  jungle-health -0.1, capture-health -0.3, monster-health -0.3, jungle-strength -0.7  | worst home-focus -7.2 | maps 0% boot 25% p10 -0.9
  vendetta       k2  collectors-strength 2.1, tribute-strength 1.8, collectors-health 1.8, tribute-health 1.4  | worst skirmish-focus -7.0 | maps 100% boot 0% p10 -1.6
  vendetta       k3+ tribute-strength 0.6, monster-strength 0.1, hunter-strength 0.0, bruiser-strength -0.1  | worst skirmish-focus -5.5 | maps 100% boot 0% p10 -2.3
  cassi          k0  monster-strength 2.6, monster-health 1.5, jungle-strength 1.2, prospector-strength 0.3  | worst power-focus -5.2 | maps 100% boot 25% p10 0.4
  cassi          k1  jungle-health 2.9, jungle-strength 2.1, monster-health 1.2, prospector-health 1.1  | worst home-focus -4.4 | maps 100% boot 100% p10 3.4
  cassi          k2  monster-strength 2.7, tribute-strength 2.7, jungle-strength 2.7, collectors-strength 2.6  | worst skirmish-focus -3.0 | maps 100% boot 0% p10 -0.1
  cassi          k3+ hunter-strength 2.0, jungle-strength 1.8, hunter-health 1.5, tribute-strength 1.5  | worst durability-focus -2.4 | maps 100% boot 0% p10 1.0
  issac          k0  monster-health 0.5, capture-health 0.3, monster-strength -0.0, capture-strength -0.2  | worst durability-focus -4.9 | maps 100% boot 25% p10 -2.4
  issac          k1  capture-health 3.1, tribute-health 2.3, jungle-health 1.4, skirmish-health 1.3  | worst durability-strength -4.1 | maps 100% boot 75% p10 -0.6
  issac          k2  tribute-health 4.5, capture-health 3.2, tribute-strength 3.0, tribute-focus 3.0  | worst durability-focus -2.6 | maps 100% boot 50% p10 3.1
  issac          k3+ tribute-health 3.0, capture-health 2.1, tribute-focus 2.0, tribute-strength 1.8  | worst durability-strength -3.6 | maps 100% boot 25% p10 -0.2
  prism          k0  monster-strength -0.6, monster-health -0.7, jungle-strength -1.4, jungle-health -1.5  | worst skirmish-focus -8.0 | maps 0% boot 0% p10 -3.8
  prism          k1  jungle-health 1.4, capture-health -0.1, jungle-strength -0.5, durability-health -0.8  | worst bruiser-focus -6.1 | maps 100% boot 75% p10 0.4
  prism          k2  tribute-health 1.0, jungle-health 1.0, collectors-health 0.4, monster-health 0.4  | worst skirmish-focus -6.3 | maps 100% boot 25% p10 0.2
  prism          k3+ home-health -0.1, hunter-health -0.1, jungle-health -0.2, tribute-health -0.5  | worst skirmish-focus -4.8 | maps 0% boot 0% p10 -1.0
  marcella       k0  monster-health 1.3, monster-strength 0.4, monster-focus 0.2, capture-health -0.5  | worst hunter-focus -5.8 | maps 100% boot 50% p10 -1.0
  marcella       k1  capture-health 2.3, jungle-health 2.2, treasure-health 1.4, skirmish-health 1.2  | worst hunter-strength -4.4 | maps 100% boot 50% p10 0.1
  marcella       k2  monster-health 2.4, capture-health 2.3, jungle-health 1.8, tribute-health 1.5  | worst hunter-strength -4.4 | maps 100% boot 0% p10 0.7
  marcella       k3+ capture-health 1.2, monster-health 0.8, home-health 0.8, jungle-health 0.7  | worst collectors-strength -2.8 | maps 100% boot 50% p10 0.5
  willow         k0  monster-health 0.0, durability-health -0.1, capture-health -0.5, prospector-health -0.5  | worst skirmish-focus -4.9 | maps 100% boot 0% p10 -1.1
  willow         k1  capture-health 2.3, power-health 1.7, hunter-health 1.6, durability-health 1.6  | worst home-strength -3.8 | maps 100% boot 0% p10 -0.1
  willow         k2  tribute-health 3.3, power-health 2.8, collectors-health 2.5, capture-health 2.4  | worst skirmish-strength -4.0 | maps 100% boot 50% p10 1.7
  willow         k3+ hunter-health 2.4, power-health 2.3, tribute-health 1.8, home-health 1.7  | worst skirmish-strength -2.7 | maps 100% boot 0% p10 0.9
  ren            k0  monster-strength 3.1, monster-health 3.1, prospector-strength 0.7, prospector-health 0.6  | worst skirmish-focus -6.0 | maps 100% boot 25% p10 0.3
  ren            k1  jungle-health 3.0, monster-health 2.8, prospector-health 2.6, collectors-health 2.1  | worst home-focus -3.8 | maps 100% boot 75% p10 2.1
  ren            k2  collectors-health 4.7, monster-health 4.2, collectors-strength 3.8, tribute-health 3.7  | worst skirmish-focus -4.3 | maps 100% boot 50% p10 0.3
  ren            k3+ monster-health 2.6, prospector-health 2.3, home-health 2.2, tribute-health 2.2  | worst treasure-focus -3.3 | maps 100% boot 25% p10 2.0
  varg           k0  monster-strength 1.2, monster-health 0.5, durability-strength 0.1, monster-focus 0.1  | worst power-focus -4.9 | maps 100% boot 50% p10 -1.4
  varg           k1  durability-health 1.2, treasure-health 1.2, capture-health 0.6, jungle-health 0.6  | worst home-strength -2.7 | maps 100% boot 0% p10 -1.5
  varg           k2  tribute-health 2.3, tribute-strength 2.0, durability-health 1.8, tribute-focus 1.7  | worst skirmish-focus -3.0 | maps 100% boot 0% p10 1.1
  varg           k3+ tribute-health 0.8, tribute-strength 0.8, hunter-health 0.8, hunter-strength 0.7  | worst skirmish-focus -1.5 | maps 100% boot 0% p10 -1.0
  tavi           k0  monster-strength 0.1, jungle-strength -1.4, monster-focus -1.8, durability-strength -1.8  | worst prospector-health -5.9 | maps 100% boot 100% p10 -1.6
  tavi           k1  jungle-strength -0.4, jungle-health -0.5, tribute-strength -0.8, tribute-health -0.8  | worst prospector-focus -4.4 | maps 0% boot 25% p10 -2.4
  tavi           k2  tribute-strength 2.4, tribute-health 1.4, tribute-focus 1.4, collectors-strength 1.0  | worst skirmish-focus -4.0 | maps 100% boot 50% p10 -1.4
  tavi           k3+ tribute-strength 1.2, tribute-focus 0.4, hunter-strength 0.2, tribute-health -0.1  | worst prospector-health -4.2 | maps 100% boot 50% p10 -1.4
  heart_of_ruin  k0  monster-health -0.4, monster-strength -0.4, durability-health -0.5, durability-strength -0.5  | worst power-focus -4.4 | maps 0% boot 50% p10 -1.3
  heart_of_ruin  k1  jungle-health 2.2, capture-health 1.2, durability-health 1.2, jungle-focus 1.2  | worst home-strength -4.7 | maps 100% boot 50% p10 0.2
  heart_of_ruin  k2  tribute-health 3.0, collectors-health 2.7, tribute-focus 2.4, collectors-focus 2.1  | worst home-strength -2.6 | maps 100% boot 25% p10 3.4
  heart_of_ruin  k3+ tribute-health 1.5, tribute-focus 1.4, hunter-health 1.1, hunter-focus 1.0  | worst treasure-strength -1.7 | maps 100% boot 0% p10 0.2

5 picks. Model choice term MD by ordinal k0 0.078, k1 0.054, k2 -0.002, k3 0.008
  ryth           k0  jungle-health 1.1, monster-health 0.7, collectors-health 0.1, home-health 0.1  | worst tribute-focus -4.2 | maps 100% boot 0% p10 0.4
  ryth           k1  jungle-health 2.8, hunter-health 1.4, jungle-focus 1.1, jungle-strength 1.0  | worst monster-strength -2.6 | maps 100% boot 75% p10 2.1
  ryth           k2  collectors-health 4.0, collectors-strength 3.2, home-health 2.3, bruiser-health 2.3  | worst power-focus -2.6 | maps 100% boot 25% p10 2.3
  ryth           k3+ jungle-health 2.7, hunter-health 2.4, jungle-strength 1.9, durability-health 1.8  | worst treasure-focus -1.9 | maps 100% boot 75% p10 1.8
  vesper_vale    k0  monster-strength 1.9, monster-health 0.8, jungle-strength 0.7, prospector-strength -0.2  | worst hunter-focus -7.3 | maps 100% boot 75% p10 1.1
  vesper_vale    k1  jungle-strength 1.9, jungle-health 1.3, monster-strength -0.1, prospector-strength -0.2  | worst collectors-focus -5.1 | maps 100% boot 100% p10 1.2
  vesper_vale    k2  monster-strength 3.6, collectors-strength 2.5, jungle-strength 2.3, home-strength 2.2  | worst power-focus -5.7 | maps 100% boot 50% p10 2.0
  vesper_vale    k3+ jungle-strength 2.7, monster-strength 2.7, prospector-strength 1.6, jungle-health 1.1  | worst power-focus -4.2 | maps 100% boot 75% p10 1.1
  vendetta       k0  monster-health 1.8, monster-strength 1.5, jungle-health -0.0, jungle-strength -0.3  | worst hunter-focus -5.6 | maps 100% boot 75% p10 1.5
  vendetta       k1  jungle-health 1.7, jungle-strength 0.9, durability-health 0.3, monster-health 0.3  | worst home-focus -4.2 | maps 100% boot 50% p10 0.9
  vendetta       k2  collectors-strength 3.2, monster-strength 3.2, collectors-health 3.0, monster-health 3.0  | worst power-focus -4.3 | maps 100% boot 25% p10 -0.8
  vendetta       k3+ monster-strength 2.3, monster-health 2.1, jungle-strength 1.8, jungle-health 1.6  | worst home-focus -3.4 | maps 100% boot 0% p10 -0.0
  cassi          k0  monster-health -0.6, jungle-health -0.6, monster-strength -0.7, jungle-strength -0.7  | worst hunter-focus -5.3 | maps 0% boot 50% p10 -2.5
  cassi          k1  jungle-health 1.1, jungle-focus 0.7, jungle-strength 0.5, durability-health -1.8  | worst collectors-strength -4.6 | maps 100% boot 50% p10 0.3
  cassi          k2  monster-strength 1.0, jungle-strength 0.9, monster-health 0.7, jungle-health 0.5  | worst durability-focus -3.6 | maps 100% boot 0% p10 -2.2
  cassi          k3+ jungle-strength 1.4, jungle-focus 1.1, jungle-health 1.0, monster-strength 0.1  | worst treasure-health -3.5 | maps 100% boot 25% p10 0.5
  issac          k0  capture-health -0.3, jungle-health -0.3, monster-health -0.4, capture-focus -0.7  | worst durability-strength -4.4 | maps 0% boot 0% p10 -2.2
  issac          k1  jungle-focus 1.5, jungle-health 1.4, capture-focus 0.7, capture-health 0.5  | worst durability-strength -3.6 | maps 100% boot 25% p10 -0.3
  issac          k2  tribute-health 2.0, tribute-focus 1.7, tribute-strength 1.7, capture-health 1.5  | worst durability-strength -3.5 | maps 100% boot 0% p10 -2.7
  issac          k3+ jungle-focus 1.9, capture-focus 1.8, tribute-focus 1.5, jungle-health 1.3  | worst home-strength -2.1 | maps 100% boot 25% p10 0.3
  prism          k0  jungle-health 3.2, jungle-strength 2.7, monster-health 2.5, monster-strength 2.0  | worst skirmish-focus -4.1 | maps 100% boot 25% p10 0.9
  prism          k1  jungle-health 4.9, jungle-strength 3.9, jungle-focus 3.6, durability-health 2.3  | worst treasure-focus -2.8 | maps 100% boot 25% p10 3.0
  prism          k2  jungle-health 4.3, jungle-strength 4.2, monster-health 3.7, monster-strength 3.7  | worst power-focus -2.4 | maps 100% boot 0% p10 2.4
  prism          k3+ jungle-health 4.8, jungle-strength 4.7, jungle-focus 4.0, durability-health 3.2  | worst treasure-focus -2.3 | maps 100% boot 50% p10 2.7
  marcella       k0  monster-focus 1.4, monster-strength 1.0, monster-health 0.9, jungle-focus 0.6  | worst hunter-health -4.7 | maps 100% boot 0% p10 -1.0
  marcella       k1  jungle-focus 2.9, jungle-health 1.8, jungle-strength 1.4, durability-focus 0.9  | worst collectors-strength -4.1 | maps 100% boot 50% p10 0.4
  marcella       k2  monster-focus 2.7, monster-strength 2.7, monster-health 2.1, jungle-focus 1.8  | worst hunter-health -2.3 | maps 100% boot 0% p10 -0.9
  marcella       k3+ jungle-focus 3.2, monster-focus 2.7, durability-focus 2.3, jungle-strength 2.3  | worst collectors-health -3.0 | maps 100% boot 50% p10 0.8
  willow         k0  power-health 0.6, durability-health -0.3, bruiser-health -0.5, treasure-health -0.6  | worst tribute-strength -4.5 | maps 100% boot 25% p10 -1.2
  willow         k1  durability-health 1.0, jungle-health 0.6, power-health 0.4, durability-focus 0.4  | worst monster-strength -4.9 | maps 100% boot 0% p10 -2.1
  willow         k2  bruiser-health 1.6, collectors-health 1.2, home-health 1.2, prospector-health 0.9  | worst skirmish-strength -2.0 | maps 100% boot 25% p10 -1.7
  willow         k3+ durability-health 1.9, durability-focus 1.7, hunter-health 0.8, prospector-health 0.7  | worst collectors-strength -3.1 | maps 100% boot 0% p10 0.7
  ren            k0  monster-health 2.6, monster-strength 2.2, prospector-health 1.1, prospector-strength 0.7  | worst hunter-focus -4.3 | maps 100% boot 75% p10 1.8
  ren            k1  jungle-health 2.4, prospector-health 1.5, jungle-strength 1.5, monster-health 1.1  | worst treasure-focus -3.1 | maps 100% boot 75% p10 1.8
  ren            k2  collectors-strength 4.0, monster-strength 3.9, collectors-health 3.8, monster-health 3.8  | worst durability-focus -2.9 | maps 100% boot 0% p10 1.6
  ren            k3+ monster-strength 3.0, monster-health 2.9, prospector-strength 2.5, prospector-health 2.4  | worst treasure-focus -2.6 | maps 100% boot 0% p10 1.3
  varg           k0  monster-health 1.2, monster-focus 0.6, durability-health 0.4, treasure-health 0.2  | worst skirmish-strength -3.8 | maps 100% boot 75% p10 -1.5
  varg           k1  durability-health 1.7, durability-focus 1.7, jungle-health 1.3, jungle-focus 1.2  | worst collectors-strength -4.0 | maps 100% boot 25% p10 -1.4
  varg           k2  monster-health 2.4, monster-focus 1.9, monster-strength 1.7, treasure-health 1.6  | worst power-strength -2.3 | maps 100% boot 0% p10 1.5
  varg           k3+ durability-focus 3.0, durability-health 2.6, monster-focus 1.9, durability-strength 1.8  | worst collectors-strength -2.3 | maps 100% boot 50% p10 1.5
  tavi           k0  jungle-strength 1.7, power-strength 1.4, monster-strength 1.2, jungle-health 0.4  | worst capture-focus -3.9 | maps 100% boot 0% p10 0.4
  tavi           k1  jungle-strength 2.9, jungle-focus 2.5, jungle-health 2.1, power-strength 0.8  | worst capture-health -2.9 | maps 100% boot 100% p10 2.2
  tavi           k2  collectors-strength 3.6, tribute-strength 3.5, jungle-strength 3.3, monster-strength 2.9  | worst capture-health -2.0 | maps 100% boot 0% p10 1.9
  tavi           k3+ jungle-strength 3.8, jungle-focus 2.9, durability-strength 2.6, tribute-strength 2.4  | worst capture-health -2.4 | maps 100% boot 25% p10 2.4
  heart_of_ruin  k0  jungle-health -0.8, bruiser-health -1.1, durability-health -1.2, jungle-strength -1.2  | worst collectors-focus -3.8 | maps 0% boot 0% p10 -1.9
  heart_of_ruin  k1  jungle-health 0.9, jungle-focus 0.9, durability-health 0.1, durability-focus 0.1  | worst collectors-strength -4.0 | maps 100% boot 25% p10 -1.0
  heart_of_ruin  k2  bruiser-strength 1.2, bruiser-health 1.1, tribute-strength 0.8, tribute-health 0.7  | worst power-focus -2.5 | maps 100% boot 0% p10 -2.2
  heart_of_ruin  k3+ durability-focus 1.5, jungle-focus 1.3, durability-strength 1.1, durability-health 1.0  | worst home-health -2.4 | maps 100% boot 25% p10 -0.0
