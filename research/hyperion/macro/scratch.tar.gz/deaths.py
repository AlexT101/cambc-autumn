import gzip, json, sys
from collections import Counter
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def cheb(a,b): return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def one(d):
    R=json.load(gzip.open(d/'rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(d/'events.jsonl.gz','rt')]
    meta=json.loads((d/'meta.json').read_text())
    ch=R['champions']; idx={c['id']:i for i,c in enumerate(ch)}
    rix={r:i for i,r in enumerate(R['round'])}
    out=[]
    for e in ev:
        if e['k']!='death' or e.get('linked') or 'camp' in e: continue
        v=e['v']; r=e['r']; i=rix.get(r-1, 0)
        t=ch[idx[v]]['team']; p=e['at']
        al=sum(1 for c in ch if c['team']==t and c['id']!=v and c['alive'][i] and c['x'][i] is not None and cheb(p,(c['x'][i],c['y'][i]))<=6)
        en=sum(1 for c in ch if c['team']!=t and c['alive'][i] and c['x'][i] is not None and cheb(p,(c['x'][i],c['y'][i]))<=6)
        out.append((t==meta['result']['winner'], al, en, e['gems'], r)) if r<int(__import__('os').environ.get('MAXR','5000')) else None
    return out
if __name__=='__main__':
  root=Path(sys.argv[1]); dirs=[p.parent for p in root.glob('*/meta.json')]
  with ProcessPoolExecutor(64) as ex: res=[x for l in ex.map(one,dirs) for x in l]
  c=Counter((min(a,3),min(b,4)) for w,a,b,g,r in res)
  print(len(res),'champion kills; (victim allies within 6, enemies within 6):')
  for k,v in sorted(c.items()): print(k, v, f'{100*v/len(res):.1f}%')
  print('allies-enemies diff:', sorted(Counter(max(-3,min(3,a+1-b)) for w,a,b,g,r in res).items()))
