import json,sys,collections,gzip
sys.path.insert(0,'/home/ubuntu/cambc-autumn/tools/replay')
from concurrent.futures import ProcessPoolExecutor
from analysis.data import Game
def f(d):
    g=Game(d); ev=g.events; out=collections.Counter()
    open_={}
    shops=collections.defaultdict(set)
    for e in ev:
        if e['k']=='shop': shops[e['a']].add(e['r'])
    for e in ev:
        if e['k']=='recall_start': open_[e['a']]=e
        elif e['k']=='recall_end' and e['a'] in open_:
            st=open_.pop(e['a']); c=e['a']; ch=g.ch(c); i=st['r']-2
            hpf=ch['hp'][i]/ch['maxHp'][i] if i>=0 else 1
            shop=any(r in shops[c] for r in range(e['r'], e['r']+3))
            out['n']+=1; out['shop']+=shop; out['hp<50']+=hpf<0.5; out['hp<80']+=hpf<0.8; out['bag']+=st['gems']>0
            out['useless']+= (not shop) and hpf>=0.8 and st['gems']==0
        elif e['k']=='recall_cancel': open_.pop(e['a'],None)
    return out
if __name__=='__main__':
    idx=json.load(open('/home/ubuntu/cambc-autumn/replays/.analysis/index.json'))['games']
    ds=sorted({r['dir'] for r in idx if 'm3-mirror' in r['source']})
    with ProcessPoolExecutor(90) as ex: tot=sum(ex.map(f,ds), collections.Counter())
    n=tot['n']; print(n, n/len(ds)/2, {k: round(100*v/n,1) for k,v in tot.items()})
