import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    mp=json.loads((d/meta['mapFile']).resolve().read_text())
    camps={c['id']:c for c in mp['camps']}
    groups=mp['groups']
    STR={'Wolf':20,'Elk':60,'Golem':120,'Monolith':200}
    gstr={g['id']:sum(STR.get(t,0) for t in g['types']) for g in groups}
    ev=[json.loads(l) for l in gzip.open(d/'events.jsonl.gz','rt')]
    R=json.load(gzip.open(d/'rounds.json.gz'))
    team={c['id']:c['team'] for c in R['champions']}
    # visits: per (champion, group) consecutive damage rounds (gap<=3)
    visits={}  # (a,g)->[start,last,dealt,taken]
    done=[]
    cleared_at=collections.defaultdict(list)
    for e in ev:
        k=e['k']; r=e['r']
        if k in('attack','cast') and e.get('cdmg'):
            for cid,amt in e['cdmg']:
                g=camps[cid]['group']; key=(e['a'],g)
                v=visits.get(key)
                if v and r-v[1]<=4: v[1]=r; v[2]+=amt
                else:
                    if v: done.append((key,v))
                    visits[key]=[r,r,amt,0.0]
        elif k=='camp_attack' and e.get('tgt') is not None:
            key=(e['tgt'],e['g'])
            v=visits.get(key)
            if v and r-v[1]<=4: v[3]+=e['dmg']
        elif k=='group_clear':
            cleared_at[e['g']].append(r)
    done+=list(visits.items())
    out=collections.Counter()
    for (a,g),(s,l,dealt,taken) in done:
        if gstr[g]<60: continue
        cl=any(s<=c<=l+2 for c in cleared_at[g])
        # simultaneous others: count other visits same team same group overlapping
        k='clear' if cl else 'chip'
        out[k+'_n']+=1; out[k+'_rounds']+=l-s+1; out[k+'_dealt']+=dealt; out[k+'_taken']+=taken
    out['strong_gems_cleared']=sum(groups[g]['gems']*len(v) for g,v in cleared_at.items() if gstr[g]>=60)
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    T=collections.Counter()
    for r in res: T.update(r)
    n=len(res)
    for k in sorted(T): print(k, round(T[k]/n,1))
