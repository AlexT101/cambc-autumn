import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    R=json.load(gzip.open(d/'rounds.json.gz'))
    rix={r:i for i,r in enumerate(R['round'])}
    ch={c['id']:c for c in R['champions']}
    out=[]
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k']=='recall_end':
            c=ch[e['a']]; i=rix.get(e['r']-6)
            if i is None: continue
            out.append((c['hp'][i]/c['maxHp'][i], e['gems'], c['gold'][i]))
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=[x for l in ex.map(one,dirs) for x in l]
    n=len(dirs)
    print(len(res)/n/2,'recalls per team-game')
    h=collections.Counter(min(9,int(f*10)) for f,g,go in res)
    print('hp fraction decile at recall start:', sorted((k/10,round(v/len(res),3)) for k,v in h.items()))
    print('with gems:', sum(1 for f,g,go in res if g>0)/len(res), ' gold>=150:', sum(1 for f,g,go in res if go>=150)/len(res))
    print('hp>=0.6:', sum(1 for f,g,go in res if f>=0.6)/len(res), 'of which gold>=100', sum(1 for f,g,go in res if f>=0.6 and go>=100)/max(1,sum(1 for f,g,go in res if f>=0.6)))
