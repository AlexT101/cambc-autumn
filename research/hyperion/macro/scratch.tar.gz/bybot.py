import json,sys,collections
res=json.load(open(sys.argv[1]))
by=collections.defaultdict(list)
for r in res:
    for t in ('0','1'):
        by[r['names'][int(t)]].append((r, r['teams'][t], int(t)==r['winner']))
keys=('gems300','gems600','earned','clears','capture_gems','deaths','gems_lost','kills','tributes','tribute_gems','recalls','camp_taken','champ_taken','ally_near')
for name,rows in by.items():
    tot=collections.Counter()
    for r,x,w in rows: tot.update(x['time'])
    s=sum(tot.values())
    print(f"{name} n={len(rows)} win {100*sum(w for *_,w in rows)/len(rows):.1f}%")
    print('  '+', '.join(f"{k} {100*v/s:.1f}" for k,v in sorted(tot.items(), key=lambda kv:-kv[1])))
    print('  '+', '.join(f"{k} {sum(x[k] for _,x,_ in rows)/len(rows):.1f}" for k in keys))
