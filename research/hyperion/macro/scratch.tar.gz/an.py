import pickle,collections,sys
R=pickle.load(open(sys.argv[1],'rb'))
def pct(f,s): s=list(s); return f"{100*sum(1 for x in s if f(x))/max(1,len(s)):.0f}% (n={len(s)})"
for lab,sel in [('all',R),('first3',[x for x in R if x['order']<=3]),('loserdeaths',[x for x in R if not x['win']]),('winnerdeaths',[x for x in R if x['win']])]:
    print('==',lab)
    print(' victim mostly R last 8 (>=6):',pct(lambda x: x['vbr'].count('R')>=6,sel))
    print(' victim chased-into C/A in last 8 (>=2 C):',pct(lambda x: x['vbr'].count('C')>=2,sel))
    print(' victim F only last 8 (>=6 F):',pct(lambda x: x['vbr'].count('F')>=6,sel))
    print(' victim B/T carrying (>=4 B):',pct(lambda x: x['vbr'].count('B')>=4,sel))
    print(' no ally within 8:',pct(lambda x: x['anear']==0,sel))
    print(' enemies within8 >= 2:',pct(lambda x: x['enear']>=2,sel))
    print(' attackers >=2:',pct(lambda x: x['natt']>=2,sel))
    print(' nearest ally <=10, hp>60%, F/B/P all window:',pct(lambda x: x['ally'] and x['ally'][0]<=10 and x['ally'][1]>0.6 and set(x['ally'][2])<=set('FBPQTtKkS'),sel))
    print(' nearest ally 5-12 farming(F>=5):',pct(lambda x: x['ally'] and 5<=x['ally'][0]<=12 and x['ally'][2].count('F')>=5,sel))
    print(' spawn dist not reduced over 10 rounds while R>=6:',pct(lambda x: x['sp1']>=x['sp0']-1,[y for y in sel if y['vbr'].count('R')>=6]))
    print(' killer branch had C:',pct(lambda x: 'C' in x['kbr'],sel))
    print(' gems>=30:',pct(lambda x: x['gems']>=30,sel))
c=collections.Counter()
for x in R:
    if x['ally']: c[min(x['ally'][0],20)//3]+=1
print('nearest ally dist buckets(/3):',sorted(c.items()))
