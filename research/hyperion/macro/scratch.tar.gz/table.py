import re,sys,glob,os
S=os.path.dirname(os.path.abspath(__file__))
pre=sys.argv[1]
for t in sys.argv[2:]:
    f=f"{S}/{pre}-{t}.log"
    if not os.path.exists(f): continue
    s=open(f).read()
    def cell(name):
        m=re.search(r"^\| "+re.escape(name)+r" \| ([^|]+) \|",s,re.M); return m.group(1).strip() if m else '?'
    fs=re.search(r"faster / slower / identical: (\d+) / (\d+) / (\d+)",s)
    print(f"| {t} | {cell('round to 1000 (log ratio)')} | {cell('collected @300')} | {cell('collected @600')} | {cell('gold earned @600')} | {fs.group(1)}/{fs.group(2)} |" if fs else f"| {t} | ? |")
