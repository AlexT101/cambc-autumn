# Walk audit: 70 games, 4.7 champions per game, 3726 champion-rounds per game

## 1. Walk legs

181 legs per game, 2047 walking rounds per game (54.9% of champion-rounds); mean 11.3 rounds, 11.3 steps; median 7.

Walking rounds by leg length: 1-4 6.6%, 5-9 13.5%, 10-19 25.6%, 20-39 32.7%, 40+ 21.6%

| origin | destination | legs/game | rounds/leg | steps/leg | rounds/game | % of walking | % with bag |
|---|---|---|---|---|---|---|---|
| recall arrival | camp:Elk | 7.4 | 22.4 | 22.3 | 165 | 8.1 | 50.3 |
| recall arrival | altar | 9.2 | 17.7 | 17.7 | 163 | 8.0 | 100.0 |
| camp | idle | 8.0 | 13.3 | 13.2 | 106 | 5.2 | 24.1 |
| payout | idle | 6.1 | 16.6 | 16.6 | 102 | 5.0 | 36.5 |
| tribute | idle | 6.9 | 14.4 | 14.4 | 98.8 | 4.8 | 0.0 |
| payout | altar | 11.6 | 8.3 | 8.2 | 96.1 | 4.7 | 31.0 |
| recall arrival | idle | 4.5 | 19.6 | 19.6 | 88.8 | 4.3 | 53.6 |
| tribute | camp:Elk | 5.6 | 15.5 | 15.5 | 87.2 | 4.3 | 0.0 |
| recall arrival | camp:Wolf | 5.3 | 14.9 | 14.9 | 79.0 | 3.9 | 55.4 |
| camp | camp:Elk | 10.8 | 6.8 | 6.7 | 73.1 | 3.6 | 34.7 |
| camp | camp:Wolf | 12.4 | 5.8 | 5.8 | 71.8 | 3.5 | 40.0 |
| recall arrival | end | 0.2 | 220 | 220 | 50.4 | 2.5 | 43.8 |
| fight | fight | 5.8 | 7.7 | 7.7 | 44.8 | 2.2 | 75.9 |
| camp | camp:GoldCl | 5.5 | 7.7 | 7.7 | 42.6 | 2.1 | 15.5 |
| tribute | camp:Wolf | 3.3 | 11.2 | 11.2 | 37.0 | 1.8 | 0.0 |
| recall arrival | camp:GoldCl | 2.2 | 15.8 | 15.7 | 34.2 | 1.7 | 34.9 |
| payout | camp:Wolf | 3.2 | 10.6 | 10.6 | 33.8 | 1.7 | 49.1 |
| payout | camp:GoldCl | 3.3 | 9.4 | 9.4 | 30.7 | 1.5 | 12.7 |
| recall cancelled | idle | 1.8 | 16.8 | 16.8 | 30.7 | 1.5 | 29.7 |
| payout | camp:Elk | 2.5 | 11.8 | 11.8 | 29.7 | 1.5 | 44.9 |
| camp | camp:GemCl | 4.2 | 6.3 | 6.3 | 26.2 | 1.3 | 42.6 |
| recall arrival | camp:GemCl | 1.1 | 23.1 | 23.1 | 26.0 | 1.3 | 63.3 |

By origin: recall arrival 32.7%, camp 19.5%, payout 17.6%, tribute 13.9%, recall cancelled 4.9%, idle 3.1%, start 3.1%, fight 3.0%, left hold 1.7%, respawn 0.4%, spawn 0.2%, teleport 0.0%

By dest: camp 50.0%, idle 22.6%, altar 14.9%, end 4.1%, hold 3.2%, fight 2.7%, recall 1.9%, teleport 0.3%, spawn 0.2%, died 0.1%

## 2. Walks to a camp: detours and pass-bys

| legs | per game | % not to nearest available | extra steps (those) | extra steps/game | % nearer had >= gems | dest gems | nearer gems | % passed an available group | gems passed | % ally on same group |
|---|---|---|---|---|---|---|---|---|---|---|
| all to-camp legs | 89.3 | 39.3 | 19657612 | 690263012 | 47.2 | 32.1 | 43.6 | 14.6 | 44.4 | 46.2 |
| destination available at start | 54.7 | 42.5 | 23772894 | 552210356 | 49.9 | 30.2 | 41.6 | 16.5 | 45.2 | 35.2 |
| destination respawning/cleared at start | 34.6 | 34.3 | 11615007 | 138052656 | 41.9 | 35.8 | 47.7 | 11.8 | 42.7 | 63.6 |

Available destinations by type:

| type | legs | % not nearest | extra steps | steps/leg | % passed another |
|---|---|---|---|---|---|
| Wolf | 1233 | 35.1 | 24797742 | 9.4 | 15.3 |
| Elk | 1197 | 51.7 | 13877129 | 13.7 | 18.8 |
| GoldCl | 756 | 37.3 | 26653176 | 9.3 | 13.8 |
| GemCl | 455 | 40.4 | 64191100 | 10.2 | 15.8 |
| Golem | 129 | 51.9 | 19.6 | 16.7 | 19.4 |
| Monolith | 56 | 73.2 | 13.8 | 19.7 | 26.8 |

## 3. Crews

Camp-hit champion-rounds on a group another ally hits the same round: 45.3%; to-camp legs whose group an ally works or heads to meanwhile: 46.2%; mean clear 17.6 rounds from first hit.

## 4. Banking trips (last group worked -> altar -> next group worked)

28.7 tributes per game, mean bag 35.2 (median 24.0); 41.1% under 20 gems.

| tributes | n | rounds to altar | rounds back | trip (no recall) | best walk via any altar | recall+walk alt | % used altar 3+ farther than nearest | extra altar dist | % recall alt < actual | % recall alt < best walk | trip rounds per gem |
|---|---|---|---|---|---|---|---|---|---|---|---|
| all | 2006 | 12.3 | 13.8 | 18.9 | 53217542 | 22956626 | 14.6 | 2676328 | 5.7 | 3.5 | 0.8 |
| bag < 20 | 824 | 11.1 | 11.9 | 16.8 | 35932321 | 10568370 | 15.3 | 6515426 | 5.5 | 2.6 | 2.3 |
| bag 20-59 | 945 | 11.8 | 15.0 | 20.2 | 69043284 | 33331280 | 15.0 | 2.7 | 5.8 | 4.4 | 0.7 |
| bag 60+ | 237 | 18.8 | 15.9 | 26.5 | 76695868 | 46017560 | 10.1 | 2.2 | 7.1 | 4.3 | 0.4 |

Trips with a recall in them: 43.0%; next group is the same as the last: 9.8%.

## 5. Recalls

9.0 real recalls per champion per game (88.6% complete); 64.6% start on a capture tile (hold+recall).

| recalls | per champion-game | walk dist from spawn at start | % with bag | % shop on arrival | rounds arrival -> next camp | walk-out distance | % back to the same group | recall+walk-out rounds/game |
|---|---|---|---|---|---|---|---|---|
| all completed | 8.0 | 29.2 | 31.4 | 77.2 | 26.7 | 26178714 | 13.8 | 1174 |
| hp < 50% | 2.6 | 32.1 | 24.6 | 49.0 | 26.4 | 16499604 | 25.1 | 381 |
| hp 50-80% | 1.8 | 31.4 | 36.0 | 90.8 | 30.9 | 22764873 | 12.7 | 291 |
| hp >= 80% | 3.6 | 26.0 | 34.0 | 90.9 | 24.9 | 34814175 | 6.1 | 502 |

## 6. Idle off spawn

238 idle-off rounds per game (6.4% of champion-rounds).

| where | rounds/game | % of idle | % in runs 1-2 | 3-9 | 10-49 | 50+ | respawn timer left at start |
|---|---|---|---|---|---|---|---|
| by respawning group | 183 | 76.8 | 6.3 | 64.7 | 6.6 | 22.4 | 10.5 |
| by live group (asleep) | 16.7 | 7.0 | 3.8 | 48.6 | 26.2 | 21.5 | - |
| by live group (awake) | 15.7 | 6.6 | 5.0 | 77.8 | 6.2 | 11.0 | - |
| elsewhere | 13.4 | 5.6 | 8.3 | 33.4 | 45.3 | 12.9 | - |
| by cleared group, unheld | 4.7 | 2.0 | 12.4 | 87.6 | 0.0 | 0.0 | - |
| by cleared group, held | 3.4 | 1.4 | 14.6 | 43.1 | 42.3 | 0.0 | - |
| at altar | 0.9 | 0.4 | 6.7 | 35.0 | 58.3 | 0.0 | - |
| at altar with bag | 0.3 | 0.1 | 0.0 | 0.0 | 100.0 | 0.0 | - |

## 7. Group utilisation

| groups | respawns | mean rounds up before first hit | gem-weighted | % never hit before game end |
|---|---|---|---|---|
| Q1 (nearest) | 1769 | 47.7 | 77.2 | 7.7 |
| Q2 | 1474 | 93.3 | 115 | 11.7 |
| Q3 | 1303 | 122 | 174 | 13.2 |
| Q4 (farthest) | 928 | 377 | 407 | 45.7 |
| Wolf | 1514 | 171 | 137 | 21.7 |
| Elk | 1135 | 138 | 134 | 15.9 |
| Golem | 77 | 231 | 318 | 23.4 |
| Monolith | 45 | 655 | 697 | 60.0 |
| GemCl | 1291 | 75.7 | 53.0 | 10.1 |
| GoldCl | 1412 | 120 | 194 | 15.5 |

Captured 1066 gems per game of a supply bound of 3756 (every group farmed on cooldown: gems x rounds / (respawn + typical clear + 6)) = 28.4%; by side own 39.5% of 1426, mid 35.9% of 819, enemy 13.8% of 1511.

## 8. Opening

| metric | mean | median |
|---|---|---|
| round of first capture | 25.5 | 22.5 |
| round of first tribute | 104 | 65.0 |
| gems captured by r100 | 88.4 | 63.5 |
| gems captured by r200 | 205 | 152 |
| gems tributed by r200 | 130 | 90.0 |
| round reaching 1000 tributed | 775 | 758 |
| games not reaching 1000 | 2 |  |

## Examples

**Longest detours past a nearer available group**

- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/045-01islands-12.repl26a` r157 Vendetta#0: camp:Wolf (11 gems) at 1073741824 steps, nearest available 1 steps (29 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/046-01shortcut-12.repl26a` r484 Vesper Vale#0: camp:Wolf (8 gems) at 1073741824 steps, nearest available 2 steps (22 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/042-01fracture-12.repl26a` r497 Heart of Ruin#4: camp:GemCl (14 gems) at 1073741824 steps, nearest available 3 steps (4 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/069-adgato-gemcombat4-12.repl26a` r1 Heart of Ruin#4: camp:GemCl (21 gems) at 1073741824 steps, nearest available 11 steps (28 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/036-01big-world-21.repl26a` r173 Issac#7: camp:GemCl (21 gems) at 1073741824 steps, nearest available 17 steps (41 gems)

**Longest walk-outs after a recall**

- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/026-00reverse-spiral-12.repl26a` Vesper Vale#1: 455 rounds from arrival to the next camp (distance 9)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/030-00rushbait-v2-12.repl26a` Prism#2: 412 rounds from arrival to the next camp (distance 11)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/058-02guardians-21.repl26a` Marcella#5: 204 rounds from arrival to the next camp (distance 20)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/064-02treasure-box-12.repl26a` Tavi#4: 182 rounds from arrival to the next camp (distance 32)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/061-02tangle-21.repl26a` Cassi#6: 175 rounds from arrival to the next camp (distance 51)

**Longest idle stretches**

- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/062-02the-pack-12.repl26a` r712 Prism#0 idle 1289 rounds at (13, 0) (by respawning group)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/034-00the-line-12.repl26a` r523 Issac#1 idle 75 rounds at (3, 20) (by live group (asleep))
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/041-01elk-arena-12.repl26a` r303 Willow#4 idle 64 rounds at (23, 23) (by live group (awake))
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/058-02guardians-21.repl26a` r713 Marcella#5 idle 63 rounds at (16, 26) (elsewhere)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/005-00contest-21.repl26a` r323 Marcella#7 idle 61 rounds at (17, 37) (by live group (asleep))

**Longest banking trips**

- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/026-00reverse-spiral-12.repl26a` r130 Ryth#0: 7 gems, 119 rounds to the altar + 6 back (best walk 60, recall alt 61)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/039-01concentrated-wealth-12.repl26a` r490 Willow#3: 4 gems, 4 rounds to the altar + 113 back (best walk 9, recall alt 94)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/028-00road-of-riches-21.repl26a` r196 Willow#8: 7 gems, 109 rounds to the altar + 0 back (best walk 114, recall alt 126)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/054-02famine-12.repl26a` r1266 Vendetta#1: 32 gems, 22 rounds to the altar + 71 back (best walk 78, recall alt 73)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/063-02the-pond-12.repl26a` r708 Heart of Ruin#2: 60 gems, 21 rounds to the altar + 72 back (best walk 2147483646, recall alt 1073741847)

