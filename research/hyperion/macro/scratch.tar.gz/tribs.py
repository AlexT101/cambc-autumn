import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    ev=[json.loads(l) for l in gzip.open(d/'events.jsonl.gz','rt')]
    R=json.load(gzip.open(d/'rounds.json.gz'))
    rix={r:i for i,r in enumerate(R['round'])}
    ch={c['id']:c for c in R['champions']}
    lastwork={}
    out=[]
    for e in ev:
        if e['k'] in ('attack','cast') and e.get('cdmg'): lastwork[e['a']]=e['r']
        if e['k']=='capture':
            for s in e['shares']: lastwork[s[0]]=e['r']
        if e['k']=='tribute_start':
            a=e['a']; lw=lastwork.get(a,0)
            out.append((e['gems'], e['r']-lw, e['r']))
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=[x for l in ex.map(one,dirs) for x in l]
    n=len(dirs)*2
    b=collections.defaultdict(list)
    for g,gap,r in res: b[min(g//10*10,100)].append(min(gap,200))
    print('bag bucket: tributes/team-game, mean rounds since last camp work/capture, total gems')
    for k in sorted(b): v=b[k]; print(k, round(len(v)/n,2), round(sum(v)/len(v),1), round(sum(min(g//10*10,100)==k and g or 0 for g,_,_ in res)/n,1))
