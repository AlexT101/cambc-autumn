"""Wins by our team's carrier kind, Marcella's gold and tributes, carrier deaths: ours (bot 1) vs base, per batch."""
import gzip, json, os, sys, statistics as st
from collections import defaultdict

batch, root = os.path.abspath(sys.argv[1]), sys.argv[2]
index = json.load(open(os.path.join(root, 'index.json')))
wins = defaultdict(lambda: [0, 0])
marc = defaultdict(list)
deaths = defaultdict(list)
caps = defaultdict(list)


def kind(c):
    return str(c['type']).lower() + ' ' + str(c['name']).lower()


for g in index['games']:
    src = g['source'] if os.path.isabs(g['source']) else os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', g['source']))
    if not src.startswith(batch):
        continue
    d = os.path.join(root, g['dir'])
    meta = json.load(open(os.path.join(d, 'meta.json')))
    ev = [json.loads(l) for l in gzip.open(os.path.join(d, 'events.jsonl.gz'), 'rt')]
    our = 0 if src.endswith('-12.repl26a') else 1
    mine = [c for c in meta['champions'] if c['team'] == our]
    has_prism = any('prism' in kind(c) for c in mine)
    has_marc = any('marcella' in kind(c) for c in mine)
    cls = 'prism' if has_prism else 'marcella, no prism' if has_marc else 'neither'
    wins[cls][0] += meta['result']['winner'] == our
    wins[cls][1] += 1
    for who, team in (('ours', our), ('base', 1 - our)):
        champs = [c for c in meta['champions'] if c['team'] == team]
        p = [c for c in champs if 'prism' in kind(c)]
        m = [c for c in champs if 'marcella' in kind(c)]
        carrier = p[0] if p else m[0] if m else None
        if carrier:
            deaths[(who, 'prism' if p else 'marcella')].append(carrier['deaths'])
        if cls == 'marcella, no prism' and m and not p:
            mc = m[0]
            tributed = sum(e['gems'] for e in ev if e['k'] == 'tribute_end' and e['a'] == mc['id'])
            alone = sum(1 for e in ev if e['k'] == 'capture' and len(e['shares']) == 1 and e['shares'][0][0] == mc['id'])
            marc[who].append((mc['earnedGold'], tributed, alone, meta['result']['gems'][team]))

for cls, (w, n) in sorted(wins.items()):
    print(f'{cls}: ours won {w}/{n} ({100 * w / n:.1f}%)')
for who, v in marc.items():
    print(f'Marcella ({who}, games with our Marcella and no Prism, n={len(v)}): earned gold {st.mean(x[0] for x in v):.0f},'
          f' gems she tributed {st.mean(x[1] for x in v):.0f}, captures held alone {st.mean(x[2] for x in v):.1f}, team tributed {st.mean(x[3] for x in v):.0f}')
for k, v in sorted(deaths.items()):
    print(f'carrier deaths {k}: {st.mean(v):.2f}/game over {len(v)} games')
