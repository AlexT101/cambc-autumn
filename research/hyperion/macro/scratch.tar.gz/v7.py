import pickle, collections, statistics as st
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits2.pkl', 'rb'))
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
for want in ['best/a', 'shared/c', 'help/c', 'after-strike-walk-on']:
    ends = collections.Counter(); flips = []; xs = []
    for v in allv:
        if v['cleared'] or 'choice' not in v: continue
        k = v['choice'][1][1]; key = k['br'] + '/' + k['rsn']
        if key == 'cut-short/?': key = 'after-strike-walk-on'
        if key != want: continue
        fs, wk, D, wh = games[v['game']]
        c = v['c']; G = v['G']
        hp, mx = map(float, k['hp'].split('/')); A = float(k['alone']); S = hp - float(k['line']) * mx
        end = None
        for r in range(v['r0'], v['r1'] + 3):
            if r in wh[c]: end = 'recall:' + wh[c][r]; break
            d = D[c].get(r)
            if d and d[1] != G and d[0] in 'FB':
                end = 'switched(fg->%d,dec=%s)' % (d[1], d[0]); break
            if d and d[0] in 'CA': end = 'fight:' + d[0]; break
        if v['died']: end = 'died'
        ends[end or 'gap/other'] += 1
        if want == 'best/a': xs.append((A, S, (S - 0.35 * A) / 0.65, v['taken'], end))
    print(want, ends.most_common())
    if xs:
        sw = [x for x in xs if x[4] and x[4].startswith('switched')]
        print('  best/a switched: n', len(sw), 'median predicted flip dmg', st.median(x[2] for x in sw) if sw else None, 'median taken', st.median(x[3] for x in sw) if sw else None)
        rc = [x for x in xs if x[4] and x[4].startswith('recall')]
        print('  best/a recalled: n', len(rc), 'median realS', st.median(x[1] for x in rc) if rc else None, 'median taken', st.median(x[3] for x in rc) if rc else None, 'median A', st.median(x[0] for x in rc) if rc else None)
