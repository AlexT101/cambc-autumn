import pickle, collections, statistics as st
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits.pkl', 'rb'))
def key(v):
    return (v['fs'][2]['br'] + '/' + v['fs'][2]['rsn']) if v['fs'] and v['fs'][1] == v['G'] else 'x'
for want in ['best/a', 'shared/c', 'help/c', 'passing/?', 'cut-short/?']:
    for label, vs in (('chip', [v for v in allv if not v['cleared'] and key(v) == want]), ('clear', [v for v in allv if v['cleared'] and key(v) == want])):
        if not vs: continue
        def f(k): return [float(v['fs'][2][k]) for v in vs]
        hp = [float(v['fs'][2]['hp'].split('/')[0]) for v in vs]; mx = [float(v['fs'][2]['hp'].split('/')[1]) for v in vs]
        line = f('line'); alone = f('alone'); spare = f('spare')
        real = [h - l * m for h, l, m in zip(hp, line, mx)]
        print(f'{want} {label} n={len(vs)} alone/hp med={st.median(a/h for a,h in zip(alone,hp)):.2f} alone/realspare med={st.median(a/max(r,1) for a,r in zip(alone,real)):.2f} '
              f'frac alone>realspare={sum(a>r for a,r in zip(alone,real))/len(vs):.2f} frac alone>hp={sum(a>h for a,h in zip(alone,hp))/len(vs):.2f} hp/max med={st.median(h/m for h,m in zip(hp,mx)):.2f} line0.18 frac={sum(l<0.2 for l in line)/len(vs):.2f} '
              f'taken/visit med={st.median(v["taken"] for v in vs):.0f} dealt med={st.median(v["dealt"] for v in vs):.0f} unclaimed>0={sum(float(v["fs"][2]["unclaimed"])>0 for v in vs)/len(vs):.2f}')
