import sys, collections
sys.path.insert(0,'/home/ubuntu/cambc-autumn/tools/replay')
from analysis import Game, resolve
dirs=resolve(sys.argv[1:]); seen=set()
solo=collections.Counter(); shared=collections.Counter(); hitdmg_shared=collections.Counter(); hit_solo=collections.Counter()
for d in dirs:
    g=Game(d); m=g.meta
    if m['sha256'] in seen: continue
    seen.add(m['sha256'])
    team={c['id']:c['team'] for c in m['champions']}; typ={c['id']:str(c.get('name') or c['type']).rstrip('0123456789 ') for c in m['champions']}
    camp_group={}
    for c in g.map.raw['camps']: camp_group[c['id']]=c['group']
    last=collections.defaultdict(dict)
    for e in g.events:
        k=e['k']
        if k in('attack','cast') and e.get('cdmg'):
            for cid,dm in e['cdmg']:
                gr=camp_group.get(cid)
                if gr is not None: last[gr][e['a']]=e['r']
        elif k=='camp_attack':
            gr=e['g']; t=e['tgt']; r=e['r']
            hs={c for c,rr in last[gr].items() if r-rr<=6 and team.get(c)==team.get(t)}
            if len(hs|{t})>=2: shared[typ.get(t)]+=e['dmg']
            else: solo[typ.get(t)]+=e['dmg']
    # hits share
print('camp damage taken, shared clears by type (%):')
T=sum(shared.values())
for k,v in shared.most_common(): print(f'  {k:14s} {100*v/T:5.1f}  solo share {100*solo[k]/sum(solo.values()):5.1f}')
