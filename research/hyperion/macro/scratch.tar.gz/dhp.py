import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def cheb(a,b): return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    names=[t['name'] for t in meta['teams']]
    R=json.load(gzip.open(d/'rounds.json.gz')); rix={r:i for i,r in enumerate(R['round'])}
    ch={c['id']:c for c in R['champions']}
    sp=json.loads((d/meta['mapFile']).resolve().read_text())['spawn']
    out=[]
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k']=='death' and not e.get('linked') and 'camp' not in e:
            c=ch[e['v']]; i=rix.get(e['r']-8)
            if i is None or not c['alive'][i]: continue
            t=c['team']; s=sp[t]; o=sp[1-t]
            p=(c['x'][i],c['y'][i])
            ds=cheb(p,((s['minX']+s['maxX'])/2,(s['minY']+s['maxY'])/2)); de=cheb(p,((o['minX']+o['maxX'])/2,(o['minY']+o['maxY'])/2))
            out.append((names[t], c['hp'][i]/c['maxHp'][i], ds<de))
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(48) as ex: res=[x for l in ex.map(one,dirs) for x in l]
    for bot in set(n for n,_,_ in res):
        v=[(h,own) for n,h,own in res if n==bot]
        b=collections.Counter(min(int(h*10),9) for h,_ in v)
        print(bot, len(v)/len(dirs), 'champion-kill deaths/game; hp 8 rounds before, by decile:', [round(b[k]/len(dirs),2) for k in range(10)], 'own half share %.2f'%(sum(o for _,o in v)/len(v)))
