# Walk audit: 326 games, 4.5 champions per game, 3818 champion-rounds per game

## 1. Walk legs

197 legs per game, 2022 walking rounds per game (53.0% of champion-rounds); mean 10.2 rounds, 10.2 steps; median 7.0.

Walking rounds by leg length: 1-4 8.0%, 5-9 15.5%, 10-19 31.3%, 20-39 31.3%, 40+ 14.0%

| origin | destination | legs/game | rounds/leg | steps/leg | rounds/game | % of walking | % with bag |
|---|---|---|---|---|---|---|---|
| camp | idle | 12.9 | 13.0 | 13.0 | 168 | 8.3 | 20.4 |
| tribute | idle | 11.0 | 15.2 | 15.2 | 168 | 8.3 | 0.0 |
| recall arrival | altar | 12.9 | 10.5 | 10.5 | 136 | 6.7 | 100.0 |
| payout | idle | 7.2 | 15.8 | 15.7 | 114 | 5.6 | 42.5 |
| recall arrival | camp:Elk | 5.8 | 16.9 | 16.9 | 97.7 | 4.8 | 54.5 |
| payout | altar | 13.1 | 7.3 | 7.3 | 95.3 | 4.7 | 33.0 |
| recall arrival | idle | 5.2 | 17.0 | 17.0 | 88.3 | 4.4 | 56.3 |
| tribute | camp:Elk | 5.7 | 12.5 | 12.5 | 70.9 | 3.5 | 0.0 |
| camp | camp:Elk | 9.1 | 6.7 | 6.7 | 60.9 | 3.0 | 31.2 |
| camp | camp:Wolf | 10.4 | 5.7 | 5.7 | 59.4 | 2.9 | 32.1 |
| recall arrival | camp:Wolf | 4.9 | 11.0 | 11.0 | 54.6 | 2.7 | 57.4 |
| idle | idle | 4.1 | 11.3 | 11.2 | 46.2 | 2.3 | 25.3 |
| tribute | camp:GemCl | 3.1 | 14.1 | 14.1 | 44.2 | 2.2 | 0.0 |
| tribute | camp:Wolf | 4.6 | 9.2 | 9.2 | 42.0 | 2.1 | 0.0 |
| camp | camp:GemCl | 5.2 | 7.4 | 7.4 | 38.9 | 1.9 | 33.6 |
| camp | camp:GoldCl | 4.6 | 7.2 | 7.2 | 33.0 | 1.6 | 20.2 |
| recall arrival | camp:Golem | 2.0 | 15.6 | 15.6 | 31.5 | 1.6 | 32.7 |
| recall cancelled | idle | 1.9 | 16.6 | 16.6 | 31.5 | 1.6 | 35.8 |
| payout | camp:GoldCl | 3.0 | 9.9 | 9.9 | 30.2 | 1.5 | 23.9 |
| payout | camp:GemCl | 2.7 | 10.7 | 10.6 | 28.9 | 1.4 | 55.1 |
| recall arrival | camp:GoldCl | 2.5 | 11.3 | 11.3 | 28.2 | 1.4 | 47.4 |
| payout | camp:Wolf | 3.1 | 8.4 | 8.4 | 25.9 | 1.3 | 47.7 |

By origin: recall arrival 25.5%, camp 22.5%, tribute 20.0%, payout 17.3%, recall cancelled 4.9%, idle 4.2%, start 2.2%, left hold 1.5%, fight 1.1%, teleport 0.3%, respawn 0.3%, spawn 0.2%

By dest: camp 45.0%, idle 31.3%, altar 13.8%, end 3.1%, hold 3.0%, recall 1.5%, fight 1.1%, teleport 1.1%, died 0.1%, spawn 0.1%

## 2. Walks to a camp: detours and pass-bys

(0.9 to-camp legs per game go to a group with no walking path (dash-only), left out.)

| legs | per game | % not to nearest available | extra steps (those) | extra steps/game | % nearer had >= gems | dest gems | nearer gems | % passed an available group | gems passed | % ally on same group |
|---|---|---|---|---|---|---|---|---|---|---|
| all to-camp legs | 89.5 | 37.7 | 8.8 | 298 | 46.1 | 25.0 | 44.4 | 14.9 | 54.1 | 44.5 |
| destination available at start | 40.5 | 41.2 | 9.2 | 154 | 51.7 | 18.6 | 40.4 | 17.9 | 45.9 | 14.4 |
| destination respawning/cleared at start | 49.0 | 34.7 | 8.5 | 144 | 40.6 | 31.3 | 48.4 | 12.4 | 63.8 | 69.4 |

Available destinations by type:

| type | legs | % not nearest | extra steps | steps/leg | % passed another |
|---|---|---|---|---|---|
| Wolf | 3620 | 33.8 | 8.1 | 8.3 | 14.0 |
| GoldCl | 3130 | 34.2 | 7.6 | 8.0 | 13.5 |
| Elk | 3006 | 52.5 | 10.0 | 11.6 | 22.8 |
| GemCl | 2573 | 44.9 | 9.8 | 8.8 | 21.9 |
| Golem | 827 | 46.3 | 11.8 | 13.7 | 20.1 |
| Monolith | 52 | 67.3 | 16.0 | 20.6 | 38.5 |

## 3. Crews

Camp-hit champion-rounds on a group another ally hits the same round: 47.7%; to-camp legs whose group an ally works or heads to meanwhile: 44.5%; mean clear 13.8 rounds from first hit.

## 4. Banking trips (last group worked -> altar -> next group worked)

36.7 tributes per game, mean bag 27.5 (median 16.5); 57.0% under 20 gems.

| tributes | n | rounds to altar | rounds back | trip (no recall) | direct walk last->next group | overhead/trip | overhead rounds/game | best walk via any altar | recall+walk alt | % used altar 3+ farther than nearest | extra altar dist | % recall alt < actual | % recall alt < best walk | trip rounds per gem |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| all | 11698 | 8.9 | 14.2 | 19.0 | 12.3 | 6.8 | 110 | 17.3 | 37.3 | 17.8 | 2.6 | 13.5 | 2.8 | 0.9 |
| bag < 20 | 6657 | 7.3 | 14.3 | 18.2 | 11.9 | 6.3 | 61.5 | 16.0 | 33.8 | 18.7 | 2.6 | 16.4 | 3.3 | 2.1 |
| bag 20-59 | 4177 | 10.1 | 14.0 | 19.9 | 12.7 | 7.1 | 40.8 | 18.9 | 41.8 | 17.3 | 2.7 | 9.3 | 2.0 | 0.7 |
| bag 60+ | 864 | 15.8 | 14.2 | 23.1 | 13.3 | 9.8 | 7.4 | 23.2 | 46.9 | 13.3 | 2.4 | 7.7 | 1.6 | 0.3 |

Trips with a recall in them: 49.4%; next group is the same as the last: 8.1%.

## 5. Recalls

10.9 real recalls per champion per game (91.1% complete); 68.6% start on a capture tile (hold+recall).

Recall detour: recall rounds off a capture tile + walk spawn->next group - walk last group->next group = mean 3.4 rounds (n=13539; 344 rounds/game where positive; recall faster in 40.8%). Bag recalls then walked to an altar: 4.2/game taking 21.7 rounds (recall + walk) vs 16.8 to walk from the last group to its nearest altar; 34.8 rounds/game lost.

| recalls | per champion-game | walk dist from spawn at start | % with bag | % shop on arrival | rounds arrival -> next camp | walk-out distance | % back to the same group | recall+walk-out rounds/game |
|---|---|---|---|---|---|---|---|---|
| all completed | 9.9 | 24.1 | 28.7 | 77.4 | 22.3 | 17.5 | 11.5 | 1196 |
| hp < 50% | 2.9 | 24.7 | 26.2 | 50.9 | 20.1 | 17.8 | 24.3 | 320 |
| hp 50-80% | 2.1 | 23.9 | 28.9 | 92.3 | 23.7 | 19.0 | 6.5 | 265 |
| hp >= 80% | 4.9 | 23.9 | 30.1 | 86.5 | 23.0 | 16.7 | 6.1 | 610 |

## 6. Idle off spawn

298 idle-off rounds per game (7.8% of champion-rounds).

| where | rounds/game | % of idle | % in runs 1-2 | 3-9 | 10-49 | 50+ | respawn timer left at start |
|---|---|---|---|---|---|---|---|
| by respawning group | 203 | 68.1 | 7.8 | 82.0 | 5.1 | 5.2 | 8.1 |
| elsewhere | 27.9 | 9.3 | 14.4 | 28.1 | 22.4 | 35.1 | - |
| by live group (asleep) | 25.9 | 8.7 | 2.2 | 29.2 | 16.2 | 52.3 | - |
| by cleared group, held | 16.7 | 5.6 | 3.1 | 13.1 | 25.2 | 58.6 | - |
| by live group (awake) | 16.2 | 5.4 | 5.0 | 70.9 | 17.5 | 6.6 | - |
| by cleared group, unheld | 7.2 | 2.4 | 8.3 | 48.6 | 43.1 | 0.0 | - |
| at altar | 1.2 | 0.4 | 7.0 | 36.8 | 56.1 | 0.0 | - |
| at altar with bag | 0.1 | 0.0 | 36.4 | 9.1 | 54.5 | 0.0 | - |

## 7. Group utilisation

| groups | respawns | mean rounds up before first hit | gem-weighted | % never hit before game end |
|---|---|---|---|---|
| Q1 (nearest) | 9540 | 37.7 | 54.3 | 6.5 |
| Q2 | 7631 | 67.3 | 127 | 9.0 |
| Q3 | 7070 | 126 | 193 | 14.2 |
| Q4 (farthest) | 5475 | 416 | 441 | 50.7 |
| Wolf | 7378 | 168 | 139 | 21.5 |
| Elk | 6104 | 137 | 133 | 18.6 |
| Golem | 1198 | 212 | 227 | 22.5 |
| Monolith | 183 | 806 | 850 | 64.5 |
| GemCl | 7998 | 77.3 | 65.7 | 10.8 |
| GoldCl | 6855 | 138 | 79.9 | 16.4 |

Captured 1034 gems per game of a supply bound of 3637 (every group farmed on cooldown: gems x rounds / (respawn + typical clear + 6)) = 28.4%; by side own 45.5% of 1539, mid 28.8% of 568, enemy 11.1% of 1531.

## 8. Opening

| metric | mean | median |
|---|---|---|
| round of first capture | 23.3 | 20.0 |
| round of first tribute | 90.0 | 53.0 |
| gems captured by r100 | 79.8 | 65.5 |
| gems captured by r200 | 185 | 154 |
| gems tributed by r200 | 124 | 102 |
| round reaching 1000 tributed | 824 | 784 |
| games not reaching 1000 | 15 |  |

## Examples

**Longest detours past a nearer available group**

- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/028-00road-of-riches-21.repl26a` r515 Vendetta#5: camp:GemCl (21 gems) at 140 steps, nearest available 11 steps (22 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/245-mut-road-of-riches-600101813-21.repl26a` r431 Heart of Ruin#9: camp:GemCl (21 gems) at 140 steps, nearest available 11 steps (22 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/061-02tangle-21.repl26a` r969 Heart of Ruin#10: camp:GoldCl (0 gems) at 133 steps, nearest available 17 steps (4 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/048-01starvation-21.repl26a` r1 Vendetta#5: camp:Wolf (4 gems) at 180 steps, nearest available 83 steps (200 gems)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/243-mut-pilgrimage-600101824-21.repl26a` r412 Vesper Vale#5: camp:Elk (33 gems) at 140 steps, nearest available 50 steps (88 gems)

**Longest walk-outs after a recall**

- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/248-mut-rushbait-v2-600101846-12.repl26a` Prism#2: 680 rounds from arrival to the next camp (distance 11)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/251-mut-stampede-600101844-12.repl26a` Heart of Ruin#3: 593 rounds from arrival to the next camp (distance 56)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/254-mut-the-pack-600101845-21.repl26a` Willow#6: 574 rounds from arrival to the next camp (distance 5)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/168-gen-monolith-only-600101500-21.repl26a` Willow#8: 534 rounds from arrival to the next camp (distance 14)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/026-00reverse-spiral-12.repl26a` Vesper Vale#1: 455 rounds from arrival to the next camp (distance 9)

**Longest idle stretches**

- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/031-gen-atoll-600101919-12.repl26a` r674 Heart of Ruin#2 idle 1327 rounds at (43, 68) (elsewhere)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/062-02the-pack-12.repl26a` r712 Prism#0 idle 1289 rounds at (13, 0) (by respawning group)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/254-mut-the-pack-600101845-21.repl26a` r1099 Marcella#5 idle 902 rounds at (28, 34) (by cleared group, held)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/251-mut-stampede-600101844-12.repl26a` r195 Heart of Ruin#3 idle 534 rounds at (3, 1) (elsewhere)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/047-gen-chambers-600103608-21.repl26a` r385 Willow#6 idle 156 rounds at (40, 26) (by live group (asleep))

**Longest banking trips**

- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/047-gen-chambers-600103608-21.repl26a` r359 Marcella#5: 47 gems, 19 rounds to the altar + 184 back (best walk 31, recall alt 63)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/178-gen-rivers-600102101-12.repl26a` r702 Heart of Ruin#2: 8 gems, 22 rounds to the altar + 135 back (best walk 56, recall alt 62)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/037-gen-blob-600103700-12.repl26a` r1236 Issac#2: 35 gems, 72 rounds to the altar + 82 back (best walk 54, recall alt 73)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/026-00reverse-spiral-12.repl26a` r130 Ryth#0: 7 gems, 119 rounds to the altar + 6 back (best walk 60, recall alt 61)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/001-gen-altar-poor-600101000-21.repl26a` r778 Issac#6: 17 gems, 82 rounds to the altar + 37 back (best walk 88, recall alt 97)

