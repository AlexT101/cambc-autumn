# Turn budget: 582 games from replays/batch-20261030-094349-ab-m3-mirror-ladder, replays/batch-20261030-094349-ab-m3-mirror-gen, replays/batch-20261030-094349-ab-m3-mirror-fresh-gen-s1

Mirror mode: identical replays (a map pair swapped between two copies of one bot) count once; sides are the game winner (W) and loser (L).

Trace: 1 of 1164 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 0.0% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all W | all L | r1-150 W | r1-150 L | r151-400 W | r151-400 L | r401-800 W | r401-800 L | r801+ W | r801+ L | r1-300 W | r1-300 L |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 3.6 | 7.3 | 2.3 | 3.5 | 3.1 | 5.1 | 3.7 | 7.2 | 4.5 | 11.2 | 2.7 | 4.2 |
| fight | 3.6 | 3.6 | 2.7 | 2.6 | 2.9 | 2.9 | 3.5 | 3.5 | 4.9 | 5.0 | 2.8 | 2.8 |
| tribute | 3.5 | 2.4 | 1.7 | 1.6 | 2.8 | 2.5 | 4.2 | 2.9 | 4.1 | 2.1 | 2.2 | 2.0 |
| recall | 3.8 | 3.8 | 3.8 | 3.8 | 4.4 | 4.5 | 3.9 | 3.8 | 3.1 | 3.1 | 4.2 | 4.3 |
| hold+recall | 3.2 | 3.0 | 3.5 | 3.4 | 4.3 | 4.1 | 3.3 | 3.2 | 2.0 | 1.7 | 4.0 | 3.7 |
| teleport | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.1 | 0.1 | 0.1 | 0.1 | 0.0 | 0.0 |
| camp | 17.6 | 16.5 | 27.3 | 26.7 | 21.0 | 20.3 | 16.6 | 15.6 | 10.8 | 8.9 | 24.6 | 23.9 |
| hold | 4.9 | 4.4 | 5.5 | 5.3 | 5.1 | 4.8 | 4.7 | 4.4 | 4.4 | 3.6 | 5.3 | 5.1 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 12.7 | 11.9 | 9.3 | 9.2 | 13.9 | 13.4 | 14.5 | 13.6 | 11.2 | 9.9 | 11.4 | 11.1 |
| bag->camp | 4.7 | 4.6 | 3.9 | 3.9 | 5.9 | 5.7 | 5.0 | 5.2 | 3.6 | 3.5 | 4.9 | 4.9 |
| bag-other | 2.5 | 2.8 | 1.4 | 1.6 | 2.3 | 2.4 | 2.7 | 2.9 | 3.0 | 3.7 | 1.8 | 2.0 |
| empty->camp | 24.2 | 22.9 | 28.3 | 27.8 | 22.4 | 22.2 | 23.3 | 22.0 | 24.7 | 22.1 | 25.4 | 25.0 |
| empty->spawn | 3.0 | 3.4 | 2.1 | 2.1 | 2.2 | 2.3 | 2.7 | 3.0 | 4.5 | 5.4 | 2.1 | 2.2 |
| empty-other | 6.4 | 7.2 | 4.6 | 4.9 | 4.7 | 4.9 | 5.6 | 6.6 | 9.8 | 11.3 | 4.6 | 4.9 |
| idle-off | 6.2 | 6.0 | 3.5 | 3.5 | 4.8 | 4.9 | 6.1 | 6.0 | 9.1 | 8.2 | 4.1 | 4.0 |
| idle-spawn | 0.1 | 0.2 | 0.0 | 0.0 | 0.0 | 0.1 | 0.1 | 0.1 | 0.3 | 0.4 | 0.0 | 0.0 |

By attack type (all rounds):

| class | melee W | melee L | ranged W | ranged L |
|---|---|---|---|---|
| dead | 3.6 | 7.3 | 3.6 | 7.2 |
| fight | 4.1 | 4.1 | 2.6 | 2.8 |
| tribute | 3.8 | 2.9 | 2.9 | 1.5 |
| recall | 4.0 | 4.0 | 3.4 | 3.4 |
| hold+recall | 3.6 | 3.3 | 2.6 | 2.4 |
| teleport | 0.1 | 0.0 | 0.1 | 0.1 |
| camp | 16.7 | 15.4 | 19.3 | 18.3 |
| hold | 4.4 | 3.9 | 5.7 | 5.3 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 12.6 | 11.7 | 12.8 | 12.1 |
| bag->camp | 3.6 | 3.6 | 6.7 | 6.6 |
| bag-other | 2.3 | 2.6 | 2.8 | 3.2 |
| empty->camp | 25.5 | 24.2 | 21.9 | 20.6 |
| empty->spawn | 3.0 | 3.5 | 2.9 | 3.1 |
| empty-other | 7.1 | 7.9 | 5.2 | 6.1 |
| idle-off | 5.7 | 5.4 | 7.2 | 7.1 |
| idle-spawn | 0.1 | 0.1 | 0.2 | 0.3 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | W | 187996 | 4.3 | 1.1 | 20.6 | 5.3 | 2.0 | 3.3 | 0.0 | 0.0 | 6.5 | 53.3 |
| Cassi | L | 187996 | 7.4 | 1.2 | 19.7 | 5.2 | 1.7 | 3.1 | 0.0 | 0.1 | 6.1 | 52.0 |
| Heart of Ruin | W | 490308 | 4.4 | 7.1 | 18.5 | 4.2 | 3.0 | 3.4 | 0.0 | 0.1 | 5.6 | 50.9 |
| Heart of Ruin | L | 490308 | 8.8 | 6.7 | 16.8 | 3.6 | 2.2 | 3.4 | 0.0 | 0.1 | 5.6 | 50.1 |
| Issac | W | 187996 | 4.3 | 1.6 | 18.5 | 4.8 | 3.4 | 3.7 | 0.0 | 0.0 | 4.8 | 54.5 |
| Issac | L | 187996 | 7.4 | 1.6 | 17.4 | 4.3 | 2.9 | 3.7 | 0.0 | 0.0 | 4.8 | 53.7 |
| Marcella | W | 513599 | 3.5 | 3.8 | 14.2 | 4.6 | 3.8 | 4.5 | 0.0 | 0.1 | 6.0 | 56.2 |
| Marcella | L | 513599 | 7.4 | 3.9 | 13.4 | 4.1 | 2.6 | 4.1 | 0.0 | 0.2 | 5.4 | 56.0 |
| Prism | W | 280750 | 2.5 | 2.4 | 19.1 | 8.6 | 4.2 | 3.2 | 0.0 | 0.4 | 7.6 | 50.0 |
| Prism | L | 280750 | 5.9 | 2.4 | 19.3 | 8.7 | 0.9 | 3.3 | 0.0 | 0.7 | 8.0 | 48.9 |
| Ren | W | 6742 | 3.8 | 6.4 | 17.7 | 1.7 | 2.3 | 3.0 | 0.0 | 0.2 | 2.3 | 59.7 |
| Ren | L | 6742 | 8.4 | 6.1 | 14.4 | 1.0 | 2.0 | 3.8 | 0.0 | 2.1 | 1.9 | 57.6 |
| Ryth | W | 30608 | 5.7 | 9.8 | 11.5 | 2.9 | 3.1 | 4.2 | 0.0 | 0.3 | 6.0 | 54.3 |
| Ryth | L | 30608 | 9.8 | 10.1 | 8.4 | 8.6 | 3.0 | 4.1 | 0.0 | 0.2 | 4.9 | 48.9 |
| Tavi | W | 41205 | 7.1 | 6.8 | 15.4 | 4.6 | 1.9 | 2.0 | 0.0 | 0.7 | 8.9 | 50.7 |
| Tavi | L | 41205 | 13.5 | 7.9 | 12.8 | 3.6 | 1.4 | 2.1 | 0.0 | 0.6 | 7.7 | 48.9 |
| Varg | W | 41342 | 2.4 | 1.3 | 20.6 | 2.9 | 4.1 | 3.1 | 0.0 | 0.0 | 4.2 | 56.7 |
| Varg | L | 41342 | 3.5 | 1.1 | 19.8 | 3.0 | 3.6 | 3.0 | 0.0 | 0.0 | 4.6 | 56.9 |
| Vendetta | W | 457256 | 2.5 | 2.2 | 16.7 | 4.4 | 4.9 | 4.3 | 0.0 | 0.0 | 5.9 | 54.4 |
| Vendetta | L | 457256 | 5.9 | 2.3 | 15.5 | 3.8 | 3.9 | 4.7 | 0.0 | 0.0 | 5.4 | 54.1 |
| Vesper Vale | W | 222173 | 2.4 | 4.6 | 18.5 | 4.1 | 3.5 | 4.0 | 0.0 | 0.1 | 5.3 | 54.1 |
| Vesper Vale | L | 222173 | 5.7 | 4.6 | 17.2 | 3.5 | 2.4 | 4.1 | 0.0 | 0.1 | 4.6 | 54.5 |
| Willow | W | 222473 | 5.0 | 1.4 | 19.9 | 4.2 | 1.5 | 3.3 | 0.0 | 0.2 | 8.8 | 53.7 |
| Willow | L | 222473 | 8.7 | 1.9 | 18.1 | 3.0 | 1.1 | 3.4 | 0.0 | 0.3 | 9.0 | 52.7 |

Bot branch (D lines), % of champion-rounds:

| branch | all W | all L | r1-300 W | r1-300 L |
|---|---|---|---|---|
| `-` | 3.7 | 7.3 | 2.7 | 4.2 |
| `?` | 0.0 | 0.0 | 0.0 | 0.0 |
| `B` | 20.3 | 19.4 | 19.0 | 19.0 |
| `C` | 2.7 | 2.1 | 1.7 | 1.6 |
| `E` | 0.0 | 0.2 | 0.0 | 0.0 |
| `F` | 53.3 | 51.0 | 58.5 | 57.1 |
| `G` | 2.6 | 2.2 | 0.4 | 0.4 |
| `H` | 0.9 | 0.8 | 1.0 | 1.0 |
| `K` | 1.2 | 1.4 | 1.7 | 1.8 |
| `P` | 4.7 | 4.2 | 5.4 | 5.1 |
| `Q` | 2.5 | 2.3 | 3.1 | 2.9 |
| `R` | 5.0 | 6.7 | 4.4 | 4.9 |
| `S` | 0.1 | 0.0 | 0.1 | 0.0 |
| `T` | 1.8 | 1.1 | 0.9 | 0.8 |
| `W` | 0.0 | 0.0 | 0.0 | 0.0 |
| `X` | 0.1 | 0.1 | 0.1 | 0.1 |
| `h` | 0.3 | 0.3 | 0.4 | 0.4 |
| `k` | 0.8 | 0.7 | 0.6 | 0.5 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 295078 | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |
| `?` | 2106 | 4 |  | 30 |  |  |  |  | 5 |  |  |  |  |  |  |  | 60 | 1 |
| `B` | 1066747 |  | 2 | 4 | 1 |  |  | 14 |  |  | 50 | 14 | 7 |  |  |  | 6 |  |
| `C` | 128633 |  | 17 |  |  |  |  |  |  |  | 11 | 4 | 13 | 18 | 5 | 31 |  |  |
| `E` | 5951 |  | 42 |  |  |  |  |  |  |  | 7 |  | 6 | 6 | 3 | 31 | 2 | 2 |
| `F` | 2797818 |  | 3 | 1 |  |  |  | 26 | 1 |  | 3 | 3 |  | 41 | 2 | 10 | 8 |  |
| `G` | 130194 |  | 2 |  |  |  |  | 13 |  |  | 1 |  |  | 23 | 12 | 20 | 26 |  |
| `H` | 46042 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 70573 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 238368 |  | 1 |  |  | 12 |  | 2 | 85 |  |  |  |  |  |  |  |  |  |
| `Q` | 127898 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 312540 |  | 22 |  | 7 |  |  |  |  |  | 4 | 4 | 11 | 20 | 25 | 6 | 1 |  |
| `S` | 2886 |  | 2 | 45 | 4 |  |  |  |  |  | 4 | 2 | 9 | 10 | 24 |  |  |  |
| `T` | 78414 |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `W` | 724 |  | 12 |  |  |  |  |  |  |  | 1 |  |  |  |  |  | 86 |  |
| `X` | 4709 |  | 6 |  |  |  |  |  | 44 |  | 2 |  | 2 | 20 | 1 | 25 |  |  |
| `h` | 14485 |  | 1 |  |  |  |  | 6 |  |  |  |  |  | 20 | 11 | 12 | 48 |  |
| `k` | 41504 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 226 |  | 24 |  |  |  |  | 4 |  |  | 12 | 11 | 14 | 3 | 6 |  | 24 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 291785 | `-` 100, `?` 0, `F` 0, `B` 0 |
| fight | 193668 | `F` 38, `R` 35, `C` 11, `B` 11 |
| tribute | 156732 | `T` 50, `B` 25, `F` 23, `S` 1 |
| recall | 203125 | `K` 35, `H` 23, `k` 20, `R` 10 |
| hold+recall | 166822 | `Q` 77, `P` 17, `F` 5, `B` 1 |
| teleport | 3120 | `F` 67, `B` 31, `C` 2, `R` 1 |
| camp | 914123 | `F` 81, `B` 17, `G` 2, `P` 1 |
| hold | 248633 | `P` 81, `F` 14, `B` 3, `X` 1 |
| spawn-heal | 28 | `H` 54, `F` 39, `B` 7 |
| bag->altar | 657683 | `B` 81, `F` 14, `C` 2, `R` 2 |
| bag->camp | 250577 | `B` 58, `F` 34, `R` 5, `C` 2 |
| bag-other | 143007 | `B` 50, `R` 23, `F` 15, `C` 11 |
| empty->camp | 1263642 | `F` 90, `R` 5, `G` 2, `C` 2 |
| empty->spawn | 170823 | `R` 46, `F` 39, `G` 9, `C` 4 |
| empty-other | 366521 | `F` 74, `C` 11, `G` 7, `R` 6 |
| idle-off | 326948 | `F` 65, `B` 20, `G` 10, `h` 2 |
| idle-spawn | 7659 | `F` 84, `B` 13, `E` 1, `-` 0 |

## 2. Earnings (per game per side unless noted)

| metric | W | L |
|---|---|---|
| gems captured | 1000 | 786 |
| gems tributed | 1012 | 637 |
| gems taken by kills | 75.0 | 32.2 |
| gems lost at death to champions | 31.6 | 74.9 |
| gems lost at death to camps | 4.7 | 5.8 |
| gold earned (lifetime) | 5910 | 4488 |
| r1-300 gems captured | 242 | 216 |
| r1-300 gems tributed | 167 | 148 |
| r1-300 gems lost at death | 3.7 | 5.1 |
| gems captured per camp-hit round | 1.2 | 1.0 |
| gems captured per hold round | 4.5 | 3.9 |
| gems captured per (camp+hold) round | 1.0 | 0.8 |
| gems tributed per 100 alive rounds | 22.8 | 14.9 |
| mean bag carried per alive round | 20.8 | 16.5 |
| % alive rounds carrying 30+ | 15.9 | 14.5 |
| tributes per 1000 alive rounds | 8.5 | 7.0 |
| mean bag at tribute | 26.7 | 21.2 |
| walk steps per tributed gem | 3.0 | 4.7 |
| bag-walk rounds per tributed gem | 0.9 | 1.4 |
| bag-walk rounds just before a tribute (mean trip) | 6.9 | 7.1 |
| idle-off rounds in stretches of 50+ (% of idle-off) | 9.7 | 15.1 |
| idle-off rounds in 50+ stretches by branch at its start, per game | `G` 10.6, `F` 10.1, `B` 6.5, `R` 0.7 | `G` 22.0, `F` 9.6, `B` 9.1, `R` 0.8 |
| altar locks placed / tribute attempts blocked, per game | 3.79 / 0.00 | 3.98 / 0.00 |
| real recalls per game (completed) | 59.5 (51.3) | 57.4 (48.9) |
| tribute cancels per game (cause) | death 0.02, lock 0.28, manual 0.26, stun 0.32 | death 0.02, lock 0.26, manual 0.19, stun 0.17 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | W | 106 | 240 | 395 | 260 |
| gems captured | L | 96.4 | 210 | 316 | 163 |
| gems tributed | W | 61.7 | 192 | 411 | 347 |
| gems tributed | L | 56.1 | 165 | 271 | 146 |
| alive champion-rounds | W | 656 | 1082 | 1475 | 1231 |
| alive champion-rounds | L | 648 | 1060 | 1421 | 1145 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `R` | `F` | `B` | `S` | `G` | `C` | `E` | `X` | `W` |
|---|---|---|---|---|---|---|---|---|---|---|
| W | 24.4/g, 94.4% done, 24.9% bag, 19.8 from spawn | 16.2/g, 82.6% done, 28.4% bag, 22.7 from spawn | 11.9/g, 74.4% done, 9.0% bag, 24.2 from spawn | 4.6/g, 88.6% done, 100.0% bag, 23.3 from spawn | 1.3/g, 94.3% done, 0.7% bag, 35.8 from spawn | 0.7/g, 68.3% done, 8.6% bag, 24.0 from spawn | 0.5/g, 64.7% done, 64.7% bag, 35.1 from spawn | 0.0/g, 100.0% done, 100.0% bag, 44.3 from spawn | 0.0/g, 0.0% done, 0.0% bag, 10.5 from spawn | 0.0/g, 100.0% done, 100.0% bag, 17.0 from spawn |
| L | 22.7/g, 94.6% done, 25.8% bag, 18.7 from spawn | 17.5/g, 80.1% done, 28.1% bag, 21.0 from spawn | 11.0/g, 72.6% done, 8.7% bag, 23.2 from spawn | 4.5/g, 88.6% done, 100.0% bag, 22.2 from spawn | 0.8/g, 96.5% done, 0.2% bag, 36.2 from spawn | 0.6/g, 71.4% done, 7.7% bag, 22.0 from spawn | 0.3/g, 71.3% done, 61.8% bag, 36.2 from spawn | 0.0/g, 90.0% done, 50.0% bag, 45.3 from spawn | 0.0/g, 0.0% done, 0.0% bag, 9.0 from spawn | - |

Bag size at tribute (% of tributes): W: 0-19 60.1, 20-39 22.3, 40-59 10.8, 60-79 3.4, 80-99 1.1, 100+ 2.3; L: 0-19 64.9, 20-39 20.7, 40-59 10.3, 60-79 2.9, 80-99 0.6, 100+ 0.7

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | r1-300 turns/gem (n) | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 1 | 6 | 18.5 | 131 | 0.09 | - | 12.4 | 83.3 | 16.7 | 0.0 | 1.2 | 4.8 | 0.00 | 66.7 |
| Monolith | 2 | 9 | 35.6 | 60.0 | 0.17 | - | 17.0 | 88.9 | 11.1 | 0.0 | 1.4 | 6.4 | 0.44 | 33.3 |
| Monolith | 3+ | 149 | 86.8 | 83.3 | 0.41 | - | 26.8 | 96.6 | 2.0 | 1.3 | 1.7 | 5.1 | 0.07 | 29.5 |
| Golem | 1 | 648 | 13.4 | 34.6 | 0.32 | 0.08 (2) | 24.9 | 97.1 | 2.6 | 0.3 | 1.0 | 5.9 | 0.04 | 17.1 |
| Golem | 2 | 870 | 23.9 | 41.9 | 0.57 | 0.90 (23) | 34.6 | 97.6 | 1.5 | 0.9 | 1.0 | 5.2 | 0.03 | 9.9 |
| Golem | 3+ | 1409 | 46.8 | 72.6 | 0.95 | 1.53 (403) | 60.6 | 97.8 | 1.7 | 0.5 | 1.2 | 5.8 | 0.07 | 12.7 |
| Elk | 1 | 4777 | 12.4 | 22.0 | 0.59 | 0.82 (269) | 24.9 | 97.5 | 1.7 | 0.8 | 1.0 | 6.4 | 0.03 | 7.5 |
| Elk | 2 | 5758 | 20.7 | 28.8 | 0.94 | 1.38 (1455) | 34.2 | 98.5 | 1.1 | 0.4 | 1.0 | 6.2 | 0.04 | 5.3 |
| Elk | 3+ | 5221 | 28.9 | 29.0 | 1.10 | 1.50 (2532) | 35.2 | 98.3 | 1.4 | 0.3 | 1.0 | 6.3 | 0.08 | 7.1 |
| Wolf | 1 | 8393 | 11.4 | 17.1 | 1.31 | 2.21 (1449) | 22.6 | 97.8 | 1.7 | 0.5 | 1.0 | 6.7 | 0.04 | 5.1 |
| Wolf | 2 | 7212 | 16.5 | 24.1 | 1.55 | 2.66 (2029) | 24.8 | 98.4 | 1.2 | 0.4 | 1.0 | 6.5 | 0.06 | 3.8 |
| Wolf | 3+ | 4204 | 24.4 | 26.3 | 1.54 | 2.12 (2005) | 23.8 | 98.9 | 0.8 | 0.4 | 1.0 | 6.4 | 0.10 | 3.8 |
| GemCl | 1 | 18288 | 3.0 | 3.1 | 0.22 | 0.25 (6082) | 0.0 | 97.1 | 1.8 | 1.1 | 1.0 | 7.8 | 0.05 | 2.3 |
| GemCl | 2 | 3920 | 4.3 | 7.8 | 0.23 | 0.27 (1432) | 0.0 | 98.3 | 1.1 | 0.6 | 1.0 | 6.9 | 0.06 | 2.6 |
| GemCl | 3+ | 858 | 5.7 | 4.9 | 0.21 | 0.25 (324) | 0.0 | 98.0 | 1.2 | 0.8 | 1.1 | 7.0 | 0.06 | 4.0 |
| GoldCl | 1 | 17211 | 2.6 | 3.8 | 0.87 | 1.26 (6329) | 0.0 | 96.6 | 1.5 | 1.9 | 1.0 | 9.6 | 0.03 | 1.9 |
| GoldCl | 2 | 2645 | 3.5 | 19.1 | 1.14 | 1.68 (1162) | 0.0 | 96.6 | 1.1 | 2.3 | 1.0 | 8.5 | 0.04 | 2.0 |
| GoldCl | 3+ | 205 | 4.5 | 19.6 | 0.95 | 6.56 (122) | 0.0 | 99.0 | 1.0 | 0.0 | 1.0 | 9.4 | 0.11 | 2.9 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| W | 73.8 | 60.4 | 0.73 | 20.0 | 97.9 | 1.2 | 1.24 | 1.0 | 7.3 | 0.05 | 0.01 | 0.006 |
| L | 66.7 | 60.2 | 0.81 | 21.3 | 97.1 | 1.9 | 0.85 | 1.0 | 7.6 | 0.05 | 0.01 | 0.007 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| W | 15.77 | 12.13 | 2.34 | 0.12 | 17.23 | 15.67 | 0.95 | 1.35 | 0.22 | 0.04 | 1.62 | 0.88 | 1.13 | 1.07 | 0.27 | 0.04 | 1.94 | 1.03 |
| L | 14.86 | 11.32 | 1.99 | 0.08 | 16.38 | 15.44 | 0.63 | 0.67 | 0.10 | 0.00 | 1.09 | 0.73 | 0.70 | 0.53 | 0.11 | 0.01 | 1.37 | 0.73 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| W | own | 61.3 | 7.2 | 1.5 | 2.1 | 28.0 |
| W | mid | 75.3 | 7.2 | 1.8 | 1.1 | 14.7 |
| W | enemy | 62.7 | 7.4 | 1.7 | 2.0 | 26.1 |
| L | own | 62.7 | 7.4 | 1.7 | 2.0 | 26.1 |
| L | mid | 75.3 | 7.2 | 1.8 | 1.1 | 14.7 |
| L | enemy | 61.3 | 7.2 | 1.5 | 2.1 | 28.0 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| W | own | 67.8 | 7.4 | 1.5 | 2.2 | 21.1 |
| W | mid | 84.1 | 6.0 | 0.9 | 0.9 | 8.1 |
| W | enemy | 69.3 | 7.2 | 1.3 | 2.1 | 20.1 |
| L | own | 69.3 | 7.2 | 1.3 | 2.1 | 20.1 |
| L | mid | 84.1 | 6.0 | 0.9 | 0.9 | 8.1 |
| L | enemy | 67.8 | 7.4 | 1.5 | 2.2 | 21.1 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| W | Wolf | 62.8 | 7.8 | 1.6 | 78.1 | 6.0 | 1.4 | 63.2 | 8.1 | 1.7 |
| L | Wolf | 63.2 | 8.1 | 1.7 | 78.1 | 6.0 | 1.4 | 62.8 | 7.8 | 1.6 |
| W | Elk | 47.4 | 10.4 | 1.5 | 60.3 | 11.0 | 1.7 | 48.2 | 10.7 | 1.6 |
| L | Elk | 48.2 | 10.7 | 1.6 | 60.3 | 11.0 | 1.7 | 47.4 | 10.4 | 1.5 |
| W | Golem | 58.1 | 9.8 | 0.8 | 69.5 | 11.6 | 0.8 | 59.9 | 10.3 | 0.9 |
| L | Golem | 59.9 | 10.3 | 0.9 | 69.5 | 11.6 | 0.8 | 58.1 | 9.8 | 0.8 |
| W | Monolith | 90.7 | 3.2 | 0.1 | 94.7 | 1.7 | 0.1 | 91.6 | 3.4 | 0.1 |
| L | Monolith | 91.6 | 3.4 | 0.1 | 94.7 | 1.7 | 0.1 | 90.7 | 3.2 | 0.1 |
| W | GemCl | 39.1 | 2.7 | 4.0 | 50.1 | 3.5 | 7.7 | 39.7 | 2.7 | 4.1 |
| L | GemCl | 39.7 | 2.7 | 4.1 | 50.1 | 3.5 | 7.7 | 39.1 | 2.7 | 4.0 |
| W | GoldCl | 55.2 | 1.7 | 7.1 | 67.7 | 1.7 | 6.0 | 55.1 | 1.7 | 6.9 |
| L | GoldCl | 55.1 | 1.7 | 6.9 | 67.7 | 1.7 | 6.0 | 55.2 | 1.7 | 7.1 |

Upper bound on gems left asleep per game (each asleep round = 1/(respawn+15) of a farm cycle): W: own 1107, mid 544, enemy 1157; L: own 1157, mid 544, enemy 1107

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| W | 62.9 (764) | 5.1 (141) | 5.6 (95) | 19.9/1.1/1.0 |
| L | 59.3 (686) | 3.1 (56) | 3.2 (44) | 19.3/0.8/0.8 |

## 5. Deaths

| metric | W | L |
|---|---|---|
| deaths/game (to champions + camps) | 2.1 + 0.51 | 4.8 + 0.63 |
| median first-death round (none = length+1) | 480 | 317 |
| % of games this side died first | 31.3 | 53.8 |
| % alone (no ally within 8) | 33.4 | 32.2 |
| % ally within 4 | 40.1 | 44.8 |
| % 2+ enemies within 8 | 61.3 | 63.6 |
| % on own ground | 52.5 | 59.2 |
| % on mid ground | 23.0 | 20.1 |
| % on enemy ground | 24.5 | 20.7 |
| % walking toward spawn (last 4 rounds) | 37.5 | 34.8 |
| % branch R in last 4 rounds | 93.4 | 85.7 |
| % carrying 30+ gems | 10.7 | 11.3 |
| mean enemies within 8 | 2.0 | 2.1 |
| mean gems carried at death | 13.2 | 14.5 |
| r1-300 deaths/game | 0.59 | 0.91 |

Gems lost at death by champion type, per game (% of the side's loss): W: Prism 15.5 (45.8%), Marcella 6.2 (18.4%), Heart of Ruin 4.5 (13.1%), Vendetta 2.9 (8.7%); L: Prism 44.7 (57.0%), Marcella 8.4 (10.8%), Heart of Ruin 8.3 (10.6%), Vendetta 6.9 (8.7%)

Deaths carrying 100+ gems: W 0.07/game holding 53.0% of gems lost; L 0.18/game holding 57.9% of gems lost

Branch at death (last D line): W: `R` 87.4%, `F` 6.1%, `E` 2.2%, `K` 2.1%, `B` 0.7%, `T` 0.5%; L: `R` 79.7%, `E` 8.8%, `F` 7.8%, `B` 1.1%, `K` 1.1%, `P` 0.3%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| W | 0 | 0.6 | 3.4 | 2.8 | 1.8 |
| W | 1 | 1.3 | 1.9 | 2.3 | 2.2 |
| W | 2 | 0.8 | 1.0 | 1.4 | 2.0 |
| W | 3+ | 0.6 | 0.4 | 0.6 | 2.7 |
| L | 0 | 0.9 | 7.1 | 5.7 | 3.7 |
| L | 1 | 1.2 | 4.7 | 5.8 | 4.8 |
| L | 2 | 1.0 | 2.6 | 3.4 | 4.6 |
| L | 3+ | 0.8 | 1.4 | 1.6 | 4.8 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| W | 4.8 | 0.56 | 29.1 | 52.1 | 14.8 | 6.4 | 41.9 |
| L | 2.1 | 0.33 | 29.1 | 47.9 | 6.4 | 14.8 | -41.9 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| W | 18.30 / +0.05 | 2.79 / -0.02 | 0.59 / -0.01 | 2.30 / +0.28 | 2.00 / +0.16 | 0.91 / +0.13 | 0.39 / +0.51 | 0.63 / +0.43 | 1.19 / +0.29 |
| L | 18.30 / -0.05 | 2.30 / -0.28 | 0.39 / -0.51 | 2.79 / +0.02 | 2.00 / -0.16 | 0.63 / -0.43 | 0.59 / +0.01 | 0.91 / -0.13 | 1.19 / -0.29 |
| pooled | 18.30 / +0.00 | 2.54 / -0.14 | 0.49 / -0.21 | 2.54 / +0.14 | 2.00 / +0.00 | 0.77 / -0.10 | 0.49 / +0.21 | 0.77 / +0.10 | 1.19 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| W | 0.49 / +0.21 / 21.4 | 2.22 / +0.09 / 15.3 | 6.63 / +0.06 / 12.9 | 11.84 / +0.08 / 13.9 | 5.79 / +0.11 / 15.9 | 1.70 / +0.18 / 21.2 | 0.41 / +0.16 / 18.4 |
| L | 0.41 / -0.16 / 5.4 | 1.70 / -0.18 / 4.3 | 5.79 / -0.11 / 5.7 | 11.84 / -0.08 / 6.1 | 6.63 / -0.06 / 7.5 | 2.22 / -0.09 / 8.5 | 0.49 / -0.21 / 7.0 |
| pooled | 0.45 / +0.04 / 14.1 | 1.96 / -0.03 / 10.5 | 6.21 / -0.02 / 9.6 | 11.84 / +0.00 / 10.0 | 6.21 / +0.02 / 11.4 | 1.96 / +0.03 / 14.0 | 0.45 / -0.04 / 12.2 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 582 | 94 | 57.4 | 54.3 (n=372) | 64.2 (n=106) | 100.0 (n=10) |
| tributed r400 | 574 | 38 | 63.6 | 55.8 (n=283) | 70.6 (n=204) | 79.6 (n=49) |
| tributed r600 | 517 | 23 | 70.6 | 59.2 (n=196) | 75.0 (n=188) | 83.6 (n=110) |
| tributed+carried r200 | 582 | 79 | 64.0 | 61.3 (n=385) | 71.6 (n=102) | 81.2 (n=16) |
| tributed+carried r400 | 574 | 37 | 70.2 | 60.2 (n=289) | 78.8 (n=189) | 91.5 (n=59) |
| tributed+carried r600 | 517 | 16 | 76.6 | 62.7 (n=209) | 82.3 (n=164) | 92.2 (n=128) |

| predictor | win % |
|---|---|
| team that did not die first wins | 63.2 (n=495) |
| more kills wins | 85.0 (n=413) |
| more r1-300 kills wins | 65.6 (n=209) |
| more gems captured wins | 89.0 (n=572) |
| more r1-300 gems captured wins | 67.0 (n=539) |
| fewer gems lost at death wins | 76.1 (n=355) |
| more mid-group captures wins | 86.5 (n=200) |

Games where neither side tributes 200: 2 (gen-shared-gems-600201600, the-pack).

Game length: median 972, quartiles 739-1275, min 281, max 2000; 7.2% reach round 2000; 92.8% end on 1000 gems.

## Examples

**bagdeath** (223 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/127-02treasure-box-12.repl26a` (cc4217505b90a637) r1171 team B (W): Prism died with 1384 gems (champ, allies<=8 2, enemies<=8 2, branch T)
- `replays/batch-20261030-094349-ab-m3-mirror-gen/227-gen-fortress-600102222-12.repl26a` (ceb673eafca52d10) r1147 team B (L): Prism died with 1367 gems (champ, allies<=8 0, enemies<=8 1, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-gen/473-mut-fields-600101809-12.repl26a` (e6b7b2c1d37dc6d2) r838 team A (L): Prism died with 833 gems (champ, allies<=8 0, enemies<=8 2, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/091-01shortcut-12.repl26a` (b714855345688d11) r1223 team A (L): Prism died with 820 gems (champ, allies<=8 1, enemies<=8 1, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-gen/149-gen-continent-600102824-12.repl26a` (28a1127dbba04f27) r771 team A (L): Prism died with 809 gems (champ, allies<=8 1, enemies<=8 1, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r606 team A (L): Vendetta died with 596 gems (champ, allies<=8 1, enemies<=8 5, branch E)

**stolen** (1213 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r481 team B (W): Monolith (400 gems, mid) cleared r459 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/069-00vault-12.repl26a` (fcc8e1c0dd6d4d9e) r440 team B (L): GemCl (343 gems, enemy) cleared r31 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-gen/063-gen-atoll-600101924-12.repl26a` (29cf533eb2eff584) r285 team B (L): Elk (256 gems, enemy) cleared r203 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/009-00contest-12.repl26a` (3674b10bf9072918) r1085 team A (W): Monolith (200 gems, own) cleared r1079 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-gen/337-gen-monolith-only-600101503-12.repl26a` (aa522bfefded88e6) r716 team B (W): Monolith (200 gems, enemy) cleared r704 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-gen/459-mut-contest-600101800-12.repl26a` (771cb0794132aaa9) r1175 team B (L): Monolith (200 gems, enemy) cleared r1163 stolen

**idle-off30** (468 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-fresh-gen-s1/391-gen-shared-gems-600201600-12.repl26a` (2794427da446dc6f) r27 team A (L): Willow#2 idle off spawn 1974 rounds at (24, 18) branch G
- `replays/batch-20261030-094349-ab-m3-mirror-gen/061-gen-atoll-600101919-12.repl26a` (9e90fafbafcf0480) r622 team B (L): Heart of Ruin#5 idle off spawn 1379 rounds at (35, 5) branch G
- `replays/batch-20261030-094349-ab-m3-mirror-fresh-gen-s1/253-gen-gem-centre-600205105-12.repl26a` (4314c59f9fcb58e2) r731 team B (L): Heart of Ruin#5 idle off spawn 1270 rounds at (45, 29) branch B
- `replays/batch-20261030-094349-ab-m3-mirror-gen/393-gen-shared-gems-600101602-12.repl26a` (0cf0aad1364b14ef) r922 team B (L): Prism#4 idle off spawn 1016 rounds at (28, 32) branch G
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1336 team A (W): Heart of Ruin#2 idle off spawn 665 rounds at (11, 30) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-fresh-gen-s1/509-mut-the-pack-600201800-12.repl26a` (b0d146090f05e921) r472 team B (L): Ryth#6 idle off spawn 546 rounds at (26, 18) branch B

