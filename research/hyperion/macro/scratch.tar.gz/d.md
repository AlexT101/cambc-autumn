42699 forced decisions; variant full; lam {"base":1,"basep":10,"ea":3000,"et":300,"ek":100,"ep":1000,"ev":1,"evt":30,"es":100,"mz":3000}; cv {}

Held-out checks (models fitted without each fold, scored on it): calibration slope b of the predicted arm
gains (1: right, below 1: too optimistic); per tau (logit; 0.04 ~ a win point), following the model where its gain
clears tau against the base, by self-normalised IPW, win points +- 1 se (rows of one game share it: se a bit small).
  k0 (2259 rows): b 0.18; base 49.7%; tau 0 3.6 +- 9.3, tau 0.02 3.5 +- 9.1, tau 0.04 4.7 +- 9.2, tau 0.08 2.7 +- 9.2, tau 0.12 3.2 +- 8.9
  k1 (2971 rows): b -0.17; base 45.7%; tau 0 -0.4 +- 5.8, tau 0.02 1.0 +- 5.6, tau 0.04 0.7 +- 5.6, tau 0.08 1.1 +- 5.4, tau 0.12 -3.1 +- 5.3
  k2 (2656 rows): b 0.54; base 57.2%; tau 0 0.0 +- 6.0, tau 0.02 0.4 +- 5.9, tau 0.04 0.9 +- 5.8, tau 0.08 2.0 +- 5.6, tau 0.12 2.1 +- 5.6
  k3-5 (5773 rows): b -0.28; base 52.3%; tau 0 2.8 +- 4.5, tau 0.02 3.2 +- 4.4, tau 0.04 3.8 +- 4.4, tau 0.08 2.0 +- 4.3, tau 0.12 3.0 +- 4.2
  k6-11 (5477 rows): b 0.26; base 60.5%; tau 0 0.7 +- 3.9, tau 0.02 0.4 +- 3.9, tau 0.04 0.2 +- 3.9, tau 0.08 -0.4 +- 3.9, tau 0.12 -0.0 +- 3.9
  k0-11 (19136 rows): b 0.13; base 54.1%; tau 0 1.2 +- 2.4, tau 0.02 1.6 +- 2.4, tau 0.04 2.0 +- 2.4, tau 0.08 1.2 +- 2.3, tau 0.12 1.0 +- 2.3

Doubly robust policy selection (42699 decisions, forced and not; recomputed proposal against the logged q: mean relative error 0.02%).
Per class and z: cross-fitted gain per decision in win points +- se, and the share of decisions whose cell leaves the base.
  class (type, k, picks) z 0: -2.04 +- 2.53 points per decision; moves 93%; gain within moved cells by k: 0:-7.0 1:-9.3 2:-2.3 3:3.0 4:9.1 5:-1.2 6:-0.9 7:-0.6 8:7.5 9:1.3 10:-13.2 11:-12.6
  class (type, k, picks) z 1: 0.72 +- 2.21 points per decision; moves 89%; gain within moved cells by k: 0:-0.3 1:-16.6 2:-2.4 3:6.3 4:16.9 5:18.6 6:-8.6 7:7.1 8:2.5 9:4.6 10:-2.6 11:-5.9
  class (type, k, picks) z 2: -0.07 +- 1.09 points per decision; moves 16%; gain within moved cells by k: 0:-0.2 1:-12.4 2:-6.8 3:-6.4 4:-0.8 5:30.3 6:-0.4 7:-1.2 8:17.0 9:-9.1 10:8.4 11:-41.7
  class (type, k, picks) z 3: -0.38 +- 0.48 points per decision; moves 1%; gain within moved cells by k: 0:-54.4 1:-4.9 2:42.1 3:- 4:- 5:6.7 6:- 7:-7.3 8:- 9:- 10:- 11:-
  class (type, k, picks, current family) z 0: -0.65 +- 1.94 points per decision; moves 55%; gain within moved cells by k: 0:-0.9 1:3.9 2:-2.6 3:-5.6 4:-2.3 5:-4.3 6:3.5 7:8.1 8:-3.8 9:-4.9 10:-4.8 11:-14.6
  class (type, k, picks, current family) z 1: -0.55 +- 1.49 points per decision; moves 49%; gain within moved cells by k: 0:-5.9 1:2.6 2:2.7 3:-2.6 4:-2.4 5:6.9 6:2.2 7:-20.3 8:15.0 9:-5.3 10:-1.0 11:1.4
  class (type, k, picks, current family) z 2: 0.79 +- 1.04 points per decision; moves 6%; gain within moved cells by k: 0:36.5 1:11.1 2:2.6 3:-11.0 4:1.6 5:8.4 6:34.0 7:-3.1 8:-20.4 9:5.9 10:-30.3 11:-19.1
  class (type, k, picks, current family) z 3: 1.12 +- 0.71 points per decision; moves 0%; gain within moved cells by k: 0:414.6 1:-32.1 2:- 3:- 4:- 5:6.1 6:- 7:- 8:- 9:- 10:- 11:-

Per pick count, type and ordinal, on held-out folds: rows, share where the model would leave the base, mean predicted gain
(win points, x25 logit), the most common best arms, and the single-decision IPW estimate of following the model there
(mean y 1[chosen = best] / q over forced rows, against the cell's mean y; noisy).

3 picks

4 picks

5 picks
  vesper_vale    k1  n    247  change  55%  gain  1.25  monster-strength 26%, jungle-strength 16%, treasure-strength 15%  | ipw -4.3
  vesper_vale    k2  n    213  change  89%  gain  5.02  capture-strength 22%, jungle-strength 22%, treasure-strength 16%  | ipw 9.4
  marcella       k1  n    270  change  97%  gain  4.24  monster-strength 23%, monster-health 14%, capture-health 8%  | ipw -20.6
  marcella       k2  n    223  change  48%  gain  1.69  capture-focus 15%, capture-strength 13%, treasure-strength 10%  | ipw 6.2
  marcella       k3  n    209  change  95%  gain  4.12  tribute-health 22%, tribute-strength 18%, tribute-focus 11%  | ipw -13.0
  heart_of_ruin  k1  n    230  change  81%  gain  2.53  monster-strength 19%, monster-health 13%, durability-strength 9%  | ipw 4.0
