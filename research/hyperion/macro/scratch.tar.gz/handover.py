import gzip, json, os, sys, statistics as st
batch, root = os.path.abspath(sys.argv[1]), sys.argv[2]
index = json.load(open(os.path.join(root, 'index.json')))
out = {'ours': [], 'base': []}
for g in index['games']:
    src = g['source'] if os.path.isabs(g['source']) else os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', g['source']))
    if not src.startswith(batch): continue
    d = os.path.join(root, g['dir'])
    meta = json.load(open(os.path.join(d, 'meta.json')))
    ev = [json.loads(l) for l in gzip.open(os.path.join(d, 'events.jsonl.gz'), 'rt')]
    our = 0 if src.endswith('-12.repl26a') else 1
    for who, team in (('ours', our), ('base', 1 - our)):
        p = [c['id'] for c in meta['champions'] if c['team'] == team and 'rism' in str(c['type']) + str(c['name'])]
        if not p: continue
        pid = p[0]
        cleared_by = {}
        n = shared = 0
        for e in ev:
            if e['k'] == 'group_clear': cleared_by[e['g']] = e.get('by')
            if e['k'] == 'capture' and e['team'] == team:
                ids = [s[0] for s in e['shares']]
                if pid in ids and cleared_by.get(e['g']) not in (None, pid):
                    if len(ids) == 1: n += 1
                    else: shared += 1
        out[who].append((n, shared))
for who, v in out.items():
    print(who, f'games {len(v)}: Prism alone on captures an ally cleared {st.mean(x[0] for x in v):.1f}/game, shared with an ally {st.mean(x[1] for x in v):.2f}/game')
