import gzip, json, os, glob, zipfile
A = '/tmp/claude-1000/m4-rta/analysis'
idx = json.load(open(A + '/index.json'))
def absp(s): return s if os.path.isabs(s) else os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', s))
src = {absp(g['source']): g['dir'] for g in idx['games']}
def load(path):
    d = os.path.join(A, src[path])
    return [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')], json.load(open(d + '/meta.json'))
pairs = []
for path in src:
    if '/base/' in path or '/more-base/' in path: continue
    team = 0 if os.path.basename(path).startswith('m4-rta-vs') else 1
    out = zipfile.ZipFile(path).read('team-%s.stdout' % 'ab'[team]).decode('latin1')
    lines = [l.split() for l in out.splitlines() if l.startswith('RTA ')]
    if not lines: continue
    g = os.path.basename(os.path.dirname(path))
    bdir = '/tmp/claude-1000/m4-rta/' + ('more-base/' if '/more/' in path else 'base/') + g
    bpath = glob.glob(bdir + '/*.repl26a')[0]
    ev, meta = load(path); bev, _ = load(bpath)
    team_of = {c['id']: c['team'] for c in meta['champions']}
    r, h, a = int(lines[0][1]), int(lines[0][2]), int(lines[0][3])
    W = range(r, r + 11)
    def summ(ev):
        died = any(e['k'] == 'death' and e['v'] == h and e['r'] in W for e in ev)
        ours = sum(e['k'] == 'death' and team_of[e['v']] == team and e['r'] in W for e in ev)
        theirs = sum(e['k'] == 'death' and team_of[e['v']] != team and e['r'] in W for e in ev)
        return died, ours, theirs
    pairs.append((g, r, summ(ev), summ(bev)))
print('game round  rta(me died, our deaths, enemy deaths)  base(...)')
for p in sorted(pairs): print(*p)
print('me died: rta', sum(p[2][0] for p in pairs), 'base', sum(p[3][0] for p in pairs))
print('our deaths: rta', sum(p[2][1] for p in pairs), 'base', sum(p[3][1] for p in pairs), '| enemy deaths: rta', sum(p[2][2] for p in pairs), 'base', sum(p[3][2] for p in pairs))
