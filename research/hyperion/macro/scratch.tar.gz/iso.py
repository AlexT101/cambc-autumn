import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def cheb(a,b): return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def one(d):
    R=json.load(gzip.open(d/'rounds.json.gz'))
    ev=[json.loads(l) for l in gzip.open(d/'events.jsonl.gz','rt')]
    deaths=collections.defaultdict(list)
    for e in ev:
        if e['k']=='death' and 'camp' not in e and not e.get('linked'): deaths[e['v']].append(e['r'])
    ch=R['champions']; n=len(R['round'])
    out=collections.Counter()
    for i in range(0,n,5):
        r=R['round'][i]
        for E in ch:
            if not E['alive'][i] or E['x'][i] is None: continue
            p=(E['x'][i],E['y'][i])
            mates=sum(1 for c in ch if c['team']==E['team'] and c['id']!=E['id'] and c['alive'][i] and c['x'][i] is not None and cheb(p,(c['x'][i],c['y'][i]))<=6)
            foes=[c for c in ch if c['team']!=E['team'] and c['alive'][i] and c['x'][i] is not None and cheb(p,(c['x'][i],c['y'][i]))<=8]
            seen=any(E['id'] in (c['sees'][i] or []) for c in ch if c['team']!=E['team'])
            if not foes or not seen: continue
            k=(min(mates,2),min(len(foes),3))
            died=any(r<dr<=r+15 for dr in deaths[E['id']])
            out[k]+=1; out[('d',)+k]+=died
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    T=collections.Counter()
    for r in res: T.update(r)
    n=len(res)
    print('samples every 5 rounds: (enemy mates within 6, our champs within 8) -> samples/game, P(enemy dies within 15)')
    for k in sorted(x for x in T if x[0]!='d'): print(k, round(T[k]/n,1), '%.3f'%(T[('d',)+k]/T[k]))
