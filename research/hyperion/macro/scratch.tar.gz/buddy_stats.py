import zipfile, glob, sys, statistics, collections
for f in sorted(glob.glob(sys.argv[1] + '/**/*.repl26a', recursive=True)):
    d = zipfile.ZipFile(f).read('team-a.stdout').decode(errors='replace').splitlines()
    errs = sum('act error' in l for l in d)
    b = []
    for l in d:
        if not l.startswith('BUDDY '): continue
        p = l.split()
        kv = dict(x.split('=') for x in p[3:])
        b.append((int(p[1]), int(p[2]), int(kv['g']), int(kv['d']), float(kv['e']), float(kv['S'])))
    low = [x for x in b if x[5] < 1]
    ds = [x[3] for x in b if x[3] < 65535]
    rb = sum(l.startswith('RETREAT-BUDDY') for l in d)
    print(f.split('/')[-2], f'decisions={len(b)} S<1={len(low)} ({100*len(low)/max(1,len(b)):.1f}%) medS<1={statistics.median([x[5] for x in low]) if low else 1:.2f} minS={min([x[5] for x in b] or [1]):.2f}',
          f'd median={statistics.median(ds) if ds else 0} d>7={sum(x>7 for x in ds)} e>=0.5={sum(x[4]>=0.5 for x in b)} retreat-buddy={rb} act-errors={errs}')
    if low:
        print('   sample S<1:', [f'r{x[0]} h{x[1]} g{x[2]} d{x[3]} e{x[4]:.2f} S{x[5]:.2f}' for x in low[::max(1,len(low)//6)][:6]])
