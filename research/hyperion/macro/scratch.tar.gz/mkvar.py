import sys, shutil, pathlib
V = pathlib.Path("/home/ubuntu/cambc-wt/macro-3/bots/variants")
def make(tag, edits, base="m3-b1"):
    d = V / f"lab-{tag}"
    if d.exists(): shutil.rmtree(d)
    d.mkdir(parents=True)
    shutil.copytree(V / base / "src", d / "src")
    for rel, old, new in edits:
        p = d / "src" / rel
        s = p.read_text()
        n = s.count(old)
        assert n == 1, (tag, rel, old[:60], n)
        p.write_text(s.replace(old, new))
    print("made", d)
