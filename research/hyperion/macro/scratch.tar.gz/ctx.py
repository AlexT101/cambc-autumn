import sys,re,zipfile,collections
sys.path.insert(0,'/home/ubuntu/cambc-autumn/tools/replay')
from analysis import Game
gf=sys.argv[1]; nd=int(sys.argv[2]) if len(sys.argv)>2 else 3; win=int(sys.argv[3]) if len(sys.argv)>3 else 10
hdr=open(gf).read().split('\n')[:3]
src=re.search(r'source (\S+)',hdr[1]).group(1); an=re.search(r'analysis (\S+)',hdr[1]).group(1)
g=Game(an)
br={}
z=zipfile.ZipFile('/home/ubuntu/cambc-autumn/'+src)
for t in ('team-a.stdout','team-b.stdout'):
    for l in z.read(t).decode(errors='replace').split('\n'):
        p=l.split()
        if len(p)>=4 and p[0]=='D':
            br[(int(p[1]),int(p[2]))]=p[3]+(p[4] if len(p)>4 else '')
short={'Vesper Vale':'Ves','Heart of Ruin':'HoR'}
nm=lambda c: ('a' if g.team_of[c]==0 else 'b')+short.get(g.name_of[c],g.name_of[c][:4])+str(c)
# deaths: alive transition
deaths=[]
for c in g.team_of:
    a=g.ch(c)['alive']
    for i in range(1,len(a)):
        if a[i-1] and not a[i]: deaths.append((i+1,c))
deaths.sort()
# killer: last champ damage on victim at that round
dmg=g.champ_damage
print(hdr[0]); print(hdr[2] if len(hdr)>2 else '')
seen=set()
k=0
for r,c in deaths:
    if g.name_of[c] in ('Issac','Cassi') and (r,g.team_of[c]) in seen: continue
    seen.add((r,g.team_of[c]))
    hits=[d for d in dmg if d[3]==c and r-3<=d[1]<=r]
    killer=nm(hits[-1][2]) if hits else 'camp?'
    k+=1
    if k>nd: break
    print(f'\n=== DEATH r{r} {nm(c)} killer {killer} attackers {sorted(set(nm(d[2]) for d in hits))}')
    ids=sorted(g.team_of)
    for rr in range(max(1,r-win),r+1):
        i=rr-1
        vp=g.pos(c,i-1) or g.pos(c,i)
        row=[f'r{rr:<4}']
        for cc in ids:
            ch=g.ch(cc)
            if i>=len(ch['x']) or not ch['alive'][i]: row.append(f'{nm(cc)}:dead'); continue
            p=(ch['x'][i],ch['y'][i]); d=max(abs(p[0]-vp[0]),abs(p[1]-vp[1])) if vp else -1
            hp=int(100*ch['hp'][i]/ch['maxHp'][i])
            row.append(f"{nm(cc)}:{br.get((rr,cc),'-')} ({p[0]},{p[1]})d{d} {hp}% g{ch['gems'][i]}")
        print(' | '.join(row))
