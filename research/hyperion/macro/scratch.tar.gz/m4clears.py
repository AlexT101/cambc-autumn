# Per run: groups cleared mostly by team A, strong vs other striking vs harmless; A's camp damage taken.
import json, gzip, glob, os, collections, sys
US = int(os.environ.get('US', '0'))
for root in sys.argv[1:]:
    tot = collections.Counter(); n = 0
    for d in sorted(glob.glob(root + '/ana/*/meta.json')):
        gd = os.path.dirname(d); meta = json.load(open(d)); n += 1
        mp = json.load(open(os.path.join(gd, meta['mapFile'])))
        camp_g = {c['id']: c['group'] for c in mp['camps']}
        kind = {}
        for g in mp['groups']:
            t = set(g['types'])
            kind[g['id']] = 'strong' if t & {'Elk', 'Golem', 'Monolith'} else 'wolf' if 'Wolf' in t else 'harmless'
        team = {c['id']: c['team'] for c in meta['champions']}
        dealt = collections.defaultdict(lambda: [0.0, 0.0])
        for l in gzip.open(gd + '/events.jsonl.gz', 'rt'):
            e = json.loads(l); k = e['k']
            if k in ('attack', 'cast') and 'cdmg' in e:
                for camp, dmg in e['cdmg']:
                    G = camp_g.get(camp)
                    if G is not None: dealt[G][team[e['a']]] += dmg
            elif k == 'group_clear':
                G = e['g']; a, b = dealt[G]
                us, them = (a, b) if US == 0 else (b, a)
                tot[('us' if us > them else 'them') + ' clears ' + kind[G]] += 1
                dealt[G] = [0.0, 0.0]
            elif k == 'camp_attack' and team.get(e['tgt']) == US:
                tot['us taken from ' + kind[e['g']]] += e['dmg']
    print(root, {k: round(v / n, 1) for k, v in sorted(tot.items())})
