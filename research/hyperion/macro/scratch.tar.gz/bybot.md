# Turn budget: 140 games from replays/batch-20261030-094349-ab-m3-mirror-ladder

Trace: 0 of 280 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 0.0% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all astraeus | all astraeus-ef8f0b8 | r1-150 astraeus | r1-150 astraeus-ef8f0b8 | r151-400 astraeus | r151-400 astraeus-ef8f0b8 | r401-800 astraeus | r401-800 astraeus-ef8f0b8 | r801+ astraeus | r801+ astraeus-ef8f0b8 | r1-300 astraeus | r1-300 astraeus-ef8f0b8 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 6.5 | 6.5 | 2.5 | 2.5 | 4.8 | 4.8 | 7.5 | 7.5 | 9.3 | 9.3 | 3.3 | 3.3 |
| fight | 4.8 | 4.8 | 4.6 | 4.6 | 4.4 | 4.4 | 4.6 | 4.6 | 5.8 | 5.8 | 4.5 | 4.5 |
| tribute | 2.5 | 2.5 | 1.2 | 1.2 | 2.0 | 2.0 | 3.0 | 3.0 | 3.0 | 3.0 | 1.5 | 1.5 |
| recall | 3.6 | 3.6 | 3.4 | 3.4 | 4.0 | 4.0 | 3.8 | 3.8 | 2.9 | 2.9 | 3.8 | 3.8 |
| hold+recall | 2.5 | 2.5 | 2.7 | 2.7 | 3.2 | 3.2 | 2.6 | 2.6 | 1.5 | 1.5 | 3.0 | 3.0 |
| teleport | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| camp | 15.8 | 15.8 | 23.7 | 23.7 | 18.2 | 18.2 | 15.1 | 15.1 | 9.3 | 9.3 | 21.3 | 21.3 |
| hold | 6.0 | 6.0 | 5.3 | 5.3 | 6.3 | 6.3 | 5.5 | 5.5 | 6.9 | 6.9 | 5.7 | 5.7 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 14.3 | 14.3 | 10.1 | 10.1 | 15.4 | 15.4 | 16.2 | 16.2 | 13.0 | 13.0 | 12.6 | 12.6 |
| bag->camp | 4.4 | 4.4 | 3.6 | 3.6 | 5.4 | 5.4 | 4.8 | 4.8 | 3.3 | 3.3 | 4.5 | 4.5 |
| bag-other | 3.1 | 3.1 | 1.6 | 1.6 | 3.1 | 3.1 | 3.5 | 3.5 | 3.3 | 3.3 | 2.2 | 2.2 |
| empty->camp | 22.1 | 22.1 | 30.2 | 30.2 | 21.4 | 21.4 | 20.1 | 20.1 | 20.5 | 20.5 | 26.2 | 26.2 |
| empty->spawn | 3.3 | 3.3 | 3.0 | 3.0 | 3.0 | 3.0 | 3.0 | 3.0 | 4.3 | 4.3 | 3.0 | 3.0 |
| empty-other | 5.9 | 5.9 | 5.2 | 5.2 | 5.0 | 5.0 | 5.4 | 5.4 | 8.0 | 8.0 | 5.2 | 5.2 |
| idle-off | 4.8 | 4.8 | 2.8 | 2.8 | 3.7 | 3.7 | 4.5 | 4.5 | 7.5 | 7.5 | 3.2 | 3.2 |
| idle-spawn | 0.5 | 0.5 | 0.0 | 0.0 | 0.0 | 0.0 | 0.2 | 0.2 | 1.5 | 1.5 | 0.0 | 0.0 |

By attack type (all rounds):

| class | melee astraeus | melee astraeus-ef8f0b8 | ranged astraeus | ranged astraeus-ef8f0b8 |
|---|---|---|---|---|
| dead | 6.8 | 6.8 | 6.1 | 6.1 |
| fight | 5.9 | 5.9 | 3.3 | 3.3 |
| tribute | 2.8 | 2.8 | 1.9 | 1.9 |
| recall | 3.8 | 3.8 | 3.2 | 3.2 |
| hold+recall | 2.9 | 2.9 | 1.9 | 1.9 |
| teleport | 0.0 | 0.0 | 0.0 | 0.0 |
| camp | 14.6 | 14.6 | 17.6 | 17.6 |
| hold | 5.0 | 5.0 | 7.6 | 7.6 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 13.9 | 13.9 | 14.8 | 14.8 |
| bag->camp | 3.2 | 3.2 | 6.2 | 6.2 |
| bag-other | 2.9 | 2.9 | 3.4 | 3.4 |
| empty->camp | 23.3 | 23.3 | 20.1 | 20.1 |
| empty->spawn | 3.5 | 3.5 | 3.0 | 3.0 |
| empty-other | 6.7 | 6.7 | 4.7 | 4.7 |
| idle-off | 4.4 | 4.4 | 5.3 | 5.3 |
| idle-spawn | 0.2 | 0.2 | 0.8 | 0.8 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | astraeus | 34692 | 7.1 | 2.3 | 17.6 | 7.9 | 1.5 | 2.5 | 0.0 | 0.0 | 5.6 | 52.6 |
| Cassi | astraeus-ef8f0b8 | 34692 | 7.1 | 2.3 | 17.6 | 7.9 | 1.5 | 2.5 | 0.0 | 0.0 | 5.6 | 52.6 |
| Heart of Ruin | astraeus | 121168 | 7.8 | 8.1 | 16.8 | 3.4 | 2.4 | 3.4 | 0.0 | 0.0 | 5.6 | 49.6 |
| Heart of Ruin | astraeus-ef8f0b8 | 121168 | 7.8 | 8.1 | 16.8 | 3.4 | 2.4 | 3.4 | 0.0 | 0.0 | 5.6 | 49.6 |
| Issac | astraeus | 34692 | 7.1 | 2.2 | 18.1 | 4.0 | 2.5 | 3.3 | 0.0 | 0.1 | 3.9 | 55.6 |
| Issac | astraeus-ef8f0b8 | 34692 | 7.1 | 2.2 | 18.1 | 4.0 | 2.5 | 3.3 | 0.0 | 0.1 | 3.9 | 55.6 |
| Marcella | astraeus | 114240 | 6.4 | 5.5 | 12.1 | 7.3 | 2.8 | 4.1 | 0.0 | 0.5 | 4.9 | 53.9 |
| Marcella | astraeus-ef8f0b8 | 114240 | 6.4 | 5.5 | 12.1 | 7.3 | 2.8 | 4.1 | 0.0 | 0.5 | 4.9 | 53.9 |
| Prism | astraeus | 94658 | 4.3 | 3.5 | 17.4 | 10.8 | 2.6 | 3.1 | 0.0 | 1.7 | 4.9 | 50.1 |
| Prism | astraeus-ef8f0b8 | 94658 | 4.3 | 3.5 | 17.4 | 10.8 | 2.6 | 3.1 | 0.0 | 1.7 | 4.9 | 50.1 |
| Ren | astraeus | 5672 | 4.3 | 7.5 | 12.5 | 1.3 | 2.2 | 3.5 | 0.0 | 1.6 | 2.3 | 62.4 |
| Ren | astraeus-ef8f0b8 | 5672 | 4.3 | 7.5 | 12.5 | 1.3 | 2.2 | 3.5 | 0.0 | 1.6 | 2.3 | 62.4 |
| Ryth | astraeus | 31298 | 8.1 | 10.5 | 9.8 | 8.5 | 3.9 | 3.8 | 0.0 | 0.3 | 3.1 | 49.5 |
| Ryth | astraeus-ef8f0b8 | 31298 | 8.1 | 10.5 | 9.8 | 8.5 | 3.9 | 3.8 | 0.0 | 0.3 | 3.1 | 49.5 |
| Tavi | astraeus | 5892 | 18.3 | 4.9 | 14.8 | 3.4 | 1.9 | 2.4 | 0.0 | 4.2 | 5.7 | 43.7 |
| Tavi | astraeus-ef8f0b8 | 5892 | 18.3 | 4.9 | 14.8 | 3.4 | 1.9 | 2.4 | 0.0 | 4.2 | 5.7 | 43.7 |
| Varg | astraeus | 12804 | 1.3 | 1.1 | 18.3 | 2.0 | 2.7 | 2.8 | 0.0 | 0.0 | 2.6 | 66.2 |
| Varg | astraeus-ef8f0b8 | 12804 | 1.3 | 1.1 | 18.3 | 2.0 | 2.7 | 2.8 | 0.0 | 0.0 | 2.6 | 66.2 |
| Vendetta | astraeus | 73446 | 6.4 | 3.2 | 14.8 | 3.6 | 3.3 | 4.5 | 0.0 | 0.1 | 3.2 | 57.6 |
| Vendetta | astraeus-ef8f0b8 | 73446 | 6.4 | 3.2 | 14.8 | 3.6 | 3.3 | 4.5 | 0.0 | 0.1 | 3.2 | 57.6 |
| Vesper Vale | astraeus | 49028 | 5.9 | 5.8 | 17.1 | 5.2 | 2.4 | 3.7 | 0.0 | 0.0 | 3.8 | 53.5 |
| Vesper Vale | astraeus-ef8f0b8 | 49028 | 5.9 | 5.8 | 17.1 | 5.2 | 2.4 | 3.7 | 0.0 | 0.0 | 3.8 | 53.5 |
| Willow | astraeus | 74074 | 7.1 | 1.7 | 18.3 | 5.4 | 1.0 | 3.3 | 0.0 | 0.3 | 6.7 | 54.7 |
| Willow | astraeus-ef8f0b8 | 74074 | 7.1 | 1.7 | 18.3 | 5.4 | 1.0 | 3.3 | 0.0 | 0.3 | 6.7 | 54.7 |

Bot branch (D lines), % of champion-rounds:

| branch | all astraeus | all astraeus-ef8f0b8 | r1-300 astraeus | r1-300 astraeus-ef8f0b8 |
|---|---|---|---|---|
| `-` | 6.6 | 6.6 | 3.3 | 3.3 |
| `?` | 0.0 | 0.0 | 0.0 | 0.0 |
| `B` | 18.3 | 18.3 | 16.9 | 16.9 |
| `C` | 2.8 | 2.8 | 2.3 | 2.3 |
| `E` | 0.3 | 0.3 | 0.0 | 0.0 |
| `F` | 49.5 | 49.5 | 57.9 | 57.9 |
| `G` | 2.3 | 2.3 | 0.2 | 0.2 |
| `H` | 0.8 | 0.8 | 0.9 | 0.9 |
| `K` | 1.3 | 1.3 | 1.5 | 1.5 |
| `P` | 5.7 | 5.7 | 5.6 | 5.6 |
| `Q` | 1.9 | 1.9 | 2.3 | 2.3 |
| `R` | 7.6 | 7.6 | 6.7 | 6.7 |
| `S` | 0.0 | 0.0 | 0.1 | 0.1 |
| `T` | 1.5 | 1.5 | 0.7 | 0.7 |
| `W` | 0.0 | 0.0 | 0.0 | 0.0 |
| `X` | 0.3 | 0.3 | 0.3 | 0.3 |
| `h` | 0.4 | 0.4 | 0.7 | 0.7 |
| `k` | 0.7 | 0.7 | 0.6 | 0.6 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 85526 | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `?` | 558 | 4 | 1 | 28 |  |  |  |  | 4 |  |  |  |  |  |  |  | 61 | 1 |
| `B` | 238568 |  | 3 | 3 |  |  |  | 11 |  |  | 58 | 11 | 6 |  |  |  | 5 |  |
| `C` | 36488 |  | 19 |  |  |  |  |  |  |  | 14 | 5 | 13 | 18 | 6 | 24 |  |  |
| `E` | 3454 |  | 30 |  |  |  |  |  |  |  | 5 | 1 | 2 | 7 | 3 | 51 |  |  |
| `F` | 645244 |  | 3 |  |  |  |  | 27 | 1 |  | 5 | 4 |  | 39 | 2 | 8 | 7 |  |
| `G` | 29492 |  | 7 |  |  |  |  | 18 |  |  | 6 |  |  | 36 | 2 | 13 | 13 |  |
| `H` | 10146 |  | 2 |  | 98 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 16848 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 74070 |  | 2 |  |  | 8 |  | 2 | 89 |  |  |  |  |  |  |  |  |  |
| `Q` | 24872 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 99420 |  | 21 |  | 5 |  |  |  |  |  | 6 | 5 | 15 | 15 | 26 | 7 |  |  |
| `S` | 638 |  | 5 | 42 | 5 |  |  |  |  |  | 6 | 4 | 8 | 10 | 19 |  |  |  |
| `T` | 19500 |  | 2 | 98 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `W` | 118 |  | 24 |  |  |  |  |  |  |  | 2 |  |  |  |  |  | 75 |  |
| `X` | 3648 |  | 3 |  |  |  |  |  | 67 |  | 1 | 1 | 2 | 13 |  | 11 |  |  |
| `h` | 5148 |  | 1 |  |  |  |  | 8 |  |  |  |  |  | 23 | 11 | 10 | 45 |  |
| `k` | 9456 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 134 |  | 25 |  | 1 |  |  | 6 |  |  | 15 | 7 | 7 | 1 | 10 |  | 25 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 85212 | `-` 100, `?` 0, `B` 0, `F` 0 |
| fight | 62968 | `F` 35, `R` 33, `B` 13, `C` 11 |
| tribute | 32168 | `T` 60, `B` 20, `F` 17, `S` 1 |
| recall | 46366 | `K` 36, `H` 21, `k` 20, `R` 11 |
| hold+recall | 32524 | `Q` 76, `P` 18, `F` 5, `B` 1 |
| teleport | 288 | `F` 73, `B` 23, `P` 2, `C` 1 |
| camp | 205466 | `F` 84, `B` 13, `G` 3, `P` 1 |
| hold | 78502 | `P` 84, `F` 11, `X` 3, `B` 1 |
| spawn-heal | 32 | `H` 88, `F` 12 |
| bag->altar | 186114 | `B` 74, `F` 19, `R` 3, `C` 3 |
| bag->camp | 57252 | `F` 44, `B` 44, `R` 8, `C` 3 |
| bag-other | 39960 | `B` 38, `R` 37, `F` 12, `C` 12 |
| empty->camp | 287458 | `F` 88, `R` 5, `G` 4, `C` 2 |
| empty->spawn | 43284 | `R` 59, `F` 32, `C` 5, `G` 1 |
| empty-other | 77374 | `F` 70, `C` 12, `R` 8, `G` 5 |
| idle-off | 62446 | `F` 67, `B` 21, `G` 6, `h` 4 |
| idle-spawn | 5914 | `F` 93, `B` 6, `-` 1, `H` 0 |

## 2. Earnings (per game per side unless noted)

| metric | astraeus | astraeus-ef8f0b8 |
|---|---|---|
| gems captured | 835 | 835 |
| gems tributed | 739 | 739 |
| gems taken by kills | 106 | 106 |
| gems lost at death to champions | 106 | 106 |
| gems lost at death to camps | 1.9 | 1.9 |
| gold earned (lifetime) | 5094 | 5094 |
| r1-300 gems captured | 209 | 209 |
| r1-300 gems tributed | 127 | 127 |
| r1-300 gems lost at death | 5.2 | 5.2 |
| gems captured per camp-hit round | 1.1 | 1.1 |
| gems captured per hold round | 3.0 | 3.0 |
| gems captured per (camp+hold) round | 0.8 | 0.8 |
| gems tributed per 100 alive rounds | 17.0 | 17.0 |
| mean bag carried per alive round | 27.0 | 27.0 |
| % alive rounds carrying 30+ | 18.8 | 18.8 |
| tributes per 1000 alive rounds | 5.3 | 5.3 |
| mean bag at tribute | 31.9 | 31.9 |
| walk steps per tributed gem | 4.0 | 4.0 |
| bag-walk rounds per tributed gem | 1.4 | 1.4 |
| bag-walk rounds just before a tribute (mean trip) | 9.3 | 9.3 |
| idle-off rounds in stretches of 50+ (% of idle-off) | 14.4 | 14.4 |
| idle-off rounds in 50+ stretches by branch at its start, per game | `F` 29.3, `G` 2.7 | `F` 29.3, `G` 2.7 |
| altar locks placed / tribute attempts blocked, per game | 4.44 / 0.00 | 4.44 / 0.00 |
| real recalls per game (completed) | 52.6 (42.9) | 52.6 (42.9) |
| tribute cancels per game (cause) | death 0.04, lock 0.31, manual 0.29, stun 0.60 | death 0.04, lock 0.31, manual 0.29, stun 0.60 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | astraeus | 95.6 | 197 | 344 | 198 |
| gems captured | astraeus-ef8f0b8 | 95.6 | 197 | 344 | 198 |
| gems tributed | astraeus | 47.4 | 141 | 324 | 228 |
| gems tributed | astraeus-ef8f0b8 | 47.4 | 141 | 324 | 228 |
| alive champion-rounds | astraeus | 689 | 1122 | 1478 | 1061 |
| alive champion-rounds | astraeus-ef8f0b8 | 689 | 1122 | 1478 | 1061 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `R` | `F` | `B` | `S` | `G` | `C` | `E` |
|---|---|---|---|---|---|---|---|---|
| astraeus | 20.1/g, 92.4% done, 28.9% bag, 25.3 from spawn | 17.1/g, 80.5% done, 33.9% bag, 27.5 from spawn | 9.6/g, 61.4% done, 20.5% bag, 26.2 from spawn | 3.5/g, 82.3% done, 100.0% bag, 32.0 from spawn | 1.0/g, 95.1% done, 2.8% bag, 29.4 from spawn | 0.8/g, 67.8% done, 23.7% bag, 27.3 from spawn | 0.4/g, 57.6% done, 64.4% bag, 41.7 from spawn | 0.0/g, 100.0% done, 100.0% bag, 58.0 from spawn |
| astraeus-ef8f0b8 | 20.1/g, 92.4% done, 28.9% bag, 25.3 from spawn | 17.1/g, 80.5% done, 33.9% bag, 27.5 from spawn | 9.6/g, 61.4% done, 20.5% bag, 26.2 from spawn | 3.5/g, 82.3% done, 100.0% bag, 32.0 from spawn | 1.0/g, 95.1% done, 2.8% bag, 29.4 from spawn | 0.8/g, 67.8% done, 23.7% bag, 27.3 from spawn | 0.4/g, 57.6% done, 64.4% bag, 41.7 from spawn | 0.0/g, 100.0% done, 100.0% bag, 58.0 from spawn |

Bag size at tribute (% of tributes): astraeus: 0-19 47.6, 20-39 28.3, 40-59 14.1, 60-79 5.1, 80-99 1.8, 100+ 3.1; astraeus-ef8f0b8: 0-19 47.6, 20-39 28.3, 40-59 14.1, 60-79 5.1, 80-99 1.8, 100+ 3.1

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | r1-300 turns/gem (n) | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 3+ | 46 | 76.3 | 86.8 | 0.35 | - | 26.7 | 87.0 | 8.7 | 4.3 | 1.4 | 6.1 | 0.22 | 39.1 |
| Golem | 1 | 28 | 14.4 | 105 | 0.29 | - | 21.2 | 92.9 | 7.1 | 0.0 | 1.1 | 6.3 | 0.07 | 50.0 |
| Golem | 2 | 36 | 28.4 | 70.5 | 0.51 | - | 26.9 | 100 | 0.0 | 0.0 | 1.2 | 5.2 | 0.00 | 16.7 |
| Golem | 3+ | 86 | 44.9 | 69.6 | 0.78 | 1.42 (18) | 39.4 | 95.3 | 4.7 | 0.0 | 1.3 | 6.5 | 0.33 | 30.2 |
| Elk | 1 | 854 | 14.7 | 30.9 | 0.49 | 0.85 (38) | 22.7 | 95.8 | 2.8 | 1.4 | 1.0 | 6.9 | 0.10 | 11.9 |
| Elk | 2 | 1190 | 24.3 | 43.8 | 0.74 | 0.98 (248) | 31.2 | 98.5 | 1.0 | 0.5 | 1.0 | 6.7 | 0.04 | 11.4 |
| Elk | 3+ | 1128 | 36.2 | 43.3 | 0.87 | 1.09 (498) | 36.4 | 98.0 | 1.6 | 0.4 | 1.1 | 6.2 | 0.05 | 12.9 |
| Wolf | 1 | 2122 | 13.9 | 22.0 | 0.91 | 1.20 (466) | 14.9 | 96.6 | 2.9 | 0.5 | 1.0 | 7.3 | 0.08 | 8.5 |
| Wolf | 2 | 1446 | 19.7 | 31.9 | 1.36 | 2.03 (516) | 22.3 | 96.8 | 2.6 | 0.6 | 1.0 | 7.0 | 0.12 | 5.9 |
| Wolf | 3+ | 694 | 29.7 | 34.8 | 1.83 | 2.64 (388) | 29.2 | 96.8 | 2.0 | 1.2 | 1.1 | 6.9 | 0.07 | 8.9 |
| GemCl | 1 | 3220 | 2.7 | 3.6 | 0.20 | 0.21 (1144) | 0.0 | 92.9 | 5.1 | 2.0 | 1.0 | 11.0 | 0.11 | 4.6 |
| GemCl | 2 | 412 | 4.8 | 12.9 | 0.19 | 0.18 (176) | 0.0 | 97.1 | 1.5 | 1.5 | 1.0 | 8.4 | 0.13 | 6.8 |
| GemCl | 3+ | 66 | 12.9 | 9.8 | 0.15 | 0.14 (32) | 0.0 | 90.9 | 6.1 | 3.0 | 1.2 | 29.5 | 0.58 | 33.3 |
| GoldCl | 1 | 3304 | 3.3 | 6.5 | 3.97 | 1.85 (1260) | 0.0 | 95.8 | 2.4 | 1.8 | 1.0 | 9.5 | 0.07 | 5.2 |
| GoldCl | 2 | 594 | 3.9 | 14.1 | 23.37 | nan (264) | 0.0 | 97.0 | 2.0 | 1.0 | 1.0 | 7.8 | 0.10 | 7.4 |
| GoldCl | 3+ | 42 | 6.5 | 38.6 | nan | nan (24) | nan | 90.5 | 9.5 | 0.0 | 1.1 | 32.1 | 0.81 | 9.5 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus | 54.5 | 62.4 | 0.76 | 20.7 | 95.8 | 2.9 | 1.60 | 1.0 | 8.6 | 0.09 | 0.01 | 0.004 |
| astraeus-ef8f0b8 | 54.5 | 62.4 | 0.76 | 20.7 | 95.8 | 2.9 | 1.60 | 1.0 | 8.6 | 0.09 | 0.01 | 0.004 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus | 12.11 | 8.48 | 0.38 | 0.07 | 8.24 | 11.24 | 1.44 | 1.60 | 0.05 | 0.08 | 2.41 | 1.36 | 1.67 | 1.25 | 0.11 | 0.03 | 2.56 | 1.48 |
| astraeus-ef8f0b8 | 12.11 | 8.48 | 0.38 | 0.07 | 8.24 | 11.24 | 1.44 | 1.60 | 0.05 | 0.08 | 2.41 | 1.36 | 1.67 | 1.25 | 0.11 | 0.03 | 2.56 | 1.48 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus | own | 63.3 | 8.5 | 2.6 | 1.9 | 23.8 |
| astraeus | mid | 67.7 | 8.6 | 5.4 | 1.3 | 17.0 |
| astraeus | enemy | 63.3 | 8.5 | 2.6 | 1.9 | 23.8 |
| astraeus-ef8f0b8 | own | 63.3 | 8.5 | 2.6 | 1.9 | 23.8 |
| astraeus-ef8f0b8 | mid | 67.7 | 8.6 | 5.4 | 1.3 | 17.0 |
| astraeus-ef8f0b8 | enemy | 63.3 | 8.5 | 2.6 | 1.9 | 23.8 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus | own | 68.6 | 8.2 | 2.4 | 2.0 | 18.8 |
| astraeus | mid | 77.7 | 7.0 | 2.1 | 1.3 | 11.9 |
| astraeus | enemy | 68.6 | 8.2 | 2.4 | 2.0 | 18.8 |
| astraeus-ef8f0b8 | own | 68.6 | 8.2 | 2.4 | 2.0 | 18.8 |
| astraeus-ef8f0b8 | mid | 77.7 | 7.0 | 2.1 | 1.3 | 11.9 |
| astraeus-ef8f0b8 | enemy | 68.6 | 8.2 | 2.4 | 2.0 | 18.8 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| astraeus | Wolf | 62.3 | 8.8 | 1.6 | 72.7 | 7.3 | 1.7 | 62.3 | 8.8 | 1.6 |
| astraeus-ef8f0b8 | Wolf | 62.3 | 8.8 | 1.6 | 72.7 | 7.3 | 1.7 | 62.3 | 8.8 | 1.6 |
| astraeus | Elk | 51.3 | 12.3 | 1.5 | 47.4 | 17.2 | 1.7 | 51.3 | 12.3 | 1.5 |
| astraeus-ef8f0b8 | Elk | 51.3 | 12.3 | 1.5 | 47.4 | 17.2 | 1.7 | 51.3 | 12.3 | 1.5 |
| astraeus | Golem | 66.6 | 9.8 | 0.8 | 88.0 | 3.3 | 0.2 | 66.6 | 9.8 | 0.8 |
| astraeus-ef8f0b8 | Golem | 66.6 | 9.8 | 0.8 | 88.0 | 3.3 | 0.2 | 66.6 | 9.8 | 0.8 |
| astraeus | Monolith | 88.3 | 4.5 | 0.2 | 87.5 | 4.0 | 0.2 | 88.3 | 4.5 | 0.2 |
| astraeus-ef8f0b8 | Monolith | 88.3 | 4.5 | 0.2 | 87.5 | 4.0 | 0.2 | 88.3 | 4.5 | 0.2 |
| astraeus | GemCl | 43.6 | 2.4 | 7.7 | 43.0 | 3.7 | 21.0 | 43.6 | 2.4 | 7.7 |
| astraeus-ef8f0b8 | GemCl | 43.6 | 2.4 | 7.7 | 43.0 | 3.7 | 21.0 | 43.6 | 2.4 | 7.7 |
| astraeus | GoldCl | 56.8 | 2.4 | 6.9 | 63.8 | 1.6 | 8.2 | 56.8 | 2.4 | 6.9 |
| astraeus-ef8f0b8 | GoldCl | 56.8 | 2.4 | 6.9 | 63.8 | 1.6 | 8.2 | 56.8 | 2.4 | 6.9 |

Upper bound on gems left asleep per game (each asleep round = 1/(respawn+15) of a farm cycle): astraeus: own 1188, mid 801, enemy 1188; astraeus-ef8f0b8: own 1188, mid 801, enemy 1188

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| astraeus | 40.0 (536) | 6.8 (184) | 7.1 (115) | 13.9/1.8/1.8 |
| astraeus-ef8f0b8 | 40.0 (536) | 6.8 (184) | 7.1 (115) | 13.9/1.8/1.8 |

## 5. Deaths

| metric | astraeus | astraeus-ef8f0b8 |
|---|---|---|
| deaths/game (to champions + camps) | 4.7 + 0.34 | 4.7 + 0.34 |
| median first-death round (none = length+1) | 311 | 311 |
| % of games this side died first | 47.9 | 47.9 |
| % alone (no ally within 8) | 29.9 | 29.9 |
| % ally within 4 | 40.1 | 40.1 |
| % 2+ enemies within 8 | 68.4 | 68.4 |
| % on own ground | 59.1 | 59.1 |
| % on mid ground | 22.0 | 22.0 |
| % on enemy ground | 18.9 | 18.9 |
| % walking toward spawn (last 4 rounds) | 35.5 | 35.5 |
| % branch R in last 4 rounds | 83.8 | 83.8 |
| % carrying 30+ gems | 13.3 | 13.3 |
| mean enemies within 8 | 2.2 | 2.2 |
| mean gems carried at death | 21.2 | 21.2 |
| r1-300 deaths/game | 0.84 | 0.84 |

Branch at death (last D line): astraeus: `R` 75.8%, `E` 11.2%, `F` 7.0%, `K` 2.6%, `B` 1.4%, `T` 0.6%; astraeus-ef8f0b8: `R` 75.8%, `E` 11.2%, `F` 7.0%, `K` 2.6%, `B` 1.4%, `T` 0.6%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| astraeus | 0 | 0.6 | 5.5 | 4.7 | 4.1 |
| astraeus | 1 | 0.9 | 5.0 | 5.8 | 5.3 |
| astraeus | 2 | 0.1 | 2.5 | 3.7 | 4.9 |
| astraeus | 3+ | 0.1 | 1.1 | 1.2 | 4.4 |
| astraeus-ef8f0b8 | 0 | 0.6 | 5.5 | 4.7 | 4.1 |
| astraeus-ef8f0b8 | 1 | 0.9 | 5.0 | 5.8 | 5.3 |
| astraeus-ef8f0b8 | 2 | 0.1 | 2.5 | 3.7 | 4.9 |
| astraeus-ef8f0b8 | 3+ | 0.1 | 1.1 | 1.2 | 4.4 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| astraeus | 4.7 | 0.72 | 40.3 | 50.0 | 10.1 | 10.1 | 0.0 |
| astraeus-ef8f0b8 | 4.7 | 0.72 | 40.3 | 50.0 | 10.1 | 10.1 | 0.0 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| astraeus | 25.57 / +0.00 | 3.27 / -0.10 | 0.55 / -0.21 | 3.27 / +0.10 | 2.97 / +0.00 | 1.21 / +0.00 | 0.55 / +0.21 | 1.21 / +0.00 | 1.69 / +0.00 |
| astraeus-ef8f0b8 | 25.57 / +0.00 | 3.27 / -0.10 | 0.55 / -0.21 | 3.27 / +0.10 | 2.97 / +0.00 | 1.21 / +0.00 | 0.55 / +0.21 | 1.21 / +0.00 | 1.69 / +0.00 |
| pooled | 25.57 / +0.00 | 3.27 / -0.10 | 0.55 / -0.21 | 3.27 / +0.10 | 2.97 / +0.00 | 1.21 / +0.00 | 0.55 / +0.21 | 1.21 / +0.00 | 1.69 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| astraeus | 0.56 / -0.05 / 12.7 | 2.59 / -0.03 / 8.8 | 9.02 / +0.01 / 10.6 | 15.96 / +0.00 / 9.5 | 9.02 / -0.01 / 9.3 | 2.59 / +0.03 / 13.5 | 0.56 / +0.05 / 17.7 |
| astraeus-ef8f0b8 | 0.56 / -0.05 / 12.7 | 2.59 / -0.03 / 8.8 | 9.02 / +0.01 / 10.6 | 15.96 / +0.00 / 9.5 | 9.02 / -0.01 / 9.3 | 2.59 / +0.03 / 13.5 | 0.56 / +0.05 / 17.7 |
| pooled | 0.56 / -0.05 / 12.7 | 2.59 / -0.03 / 8.8 | 9.02 / +0.01 / 10.6 | 15.96 / +0.00 / 9.5 | 9.02 / -0.01 / 9.3 | 2.59 / +0.03 / 13.5 | 0.56 / +0.05 / 17.7 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 140 | 22 | 50.8 | 39.5 (n=86) | 78.6 (n=28) | 100.0 (n=4) |
| tributed r400 | 140 | 14 | 69.8 | 60.0 (n=60) | 68.2 (n=44) | 100.0 (n=22) |
| tributed r600 | 122 | 8 | 75.4 | 47.1 (n=34) | 84.2 (n=38) | 90.5 (n=42) |
| tributed+carried r200 | 140 | 14 | 71.4 | 64.3 (n=84) | 83.3 (n=36) | 100.0 (n=6) |
| tributed+carried r400 | 140 | 6 | 73.1 | 60.0 (n=50) | 70.4 (n=54) | 100.0 (n=30) |
| tributed+carried r600 | 122 | 4 | 79.7 | 53.3 (n=30) | 73.3 (n=30) | 96.6 (n=58) |

| predictor | win % |
|---|---|
| team that did not die first wins | 59.7 (n=134) |
| more kills wins | 87.5 (n=128) |
| more r1-300 kills wins | 62.5 (n=80) |
| more gems captured wins | 87.1 (n=140) |
| more r1-300 gems captured wins | 66.2 (n=136) |
| fewer gems lost at death wins | 71.9 (n=114) |
| more mid-group captures wins | 93.1 (n=58) |

Games where neither side tributes 200: 2 (the-pack).

Game length: median 945, quartiles 703-1205, min 441, max 2000; 4.3% reach round 2000; 95.7% end on 1000 gems.

## Examples

**bagdeath** (94 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/127-02treasure-box-12.repl26a` (cc4217505b90a637) r1171 team B (astraeus-ef8f0b8): Prism died with 1384 gems (champ, allies<=8 2, enemies<=8 2, branch T)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/091-01shortcut-12.repl26a` (b714855345688d11) r1223 team A (astraeus): Prism died with 820 gems (champ, allies<=8 1, enemies<=8 1, branch R)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r606 team A (astraeus): Vendetta died with 596 gems (champ, allies<=8 1, enemies<=8 5, branch E)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1283 team B (astraeus-ef8f0b8): Marcella died with 581 gems (champ, allies<=8 0, enemies<=8 1, branch C)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/019-00elkring-12.repl26a` (565d430298372233) r557 team B (astraeus-ef8f0b8): Prism died with 260 gems (champ, allies<=8 0, enemies<=8 4, branch F)
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/129-02uncharted-lands-12.repl26a` (f33798c62135a434) r565 team A (astraeus): Marcella died with 224 gems (champ, allies<=8 0, enemies<=8 3, branch R)

**stolen** (448 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/073-01boss-battle-12.repl26a` (4cbc1a0dfd8d447a) r481 team B (astraeus-ef8f0b8): Monolith (400 gems, mid) cleared r459 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/069-00vault-12.repl26a` (fcc8e1c0dd6d4d9e) r440 team B (astraeus-ef8f0b8): GemCl (343 gems, enemy) cleared r31 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/009-00contest-12.repl26a` (3674b10bf9072918) r1085 team A (astraeus): Monolith (200 gems, own) cleared r1079 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/067-00the-line-12.repl26a` (7a1fd1c74e67afe3) r163 team A (astraeus): GemCl (161 gems, own) cleared r156 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/063-00stampede-12.repl26a` (a24747cafef96c1b) r1360 team B (astraeus-ef8f0b8): Elk (160 gems, mid) cleared r1355 stolen
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/045-00pilgrimage-12.repl26a` (3a239830d4355491) r1499 team A (astraeus): Elk (88 gems, mid) cleared r1490 stolen

**idle-off30** (134 in all, largest first, one per game):

- `replays/batch-20261030-094349-ab-m3-mirror-ladder/123-02the-pack-12.repl26a` (a8e38c94d7ea7b82) r1336 team A (astraeus): Heart of Ruin#2 idle off spawn 665 rounds at (11, 30) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/009-00contest-12.repl26a` (3674b10bf9072918) r697 team B (astraeus-ef8f0b8): Willow#8 idle off spawn 173 rounds at (39, 18) branch G
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/125-02the-pond-12.repl26a` (2dc52e478df9c376) r845 team A (astraeus): Heart of Ruin#2 idle off spawn 163 rounds at (18, 19) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/127-02treasure-box-12.repl26a` (cc4217505b90a637) r1078 team B (astraeus-ef8f0b8): Willow#8 idle off spawn 93 rounds at (23, 31) branch F
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/115-02guardians-12.repl26a` (58c472f26eab1363) r697 team A (astraeus): Willow#2 idle off spawn 79 rounds at (25, 20) branch G
- `replays/batch-20261030-094349-ab-m3-mirror-ladder/057-00rows-12.repl26a` (919be5bac3ffc27c) r1083 team B (astraeus-ef8f0b8): Marcella#5 idle off spawn 78 rounds at (18, 30) branch G

