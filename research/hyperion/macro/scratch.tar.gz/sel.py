import re,sys,collections
for d in sys.argv[1:]:
    games=collections.defaultdict(list)
    for l in open(d+'/episodes/deaths.txt'):
        m=re.match(r'(\S+) (\S+) r(\d+) \[(\S+)\] (\S+) \((A|B),(W|L) .*?DIED at \(([\d,]+)\) (\S+) to (.*?); bag (\d+)',l)
        if not m: continue
        mp,g,r,t,ch,side,wl,pos,near,killer,bag=m.groups()
        if 'partner' in killer: continue
        games[g].append((int(r),wl,ch,int(bag),'camp' if 'camp' in killer else 'ch',near))
    idx={}
    for l in open(d+'/index.txt'):
        p=l.split()
        g=p[0].split('__')[1].replace('.txt','')
        idx[g]=l.strip()
    rows=[]
    for g,ds in games.items():
        ds.sort()
        W=sum(1 for x in ds if x[1]=='W' and x[4]=='ch'); L=sum(1 for x in ds if x[1]=='L' and x[4]=='ch')
        first=''.join(x[1] for x in ds[:4])
        lb=sum(x[3] for x in ds if x[1]=='L'); wb=sum(x[3] for x in ds if x[1]=='W')
        rows.append((L-W,g,W,L,first,ds[0][0],wb,lb))
    rows.sort(reverse=True)
    for r in rows[:40]:
        print(r, idx.get(r[1],'')[-60:])
