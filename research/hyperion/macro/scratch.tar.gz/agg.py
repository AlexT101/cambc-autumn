import sys,glob,collections,multiprocessing as mp
sys.path.insert(0,sys.argv[1]); from sumd import load
ch=lambda a,b: max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def work(gf):
    try: hdr,g,br=load(gf)
    except Exception as e: return []
    out=[]; W=g.winner; dmg=g.champ_damage
    deaths=[]
    for c in g.team_of:
        a=g.ch(c)['alive']
        for i in range(1,len(a)):
            if a[i-1] and not a[i]: deaths.append((i+1,c))
    deaths.sort(); seen=set(); n=[0,0]
    for r,c in deaths:
        t=g.team_of[c]
        if g.name_of[c] in ('Issac','Cassi') and (r,t) in seen: continue
        seen.add((r,t))
        hits=[d for d in dmg if d[3]==c and r-4<=d[1]<=r]
        if not hits: continue  # camp
        i=r-2; vp=g.pos(c,i)
        if not vp: continue
        n[t]+=1
        order=n[0]+n[1]
        vbr=[br.get((rr,c),'.') for rr in range(r-8,r+1)]
        # allies
        best=None
        for cc in g.team_of:
            if cc==c or g.team_of[cc]!=t: continue
            p=g.pos(cc,i)
            if not p: continue
            d=ch(p,vp); hp=g.ch(cc)['hp'][i]/g.ch(cc)['maxHp'][i]
            b=''.join(br.get((rr,cc),'.') for rr in range(r-6,r+1))
            if best is None or d<best[0]: best=(d,hp,b,g.name_of[cc])
        att=set(d[2] for d in hits)
        enear=sum(1 for cc in g.team_of if g.team_of[cc]!=t and g.pos(cc,i) and ch(g.pos(cc,i),vp)<=8)
        anear=sum(1 for cc in g.team_of if cc!=c and g.team_of[cc]==t and g.pos(cc,i) and ch(g.pos(cc,i),vp)<=8)
        sp=g.map.spawn_center(t); p8=g.pos(c,max(0,r-10)) or vp
        out.append(dict(g=hdr[0].split()[1],r=r,order=order,win=(t==W),name=g.name_of[c],gems=g.ch(c)['gems'][i],
            vbr=''.join(vbr),ally=best,natt=len(att),enear=enear,anear=anear,sp0=ch(p8,sp),sp1=ch(vp,sp),
            kbr=''.join(br.get((rr,hits[-1][2]),'.') for rr in range(r-6,r+1))))
    return out
if __name__=='__main__':
    files=[f for f in glob.glob(sys.argv[2]+'/games/*.txt') if not f.endswith('.fights.txt')]+[f for f in glob.glob(sys.argv[3]+'/games/*.txt') if not f.endswith('.fights.txt')]
    with mp.Pool(32) as p: res=[x for l in p.map(work,files) for x in l]
    import pickle; pickle.dump(res,open(sys.argv[4],'wb')); print(len(res))
