import sys,glob,collections,multiprocessing as mp
sys.path.insert(0,sys.argv[1]); from sumd import load
ch=lambda a,b: max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def work(gf):
    try: hdr,g,br=load(gf)
    except Exception: return []
    dmg=g.champ_damage; deaths=[]
    for c in g.team_of:
        a=g.ch(c)['alive']
        for i in range(1,len(a)):
            if a[i-1] and not a[i]:
                hits=[d for d in dmg if d[3]==c and i-3<=d[1]<=i+1]
                if hits and g.pos(c,i-1): deaths.append((i+1,c,g.pos(c,i-1)))
    deaths.sort(); seen=set(); out=[]
    D=[]
    for r,c,p in deaths:
        t=g.team_of[c]
        if g.name_of[c] in ('Issac','Cassi') and (r,t) in seen: continue
        seen.add((r,t)); D.append((r,c,p,t))
    for k,(r,c,p,t) in enumerate(D):
        prev=[x for x in D[:k] if x[3]==t and 0<r-x[0]<=25 and ch(x[2],p)<=8]
        if prev:
            r0=prev[-1][0]; p0=g.pos(c,r0-2)
            far = p0 is not None and ch(p0,p)>8
            out.append((t==g.winner,True,far,r-r0))
        else: out.append((t==g.winner,False,False,0))
    return out
if __name__=='__main__':
    files=[f for d in sys.argv[2:4] for f in glob.glob(d+'/games/*.txt') if not f.endswith('.fights.txt')]
    with mp.Pool(32) as p: res=[x for l in p.map(work,files) for x in l]
    for w in (True,False):
        s=[x for x in res if x[0]==w]
        print('winner' if w else 'loser', len(s), 'follow-up deaths', sum(x[1] for x in s), 'walked in from >8 after ally died', sum(x[2] for x in s))
