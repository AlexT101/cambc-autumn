import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    R=json.load(gzip.open(d/'rounds.json.gz'))
    out=collections.defaultdict(list)
    for c in R['champions']:
        for i in range(0,len(R['round']),10):
            r=R['round'][i]
            if c['alive'][i]: out[min(r//200,5)].append((c['gold'][i], c['earned'][i]))
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    T=collections.defaultdict(list)
    for r in res:
        for k,v in r.items(): T[k]+=v
    for k in sorted(T):
        v=T[k]; print(f'r{k*200}-{k*200+199}: mean carried gold {sum(a for a,b in v)/len(v):.0f}, mean earned {sum(b for a,b in v)/len(v):.0f}, share>=90: {sum(1 for a,b in v if a>=90)/len(v):.2f}')
