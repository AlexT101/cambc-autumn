import pickle,statistics as st,random
from collections import Counter
exec(open('dsum3.py').read().split("def show")[0])
pc=lambda n,m: f'{100*n/m:.0f}%' if m else '-'
E=[x for x in D if x['rec'].startswith('E')]
print('E clearing',pc(sum(x['clearing'] for x in E),len(E)),' walking',pc(sum(x['moved'] and not x['clearing'] for x in E),len(E)),' after-branch',Counter(x['after'] for x in E).most_common(5))
print('E after: R then die; pre5 has R', pc(sum('R' in x['pre5'] for x in E),len(E)))
Dd=[x for x in D if x['rec'].startswith('D')]
print('D pre5 all R',pc(sum(x['pre5']=='RRRRR' for x in Dd),len(Dd)),' pre5 last R',pc(sum(x['pre5'][-1:]=='R' for x in Dd),len(Dd)),' attackers',Counter(x['attackers'] for x in Dd).most_common(4))
print('types', Counter(x['type'] for x in D).most_common())
print('gems at death>=20',pc(sum(x['gems']>=20 for x in D),len(D)))
random.seed(3)
for k in sorted(set(x['rec'] for x in D)):
    T=[x for x in D if x['rec']==k and x['batch']!='ladder']
    T.sort(key=lambda x: x['hpf']); 
    for x in random.sample(T,3):
        print(k, x['src'].split('/')[-2][-12:]+'/'+x['src'].split('/')[-1], f"r{x['r1']}->{x['rD']} {x['type']}#{x['c']} team{x['team']} {'W' if x['won'] else 'L'} hp{x['hpf']:.2f} camp{x['cd30']:.0f} clr{int(x['clearing'])} br{x['branch']} nk{x['nk']}/nv{x['nv']} hist {x['hist']}")
