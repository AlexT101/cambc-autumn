# Strong-group visits of team A from replay events only (visits.py without traces). usage: m4visits.py RUNDIR
import json, gzip, glob, os, collections, sys, re
US = int(os.environ.get('US', '0'))
root = sys.argv[1]; ana = root + '/ana'
STRONG = {'Elk', 'Golem', 'Monolith'}
allv = []; gems = {}
for d in sorted(glob.glob(ana + '/*/meta.json')):
    gd = os.path.dirname(d); meta = json.load(open(d))
    run = meta['source'].split('/')[-2]
    log = open(f'{root}/{run}.log').read()
    a = re.search(r'\n  A +\S+ +(\d+)', log); b = re.search(r'\n  B +\S+ +(\d+)', log)
    gems[run] = (int(a.group(1)), int(b.group(1))) if US == 0 else (int(b.group(1)), int(a.group(1)))
    mp = json.load(open(os.path.join(gd, meta['mapFile'])))
    camp_g = {c['id']: c['group'] for c in mp['camps']}
    gtypes = {g['id']: g['types'] for g in mp['groups']}
    strong = {g for g, t in gtypes.items() if STRONG & set(t) and 'Monolith' not in t}
    team = {c['id']: c['team'] for c in meta['champions']}
    name = {c['id']: c['name'] for c in meta['champions']}
    ev = [json.loads(l) for l in gzip.open(gd + '/events.jsonl.gz', 'rt')]
    acts = collections.defaultdict(list); dealers = collections.defaultdict(lambda: collections.defaultdict(float))
    clears = collections.defaultdict(list); recalls = collections.defaultdict(list); deaths = collections.defaultdict(list)
    for e in ev:
        k = e['k']; r = e['r']
        if k in ('attack', 'cast') and 'cdmg' in e:
            for camp, dmg in e['cdmg']:
                G = camp_g.get(camp)
                if G is None: continue
                acts[(e['a'], G)].append((r, dmg, 0)); dealers[(G, r)][e['a']] += dmg
        elif k == 'camp_attack':
            G = e['g']; acts[(e['tgt'], G)].append((r, 0, e['dmg']))
            for x in e.get('xdmg', []) or []:
                try: acts[(x[0], G)].append((r, 0, x[1]))
                except Exception: pass
        elif k == 'group_clear': clears[e['g']].append(r)
        elif k == 'recall_end': recalls[e['a']].append(r)
        elif k == 'death': deaths[e['v']].append(r)
    for (c, G), lst in acts.items():
        if team.get(c) != US or G not in strong: continue
        lst.sort(); cur = None; segs = []
        for r, dl, tk in lst:
            if cur and r - cur['r1'] <= 5: cur['r1'] = r; cur['dealt'] += dl; cur['taken'] += tk
            else: cur = {'r0': r, 'r1': r, 'dealt': dl, 'taken': tk}; segs.append(cur)
        for s in segs:
            if s['dealt'] < 1: continue
            r0, r1 = s['r0'], s['r1']
            s.update(game=run, c=c, name=name[c], G=G)
            s['cleared'] = any(r0 <= r <= r1 + 3 for r in clears[G])
            s['recalled'] = any(r1 <= r <= r1 + 15 for r in recalls[c])
            s['died'] = any(r0 <= r <= r1 + 2 for r in deaths[c])
            mates = set()
            for r in range(r0, r1 + 1):
                for x in dealers.get((G, r), {}):
                    if x != c and team[x] == US: mates.add(x)
            s['mates'] = mates
            allv.append(s)
def summ(vs, label):
    if not vs: print(label, 'none'); return
    dl = sum(v['dealt'] for v in vs); tk = sum(v['taken'] for v in vs)
    print(f'{label:12s} n={len(vs):4d} dealt={dl:8.0f} taken={tk:7.0f} ratio={dl/max(tk,1):.2f} solo={sum(not v["mates"] for v in vs)/len(vs):.2f} recalled={sum(v["recalled"] for v in vs)/len(vs):.2f} died={sum(v["died"] for v in vs)/len(vs):.2f}')
clr = [v for v in allv if v['cleared']]; chip = [v for v in allv if not v['cleared']]
print(root, 'games', len(gems))
summ(allv, 'all'); summ(clr, 'cleared'); summ(chip, 'chip')
print(f'chip share {len(chip)/max(len(allv),1):.3f}  chips/game {len(chip)/len(gems):.1f}  strong dealt/game {sum(v["dealt"] for v in allv)/len(gems):.0f}  cleared-visit dealt/game {sum(v["dealt"] for v in clr)/len(gems):.0f}')
print('gems us/them by map:', ' '.join(f'{k.split("-")[0] if k.startswith("0") else k}:{a}/{b}' for k, (a, b) in sorted(gems.items())))
print('mean our gems', sum(a for a, b in gems.values()) / len(gems), 'mean theirs', sum(b for a, b in gems.values()) / len(gems))
