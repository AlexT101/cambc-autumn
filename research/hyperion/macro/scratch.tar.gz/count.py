import sys, zipfile, glob, os, collections, re
d = sys.argv[1]
for f in sorted(glob.glob(os.path.join(d, '*.repl26a'))):
    side = re.search(r'-(12|21)\.repl26a$', f).group(1)
    ours = 'team-a.stdout' if side == '12' else 'team-b.stdout'
    z = zipfile.ZipFile(f)
    out = {}
    for name in ('team-a.stdout', 'team-b.stdout'):
        try: txt = z.read(name).decode(errors='replace')
        except KeyError: txt = ''
        br = collections.Counter(); assist = help_ = errs = 0; dlines = 0
        for line in txt.splitlines():
            p = line.split()
            if p and p[0] == 'D' and len(p) >= 4: br[p[3]] += 1; dlines += 1
            elif p and p[0] == 'ASSIST': assist += 1
            elif p and p[0] == 'HELP': help_ += 1
            if 'error' in line: errs += 1
        out[name] = (dlines, br.get('Y', 0), br.get('R', 0), assist, help_, errs)
    o = out[ours]; t = out['team-b.stdout' if ours == 'team-a.stdout' else 'team-a.stdout']
    print(f"{os.path.basename(f):40s} ours: D={o[0]} Y={o[1]} R={o[2]} ASSIST={o[3]} HELP={o[4]} err={o[5]} | ref: D={t[0]} R={t[2]} err={t[5]}")
