import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def cheb(a,b): return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def one(d):
    R=json.load(gzip.open(d/'rounds.json.gz'))
    rix={r:i for i,r in enumerate(R['round'])}
    ch=R['champions']; team={c['id']:c['team'] for c in ch}
    fighting=collections.defaultdict(set)
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k'] in('attack','cast'):
            for cid,amt in e.get('dmg',[]) or []:
                if cid in team and team[cid]!=team[e['a']]:
                    fighting[e['r']].add(e['a']); fighting[e['r']].add(cid)
    out=collections.Counter()
    # fight starts: rounds with fighting where previous 3 rounds had none involving these
    prev=set()
    for r in sorted(fighting):
        f=fighting[r]
        new=[x for x in f if not any(x in fighting.get(r-k,()) for k in (1,2,3))]
        if not new: continue
        i=rix.get(r)
        if i is None: continue
        for t in (0,1):
            mine=[c for c in ch if c['team']==t and c['id'] in f]
            if not mine: continue
            out['fights']+=1
            ctr=(mine[0]['x'][i],mine[0]['y'][i])
            if ctr[0] is None: continue
            for c in ch:
                if c['team']!=t or c['id'] in f or not c['alive'][i] or c['x'][i] is None: continue
                d=cheb(ctr,(c['x'][i],c['y'][i]))
                if d<=12: out[f'free_ally_d{min(d,12)//3*3}']+=1
    return out
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(64) as ex: res=list(ex.map(one,dirs))
    T=collections.Counter()
    for r in res: T.update(r)
    n=T['fights']
    print('fight starts per team-game', n/len(dirs)/2)
    for k in sorted(T):
        if k!='fights': print(k, round(T[k]/n,3), 'per fight start')
