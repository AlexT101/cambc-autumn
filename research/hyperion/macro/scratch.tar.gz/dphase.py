import gzip,json,sys,collections
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def one(d):
    meta=json.loads((d/'meta.json').read_text())
    names=[t['name'] for t in meta['teams']]
    team={c['id']:c['team'] for c in meta['champions']}
    out=[]
    first=None
    for l in gzip.open(d/'events.jsonl.gz','rt'):
        e=json.loads(l)
        if e['k']=='death' and not e.get('linked'):
            out.append((e['r'], names[team[e['v']]], 'camp' in e, e.get('gems',0)))
    return out, names[meta['result']['winner']]
if __name__=='__main__':
    dirs=[p.parent for p in Path(sys.argv[1]).glob('*/meta.json')]
    with ProcessPoolExecutor(48) as ex: res=list(ex.map(one,dirs))
    bot=sys.argv[2]
    c=collections.Counter(); fb=collections.Counter(); fbw=collections.Counter()
    for deaths,w in res:
        for r,n,camp,g in deaths: c[(min(r//150,6), n==bot)]+=1
        if deaths:
            ours=deaths[0][1]==bot; fb[ours]+=1; fbw[(ours, w==bot)]+=1
    for b in range(7): print(f'r{b*150}-: ours {c[(b,True)]/len(res):.2f} theirs {c[(b,False)]/len(res):.2f}')
    print('first death ours', fb[True]/(fb[True]+fb[False]), 'win|we die first', fbw[(True,True)]/max(1,fb[True]), 'win|they die first', fbw[(False,True)]/max(1,fb[False]))
