# Turn budget: 326 games from replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand, replays/batch-20261030-100127-solo-m3-solo-base-gen-cand

Trace: 327 of 652 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 48.2% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all astraeus-ef8f0b8 | all idle | r1-150 astraeus-ef8f0b8 | r1-150 idle | r151-400 astraeus-ef8f0b8 | r151-400 idle | r401-800 astraeus-ef8f0b8 | r401-800 idle | r801+ astraeus-ef8f0b8 | r801+ idle | r1-300 astraeus-ef8f0b8 | r1-300 idle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 0.7 | 0.2 | 1.0 | 0.0 | 1.3 | 0.0 | 0.5 | 0.3 | 0.1 | 0.3 | 1.2 | 0.0 |
| fight | 0.1 | 0.1 | 0.0 | 0.1 | 0.0 | 0.1 | 0.1 | 0.2 | 0.2 | 0.3 | 0.0 | 0.1 |
| tribute | 4.0 | 0.0 | 2.1 | 0.0 | 3.6 | 0.0 | 5.1 | 0.0 | 4.1 | 0.0 | 2.7 | 0.0 |
| recall | 3.3 | 0.0 | 3.5 | 0.0 | 4.0 | 0.0 | 3.3 | 0.0 | 2.0 | 0.0 | 3.8 | 0.0 |
| hold+recall | 3.9 | 0.0 | 4.0 | 0.0 | 5.0 | 0.0 | 3.9 | 0.0 | 2.0 | 0.0 | 4.5 | 0.0 |
| teleport | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.1 | 0.0 | 0.2 | 0.0 | 0.0 | 0.0 |
| camp | 21.9 | 0.0 | 31.2 | 0.0 | 25.0 | 0.0 | 20.4 | 0.0 | 11.2 | 0.0 | 28.4 | 0.0 |
| hold | 5.3 | 0.0 | 6.0 | 0.0 | 5.4 | 0.0 | 5.2 | 0.0 | 4.6 | 0.0 | 5.7 | 0.0 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 13.1 | 0.0 | 9.3 | 0.0 | 14.4 | 0.0 | 14.5 | 0.0 | 12.2 | 0.0 | 11.7 | 0.0 |
| bag->camp | 5.5 | 0.0 | 4.1 | 0.0 | 6.4 | 0.0 | 5.8 | 0.0 | 4.9 | 0.0 | 5.3 | 0.0 |
| bag-other | 2.2 | 0.0 | 1.2 | 0.0 | 1.8 | 0.0 | 2.0 | 0.0 | 4.0 | 0.0 | 1.5 | 0.0 |
| empty->camp | 25.3 | 0.0 | 29.4 | 0.0 | 23.0 | 0.0 | 24.9 | 0.0 | 25.6 | 0.0 | 26.2 | 0.0 |
| empty->spawn | 1.9 | 0.0 | 1.0 | 0.0 | 1.1 | 0.0 | 1.8 | 0.0 | 4.4 | 0.0 | 1.0 | 0.0 |
| empty-other | 4.8 | 0.0 | 3.1 | 0.0 | 3.0 | 0.0 | 4.6 | 0.0 | 9.4 | 0.0 | 3.0 | 0.0 |
| idle-off | 7.8 | 0.0 | 4.0 | 0.0 | 5.9 | 0.0 | 7.8 | 0.0 | 14.4 | 0.0 | 4.8 | 0.0 |
| idle-spawn | 0.2 | 99.7 | 0.1 | 99.9 | 0.1 | 99.9 | 0.1 | 99.5 | 0.7 | 99.4 | 0.1 | 99.9 |

By attack type (all rounds):

| class | melee astraeus-ef8f0b8 | melee idle | ranged astraeus-ef8f0b8 | ranged idle |
|---|---|---|---|---|
| dead | 0.7 | 0.1 | 0.8 | 0.3 |
| fight | 0.0 | 0.1 | 0.1 | 0.4 |
| tribute | 4.5 | 0.0 | 2.9 | 0.0 |
| recall | 3.4 | 0.0 | 3.1 | 0.0 |
| hold+recall | 4.3 | 0.0 | 3.0 | 0.0 |
| teleport | 0.1 | 0.0 | 0.1 | 0.0 |
| camp | 21.3 | 0.0 | 23.0 | 0.0 |
| hold | 4.9 | 0.0 | 6.1 | 0.0 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 13.0 | 0.0 | 13.4 | 0.0 |
| bag->camp | 4.3 | 0.0 | 7.8 | 0.0 |
| bag-other | 1.9 | 0.0 | 2.8 | 0.0 |
| empty->camp | 27.0 | 0.0 | 22.1 | 0.0 |
| empty->spawn | 2.1 | 0.0 | 1.7 | 0.0 |
| empty-other | 5.1 | 0.0 | 4.2 | 0.0 |
| idle-off | 7.3 | 0.0 | 8.7 | 0.0 |
| idle-spawn | 0.2 | 99.8 | 0.2 | 99.2 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | astraeus-ef8f0b8 | 87693 | 1.9 | 0.0 | 23.4 | 5.8 | 2.3 | 3.1 | 0.0 | 0.0 | 6.3 | 53.1 |
| Heart of Ruin | astraeus-ef8f0b8 | 225146 | 0.5 | 0.0 | 25.2 | 5.2 | 3.8 | 2.4 | 0.0 | 0.6 | 8.2 | 50.3 |
| Heart of Ruin | idle | 286120 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 99.9 | 0.0 | 0.0 |
| Issac | astraeus-ef8f0b8 | 87693 | 1.9 | 0.0 | 21.8 | 5.2 | 4.2 | 3.4 | 0.0 | 0.0 | 5.3 | 53.1 |
| Marcella | astraeus-ef8f0b8 | 239860 | 0.7 | 0.0 | 18.8 | 4.9 | 4.3 | 4.0 | 0.0 | 0.1 | 8.3 | 55.1 |
| Marcella | idle | 286120 | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 99.8 | 0.0 | 0.0 |
| Prism | astraeus-ef8f0b8 | 139230 | 0.7 | 0.4 | 21.8 | 8.3 | 3.2 | 3.1 | 0.0 | 0.1 | 9.2 | 51.0 |
| Ren | astraeus-ef8f0b8 | 2735 | 0.0 | 0.0 | 27.3 | 2.1 | 2.7 | 3.5 | 0.0 | 0.0 | 2.6 | 57.4 |
| Ryth | astraeus-ef8f0b8 | 15619 | 0.4 | 1.8 | 21.0 | 5.3 | 5.0 | 2.9 | 0.0 | 0.1 | 3.9 | 56.5 |
| Ryth | idle | 112386 | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 99.9 | 0.0 | 0.0 |
| Tavi | astraeus-ef8f0b8 | 14732 | 0.0 | 0.0 | 20.6 | 7.7 | 3.4 | 0.9 | 0.0 | 0.0 | 12.1 | 52.7 |
| Varg | astraeus-ef8f0b8 | 24930 | 0.2 | 0.0 | 21.5 | 3.1 | 4.8 | 3.1 | 0.0 | 0.0 | 5.0 | 57.1 |
| Vendetta | astraeus-ef8f0b8 | 211803 | 0.4 | 0.0 | 19.7 | 4.5 | 5.6 | 4.0 | 0.0 | 0.0 | 6.7 | 53.6 |
| Vendetta | idle | 286120 | 0.3 | 0.2 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 99.5 | 0.0 | 0.0 |
| Vesper Vale | astraeus-ef8f0b8 | 97051 | 0.3 | 0.0 | 22.9 | 5.0 | 4.2 | 3.4 | 0.0 | 0.0 | 6.3 | 53.6 |
| Vesper Vale | idle | 186102 | 0.3 | 0.4 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 99.2 | 0.0 | 0.0 |
| Willow | astraeus-ef8f0b8 | 98049 | 0.6 | 0.0 | 24.6 | 4.1 | 1.8 | 3.0 | 0.0 | 0.6 | 12.2 | 50.9 |

Bot branch (D lines), % of champion-rounds:

| branch | all astraeus-ef8f0b8 | all idle | r1-300 astraeus-ef8f0b8 | r1-300 idle |
|---|---|---|---|---|
| `-` | 0.8 | 0.0 | 1.2 | 0.0 |
| `?` | 0.1 | 100.0 | 0.0 | 100.0 |
| `B` | 22.9 | 0.0 | 21.0 | 0.0 |
| `F` | 59.2 | 0.0 | 62.2 | 0.0 |
| `G` | 3.0 | 0.0 | 0.5 | 0.0 |
| `H` | 0.9 | 0.0 | 1.0 | 0.0 |
| `K` | 1.0 | 0.0 | 1.5 | 0.0 |
| `P` | 5.1 | 0.0 | 5.8 | 0.0 |
| `Q` | 3.0 | 0.0 | 3.5 | 0.0 |
| `R` | 0.9 | 0.0 | 1.0 | 0.0 |
| `S` | 0.1 | 0.0 | 0.1 | 0.0 |
| `T` | 2.0 | 0.0 | 1.3 | 0.0 |
| `h` | 0.3 | 0.0 | 0.4 | 0.0 |
| `k` | 0.7 | 0.0 | 0.5 | 0.0 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 9965 | 90 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 10 |  |
| `?` | 1157883 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 100 |
| `B` | 284976 |  |  | 4 | 1 |  |  | 18 |  |  | 48 | 15 | 7 |  |  |  | 5 |  |
| `F` | 737097 |  |  | 1 |  |  |  | 29 | 1 |  | 3 | 3 |  | 41 | 2 | 7 | 9 |  |
| `G` | 37434 |  |  |  |  |  |  | 18 |  |  | 2 | 1 |  | 20 | 11 | 14 | 32 |  |
| `H` | 10711 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 12039 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 63718 |  |  |  |  | 12 |  | 2 | 85 |  |  |  |  |  |  |  |  |  |
| `Q` | 36957 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 11177 |  | 1 |  | 27 |  |  |  |  |  | 9 | 2 | 10 | 11 | 22 | 16 |  |  |
| `S` | 801 |  |  | 59 | 3 |  |  |  |  |  | 2 | 3 | 4 | 7 | 23 |  |  |  |
| `T` | 25497 |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `h` | 3932 |  |  | 1 |  |  |  | 4 |  |  |  |  |  | 14 | 12 | 9 | 59 |  |
| `k` | 9192 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 10 |  |  |  |  |  |  |  |  |  | 30 | 10 | 40 |  | 10 |  | 10 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 10762 | `-` 84, `?` 16 |
| fight | 2657 | `?` 65, `F` 27, `R` 5, `B` 2 |
| tribute | 49422 | `T` 52, `B` 24, `F` 22, `S` 1 |
| recall | 41065 | `K` 29, `H` 26, `k` 22, `R` 7 |
| hold+recall | 48005 | `Q` 77, `P` 16, `F` 5, `B` 1 |
| teleport | 909 | `F` 75, `B` 24, `P` 0 |
| camp | 272251 | `F` 79, `B` 18, `G` 2, `P` 1 |
| hold | 65920 | `P` 83, `F` 14, `B` 3, `G` 0 |
| spawn-heal | 137 | `?` 99, `F` 1 |
| bag->altar | 163454 | `B` 84, `F` 15, `R` 1, `G` 1 |
| bag->camp | 68671 | `B` 63, `F` 36, `G` 1, `R` 0 |
| bag-other | 27340 | `B` 70, `F` 24, `R` 4, `G` 1 |
| empty->camp | 314563 | `F` 96, `G` 2, `B` 1, `R` 0 |
| empty->spawn | 24154 | `F` 67, `G` 17, `R` 10, `B` 3 |
| empty-other | 59321 | `F` 85, `G` 9, `R` 3, `B` 2 |
| idle-off | 97195 | `F` 71, `B` 13, `G` 12, `h` 2 |
| idle-spawn | 1155563 | `?` 100, `F` 0, `B` 0, `-` 0 |

## 2. Earnings (per game per side unless noted)

| metric | astraeus-ef8f0b8 | idle |
|---|---|---|
| gems captured | 1034 | 0.0 |
| gems tributed | 1003 | 0.0 |
| gems taken by kills | 0.0 | 0.0 |
| gems lost at death to champions | 0.0 | 0.0 |
| gems lost at death to camps | 3.6 | 0.0 |
| gold earned (lifetime) | 5313 | 0.0 |
| r1-300 gems captured | 303 | 0.0 |
| r1-300 gems tributed | 222 | 0.0 |
| r1-300 gems lost at death | 1.9 | 0.0 |
| gems captured per camp-hit round | 1.2 | - |
| gems captured per hold round | 5.1 | - |
| gems captured per (camp+hold) round | 1.0 | - |
| gems tributed per 100 alive rounds | 26.5 | 0.0 |
| mean bag carried per alive round | 19.8 | 0.0 |
| % alive rounds carrying 30+ | 17.5 | 0.0 |
| tributes per 1000 alive rounds | 9.6 | 0.0 |
| mean bag at tribute | 27.4 | - |
| walk steps per tributed gem | 2.4 | - |
| bag-walk rounds per tributed gem | 0.8 | - |
| bag-walk rounds just before a tribute (mean trip) | 7.3 | - |
| idle-off rounds in stretches of 50+ (% of idle-off) | 15.0 | - |
| idle-off rounds in 50+ stretches by branch at its start, per game | `F` 25.2, `G` 18.3, `B` 1.1 |  |
| altar locks placed / tribute attempts blocked, per game | 2.10 / 0.00 | 0.00 / 0.00 |
| real recalls per game (completed) | 48.7 (44.4) | 0.0 (0.0) |
| tribute cancels per game (cause) | lock 0.00, manual 0.01 | lock 0.00, manual 0.00 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | astraeus-ef8f0b8 | 132 | 303 | 429 | 169 |
| gems captured | idle | 0.0 | 0.0 | 0.0 | 0.0 |
| gems tributed | astraeus-ef8f0b8 | 80.2 | 253 | 466 | 204 |
| gems tributed | idle | 0.0 | 0.0 | 0.0 | 0.0 |
| alive champion-rounds | astraeus-ef8f0b8 | 665 | 1089 | 1309 | 728 |
| alive champion-rounds | idle | 617 | 1014 | 1220 | 693 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `F` | `R` | `B` | `S` | `G` | `?` |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 23.9/g, 97.5% done, 27.2% bag, 21.7 from spawn | 10.5/g, 78.6% done, 10.9% bag, 27.9 from spawn | 8.8/g, 86.6% done, 25.0% bag, 23.0 from spawn | 3.7/g, 95.2% done, 100.0% bag, 26.3 from spawn | 1.3/g, 98.6% done, 0.0% bag, 33.9 from spawn | 0.5/g, 80.2% done, 9.0% bag, 25.0 from spawn | 0.0/g, 100.0% done, 100.0% bag, 32.0 from spawn |
| idle | - | - | - | - | - | - | - |

Bag size at tribute (% of tributes): astraeus-ef8f0b8: 0-19 57.1, 20-39 22.8, 40-59 12.8, 60-79 4.0, 80-99 1.0, 100+ 2.3; idle: 0-19 -, 20-39 -, 40-59 -, 60-79 -, 80-99 -, 100+ -

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | r1-300 turns/gem (n) | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 3+ | 57 | 97.5 | 63.8 | 0.45 | - | 29.8 | 100 | 0.0 | 0.0 | 1.5 | 5.1 | 0.00 | 0.0 |
| Golem | 1 | 198 | 15.3 | 26.5 | 0.36 | 0.64 (1) | 27.4 | 99.0 | 0.0 | 1.0 | 1.0 | 5.2 | 0.00 | 0.0 |
| Golem | 2 | 253 | 25.4 | 37.6 | 0.54 | 0.88 (5) | 30.8 | 100 | 0.0 | 0.0 | 1.1 | 5.5 | 0.00 | 0.0 |
| Golem | 3+ | 427 | 47.7 | 63.2 | 0.94 | 1.47 (119) | 54.7 | 100 | 0.0 | 0.0 | 1.1 | 5.8 | 0.01 | 0.0 |
| Elk | 1 | 1456 | 13.3 | 21.6 | 0.62 | 0.91 (101) | 25.1 | 98.9 | 0.0 | 1.1 | 1.0 | 6.1 | 0.00 | 0.0 |
| Elk | 2 | 1687 | 20.9 | 28.5 | 0.87 | 1.28 (473) | 31.3 | 99.6 | 0.0 | 0.4 | 1.0 | 5.9 | 0.00 | 0.0 |
| Elk | 3+ | 1701 | 28.9 | 27.4 | 0.91 | 1.30 (816) | 29.2 | 99.5 | 0.0 | 0.5 | 1.1 | 5.9 | 0.00 | 0.0 |
| Wolf | 1 | 2522 | 11.8 | 14.6 | 1.25 | 2.00 (513) | 21.6 | 99.1 | 0.0 | 0.9 | 1.0 | 6.4 | 0.02 | 0.0 |
| Wolf | 2 | 1969 | 17.0 | 22.2 | 1.39 | 2.38 (684) | 22.3 | 99.2 | 0.0 | 0.8 | 1.0 | 6.1 | 0.00 | 0.0 |
| Wolf | 3+ | 1171 | 24.6 | 22.4 | 1.56 | 1.79 (603) | 23.5 | 99.7 | 0.0 | 0.3 | 1.0 | 6.0 | 0.01 | 0.0 |
| GemCl | 1 | 5598 | 3.2 | 2.7 | 0.24 | 0.25 (2113) | 0.0 | 98.9 | 0.0 | 1.1 | 1.0 | 7.7 | 0.00 | 0.0 |
| GemCl | 2 | 1238 | 4.4 | 6.9 | 0.22 | 0.24 (525) | 0.0 | 99.4 | 0.0 | 0.6 | 1.0 | 6.1 | 0.00 | 0.0 |
| GemCl | 3+ | 265 | 7.5 | 5.7 | 0.23 | 0.25 (126) | 0.0 | 98.5 | 0.0 | 1.5 | 1.1 | 6.1 | 0.01 | 0.0 |
| GoldCl | 1 | 4919 | 2.8 | 3.1 | 0.81 | 1.35 (2035) | 0.0 | 98.0 | 0.0 | 2.0 | 1.0 | 8.9 | 0.00 | 0.0 |
| GoldCl | 2 | 677 | 3.4 | 20.7 | 1.01 | 2.67 (354) | 0.0 | 97.2 | 0.0 | 2.8 | 1.0 | 7.5 | 0.00 | 0.0 |
| GoldCl | 3+ | 49 | 7.0 | 30.9 | 0.40 | 0.50 (31) | 0.0 | 100 | 0.0 | 0.0 | 1.0 | 10.0 | 0.00 | 0.0 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 74.2 | 60.7 | 0.73 | 19.3 | 98.9 | 0.0 | 0.00 | 1.0 | 7.1 | 0.00 | 0.00 | 0.006 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 14.25 | 11.28 | 1.99 | 0.10 | 15.56 | 14.21 | 1.35 | 1.46 | 0.23 | 0.04 | 2.16 | 1.07 | 1.76 | 2.12 | 0.47 | 0.04 | 4.06 | 2.04 |
| idle | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 62.7 | 6.7 | 1.1 | 2.1 | 27.4 |
| astraeus-ef8f0b8 | mid | 80.9 | 4.9 | 0.8 | 0.9 | 12.6 |
| astraeus-ef8f0b8 | enemy | 90.8 | 1.9 | 0.5 | 0.4 | 6.3 |
| idle | own | 90.8 | 1.9 | 0.5 | 0.4 | 6.3 |
| idle | mid | 80.9 | 4.9 | 0.8 | 0.9 | 12.6 |
| idle | enemy | 62.7 | 6.7 | 1.1 | 2.1 | 27.4 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 67.4 | 7.2 | 1.0 | 2.3 | 22.1 |
| astraeus-ef8f0b8 | mid | 85.4 | 4.4 | 0.4 | 1.0 | 8.9 |
| astraeus-ef8f0b8 | enemy | 94.9 | 1.4 | 0.2 | 0.3 | 3.2 |
| idle | own | 94.9 | 1.4 | 0.2 | 0.3 | 3.2 |
| idle | mid | 85.4 | 4.4 | 0.4 | 1.0 | 8.9 |
| idle | enemy | 67.4 | 7.2 | 1.0 | 2.3 | 22.1 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | Wolf | 62.4 | 7.8 | 1.3 | 82.0 | 3.7 | 1.1 | 95.3 | 1.0 | 0.2 |
| idle | Wolf | 95.3 | 1.0 | 0.2 | 82.0 | 3.7 | 1.1 | 62.4 | 7.8 | 1.3 |
| astraeus-ef8f0b8 | Elk | 50.2 | 9.5 | 1.3 | 69.1 | 6.9 | 1.9 | 90.6 | 2.0 | 0.3 |
| idle | Elk | 90.6 | 2.0 | 0.3 | 69.1 | 6.9 | 1.9 | 50.2 | 9.5 | 1.3 |
| astraeus-ef8f0b8 | Golem | 59.9 | 9.1 | 0.8 | 78.6 | 6.2 | 1.4 | 91.3 | 1.9 | 0.2 |
| idle | Golem | 91.3 | 1.9 | 0.2 | 78.6 | 6.2 | 1.4 | 59.9 | 9.1 | 0.8 |
| astraeus-ef8f0b8 | Monolith | 92.0 | 2.9 | 0.1 | 94.9 | 1.6 | 0.1 | 96.5 | 1.3 | 0.0 |
| idle | Monolith | 96.5 | 1.3 | 0.0 | 94.9 | 1.6 | 0.1 | 92.0 | 2.9 | 0.1 |
| astraeus-ef8f0b8 | GemCl | 38.2 | 2.5 | 3.3 | 57.5 | 2.4 | 3.1 | 82.5 | 0.8 | 2.2 |
| idle | GemCl | 82.5 | 0.8 | 2.2 | 57.5 | 2.4 | 3.1 | 38.2 | 2.5 | 3.3 |
| astraeus-ef8f0b8 | GoldCl | 53.4 | 1.7 | 5.7 | 75.7 | 1.2 | 2.4 | 91.8 | 0.4 | 2.3 |
| idle | GoldCl | 91.8 | 0.4 | 2.3 | 75.7 | 1.2 | 2.4 | 53.4 | 1.7 | 5.7 |

Upper bound on gems left asleep per game (each asleep round = 1/(respawn+15) of a farm cycle): astraeus-ef8f0b8: own 1023, mid 513, enemy 1582; idle: own 1582, mid 513, enemy 1023

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| astraeus-ef8f0b8 | 56.8 (700) | 6.2 (164) | 10.3 (171) | 20.7/1.8/2.7 |
| idle | 0.0 (0) | 0.0 (0) | 0.0 (0) | 0.0/0.0/0.0 |

## 5. Deaths

| metric | astraeus-ef8f0b8 | idle |
|---|---|---|
| deaths/game (to champions + camps) | 0.0 + 0.37 | 0.1 + 0.00 |
| median first-death round (none = length+1) | 714 | 792 |
| % of games this side died first | 19.0 | 1.5 |
| % alone (no ally within 8) | 23.8 | 3.3 |
| % ally within 4 | 57.4 | 96.7 |
| % 2+ enemies within 8 | 4.9 | 53.3 |
| % on own ground | 69.7 | 100.0 |
| % on mid ground | 22.1 | 0.0 |
| % on enemy ground | 8.2 | 0.0 |
| % walking toward spawn (last 4 rounds) | 24.6 | 0.0 |
| % branch R in last 4 rounds | 98.4 | 0.0 |
| % carrying 30+ gems | 12.3 | 0.0 |
| mean enemies within 8 | 0.2 | 1.9 |
| mean gems carried at death | 9.0 | 0.0 |
| r1-300 deaths/game | 0.24 | 0.00 |

Gems lost at death by champion type, per game (% of the side's loss): astraeus-ef8f0b8: Prism 1.8 (53.3%), Marcella 0.7 (22.2%), Vendetta 0.3 (8.4%), Heart of Ruin 0.2 (4.8%); idle: Vesper Vale 0.0 (-%), Vendetta 0.0 (-%), Marcella 0.0 (-%), Heart of Ruin 0.0 (-%)

Deaths carrying 100+ gems: astraeus-ef8f0b8 0.01/game holding 25.0% of gems lost; idle 0.00/game holding -% of gems lost

Branch at death (last D line): astraeus-ef8f0b8: `R` 94.3%, `F` 3.3%, `K` 2.5%; idle: `-` 100.0%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0 | 0.9 | 0.0 | 0.0 | 0.0 |
| astraeus-ef8f0b8 | 1 | 1.4 | 0.0 | 0.0 | 0.1 |
| astraeus-ef8f0b8 | 2 | 0.8 | 0.0 | 0.0 | 0.1 |
| astraeus-ef8f0b8 | 3+ | 0.4 | 0.0 | 0.0 | 0.0 |
| idle | 0 | 0.0 | 0.0 | 0.0 | 0.0 |
| idle | 1 | 0.0 | 0.0 | 0.0 | 0.0 |
| idle | 2 | 0.0 | 0.1 | 0.1 | 0.1 |
| idle | 3+ | 0.0 | 0.2 | 0.2 | 0.1 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0.1 | 0.00 | 2.4 | 100.0 | 3.8 | 0.1 | 0.0 |
| idle | 0.0 | 0.00 | 2.4 | 0.0 | 0.1 | 3.8 | 0.0 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 1.10 / +0.06 | 0.57 / +0.00 | 0.28 / +0.00 | 0.02 / +0.80 | 0.09 / +0.10 | 0.35 / +0.01 | - | 0.00 / +0.00 | 0.00 / +0.00 |
| idle | 1.10 / -0.06 | 0.02 / -0.80 | - | 0.57 / +0.00 | 0.09 / -0.10 | 0.00 / +0.00 | 0.28 / +0.00 | 0.35 / -0.01 | 0.00 / +0.00 |
| pooled | 1.10 / +0.00 | 0.29 / -0.02 | 0.14 / +0.00 | 0.29 / +0.02 | 0.09 / +0.00 | 0.17 / +0.01 | 0.14 / +0.00 | 0.17 / -0.01 | 0.00 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0.44 / +0.06 / 6.2 | 0.89 / +0.02 / 2.4 | 0.85 / +0.02 / 2.2 | 0.20 / +0.11 / 10.8 | 0.01 / +0.00 / 0.0 | 0.00 / +1.00 / 100.0 | - |
| idle | - | 0.00 / -1.00 / 0.0 | 0.01 / +0.00 / 0.0 | 0.20 / -0.11 / 0.0 | 0.85 / -0.02 / 0.0 | 0.89 / -0.02 / 0.0 | 0.44 / -0.06 / 0.7 |
| pooled | 0.22 / +0.06 / 6.2 | 0.45 / +0.02 / 2.4 | 0.43 / +0.02 / 2.1 | 0.20 / +0.00 / 5.4 | 0.43 / -0.02 / 0.0 | 0.45 / -0.02 / 0.3 | 0.22 / -0.06 / 0.7 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 326 | 30 | 100.0 | 100.0 (n=47) | 100.0 (n=155) | 100.0 (n=94) |
| tributed r400 | 314 | 15 | 100.0 | 100.0 (n=2) | 100.0 (n=45) | 100.0 (n=252) |
| tributed r600 | 251 | 4 | 100.0 | 100.0 (n=1) | 100.0 (n=13) | 100.0 (n=233) |
| tributed+carried r200 | 326 | 12 | 100.0 | 100.0 (n=22) | 100.0 (n=124) | 100.0 (n=168) |
| tributed+carried r400 | 314 | 5 | 100.0 | 100.0 (n=3) | 100.0 (n=26) | 100.0 (n=280) |
| tributed+carried r600 | 251 | 2 | 100.0 | - (n=0) | 100.0 (n=9) | 100.0 (n=240) |

| predictor | win % |
|---|---|
| team that did not die first wins | 7.5 (n=67) |
| more kills wins | 100.0 (n=8) |
| more r1-300 kills wins | - (n=0) |
| more gems captured wins | 100.0 (n=326) |
| more r1-300 gems captured wins | 100.0 (n=318) |
| fewer gems lost at death wins | 0.0 (n=25) |
| more mid-group captures wins | 100.0 (n=121) |

Games where neither side tributes 200: 1 (the-pack).

Game length: median 801, quartiles 613-1012, min 209, max 2000; 4.6% reach round 2000; 95.4% end on 1000 gems.

## Examples

**bagdeath** (4 in all, largest first, one per game):

- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/221-gen-tunnels-600104308-12.repl26a` (50d878a658f644c8) r650 team A (astraeus-ef8f0b8): Prism died with 156 gems (camp, allies<=8 2, enemies<=8 0, branch R)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/026-gen-atoll-600101906-12.repl26a` (635c12cbb13aa03f) r790 team A (astraeus-ef8f0b8): Prism died with 118 gems (camp, allies<=8 1, enemies<=8 0, branch R)
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/079-gen-cross-600103307-21.repl26a` (6fad7a39376af6ea) r379 team B (astraeus-ef8f0b8): Marcella died with 72 gems (camp, allies<=8 2, enemies<=8 0, branch R)
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/046-01shortcut-12.repl26a` (7dcaef373b3c5ec0) r265 team A (astraeus-ef8f0b8): Prism died with 63 gems (camp, allies<=8 0, enemies<=8 0, branch R)

**stolen** (0 in all, largest first, one per game):


**idle-off30** (168 in all, largest first, one per game):

- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/031-gen-atoll-600101919-12.repl26a` (0fb3bd5dfdd7b433) r674 team A (astraeus-ef8f0b8): Heart of Ruin#2 idle off spawn 1327 rounds at (43, 68) branch G
- `replays/batch-20261030-100127-solo-m3-solo-base-ladder-cand/062-02the-pack-12.repl26a` (a5b485eabf205f3f) r712 team A (astraeus-ef8f0b8): Prism#0 idle off spawn 1289 rounds at (13, 0) branch F
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/254-mut-the-pack-600101845-21.repl26a` (5a5d96d6d5c73120) r1099 team B (astraeus-ef8f0b8): Marcella#5 idle off spawn 902 rounds at (28, 34) branch F
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/251-mut-stampede-600101844-12.repl26a` (e570fa185610bc97) r195 team A (astraeus-ef8f0b8): Heart of Ruin#3 idle off spawn 534 rounds at (3, 1) branch F
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/047-gen-chambers-600103608-21.repl26a` (9308974a05840806) r385 team B (astraeus-ef8f0b8): Willow#6 idle off spawn 156 rounds at (40, 26) branch B
- `replays/batch-20261030-100127-solo-m3-solo-base-gen-cand/168-gen-monolith-only-600101500-21.repl26a` (211f690fe2e45eac) r614 team B (astraeus-ef8f0b8): Willow#8 idle off spawn 139 rounds at (29, 35) branch G

