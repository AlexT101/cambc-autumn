import gzip,json,sys,os
d=sys.argv[1]; ci=int(sys.argv[2]); a=int(sys.argv[3]); b=int(sys.argv[4])
g=[x for x in os.listdir(d) if len(x)==16][0]
R=json.load(gzip.open(f"{d}/{g}/rounds.json.gz"))
mp=json.load(open(f"{d}/maps/"+os.listdir(f"{d}/maps")[0]))
if ci==0: print(mp['width'],mp['height'],mp['symmetry'],'altars',mp['altars'],'spawn',mp['spawn'])
c=R['champions'][ci]
for i,r in enumerate(R['round']):
    if a<=r<=b: print(r,(c['x'][i],c['y'][i]),'hp',round(c['hp'][i]),'g',c['gems'][i],'ch',c['chan'][i],c['chanT'][i],'turn',c['turn'][i],'sees',c['sees'][i],'cons',c['cons'][i], 'locks',R['locks'][i])
