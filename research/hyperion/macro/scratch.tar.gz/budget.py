import json, math, collections
d = json.load(open('maps.json'))
def bits(x): return math.log2(x)
res = collections.Counter()
rows = []
for m in d:
    G = 2 * m['groups']; resp = sum(2 * (r + 1 + 16) for r in m['respawn']) + 1
    for T in (m['picks'], m['picks'] + 1):
        enemies = m['picks']
        S = m['w'] * m['h'] * enemies * 8 + 1
        for par in (0, 1):
            for E in (8, 4, 2):
                board = T * bits((G + 1) * E * 2 * (2 if par else 1))
                if board <= 64: break
            left = 64 - board
            kept = []
            for name, st in (('camp', resp), ('bag', 128 * T), ('sight', S * 16), ('second', (S - 1) * 16)):
                if name == 'second' and 'camp' not in kept: continue
                if bits(st) <= left: kept.append(name); left -= bits(st)
            rows.append((m['f'], T, par, E, tuple(kept)))
for par in (0, 1):
    print('parity', par)
    c = collections.Counter((T if T < 6 else 6, E, k) for f, T, p, E, k in rows if p == par and not f.startswith('gen-s1'))
    for k, v in sorted(c.items()): print('  ', k, v)
