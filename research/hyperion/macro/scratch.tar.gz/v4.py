import pickle, collections, statistics as st, re
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits.pkl', 'rb'))
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
# WAKE stats
W = collections.Counter(); A4 = collections.defaultdict(list); over = collections.Counter()
n = 0
for name, (fs, wk, D, wh) in games.items():
    for r, h, g, k, l in wk:
        n += 1
        site = k['site'] + '@' + (k['ctx'] if k['ctx'] != 'none' else ('farm-attack_in_range' if k['br'] == 'passing' or k['dec'] in 'F' else 'dec-' + k['dec']))
        W[(site, k['br'])] += 1
        A4[k['br']].append(int(k['allies4']))
        hp = float(k['hp'].split('/')[0])
        over[k['br']] += float(k['alone']) > hp
print('wakes', n)
for kk, c in W.most_common(15): print(' ', c, kk)
for b, v in A4.items(): print(' br', b, 'n', len(v), 'allies4=0 frac %.2f' % (sum(x == 0 for x in v) / len(v)), 'alone>hp frac %.2f' % (over[b] / len(v)))
# crew/help chips detail
def key(v):
    return (v['fs'][2]['br'] + '/' + v['fs'][2]['rsn']) if v['fs'] and v['fs'][1] == v['G'] else 'x'
for want in ['shared/c', 'help/c']:
    print('==', want, 'chips')
    for v in [v for v in allv if not v['cleared'] and key(v) == want][:12]:
        k = v['fs'][2]
        claimers = re.findall(r' a(\d+):c' + str(v['G']) + r':v(\d):d(-?\d+):hp(\d+)', v['fs'][3])
        print(f"  {v['game'][:20]} r{v['r0']}-{v['r1']} {v['name']:12s} G{v['G']} {v['types']} dealt={v['dealt']:.0f} taken={v['taken']:.0f} mates={v['mates']} foes={v['foes']} crew_out={k['crew_out']} crew_hits={k['crew_hits']} delay={k['crew_delay']} spare={k['spare']} hp={k['hp']} claimers={claimers} engaged={k['engaged']}")
