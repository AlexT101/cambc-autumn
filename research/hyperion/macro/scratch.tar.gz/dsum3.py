import pickle,statistics as st
from collections import Counter,defaultdict
res=pickle.load(open('dstate.pkl','rb'))
D=[x for r in res for x in r[4]]; G=len(res)
pc=lambda n,m: f'{100*n/m:.0f}%' if m else '-'
def recipe(x):
    if x['hpf']<.5:
        if x['cd30f']>=.3 and x['cd30']>=x['chd30']: return 'A low-from-camps'
        if x['chd30f']>=.3: return 'B low-from-earlier-fight'
        return 'C low-unhealed'
    if x['branch']=='R': return 'D healthy-retreating-caught'
    if x['branch'] in 'FG' or x['clearing']: return 'E healthy-farming'
    return 'F healthy-other'
for x in D: x['rec']=recipe(x)
def show(S,lab):
    n=len(S); print(f'\n== {lab} n={n}')
    for k,v in sorted(Counter(x['rec'] for x in S).items()):
        T=[x for x in S if x['rec']==k]
        print(f" {k:28s} {pc(v,n):>4} hpf {st.median(x['hpf'] for x in T):.2f} outnum {pc(sum(x['nk']>x['nv'] for x in T),v)} even {pc(sum(x['nk']==x['nv'] for x in T),v)} clr {pc(sum(x['clearing'] for x in T),v)} blind {pc(sum(x['blind'] for x in T),v)} ally8 {pc(sum(x['ally8']>0 for x in T),v)} ally12 {pc(sum(x['ally12']>0 for x in T),v)} dur {st.median(x['dur'] for x in T)} dur<=1 {pc(sum(x['dur']<=1 for x in T),v)} gnd {'/'.join(pc(sum(x['ground']==gg for x in T),v) for gg in ('own','mid','enemy'))} dsp {st.median(min(x['dsp'],999) for x in T)} br {''.join(f'{b}{pc(c,v)} ' for b,c in Counter(x['branch'] for x in T).most_common(3))}")
show(D,'all'); show([x for x in D if x['won']],'winners'); show([x for x in D if not x['won']],'losers')
show([x for x in D if x['r1']<=400],'r1-400'); show([x for x in D if x['r1']>400],'r401+')
# camp-softened: camp damage per game
A=[x for x in D if x['rec'].startswith('A')]
print('\ncamp-softened deaths/game %.2f; camp dmg in 30r before gank: mean %.0f med %.0f (%.2f maxhp); per game total %.0f; clearing at hit %s; walking (moved) %s'%(len(A)/G, st.mean(x['cd30'] for x in A), st.median(x['cd30'] for x in A), st.median(x['cd30f'] for x in A), sum(x['cd30']for x in A)/G, pc(sum(x['clearing'] for x in A),len(A)), pc(sum(x['moved'] and not x['clearing'] for x in A),len(A))))
for w in (True,False):
    S=[x for x in A if x['won']==w]; print(' won' if w else ' lost', '%.2f/game, dmg/game %.0f'%(len(S)/G, sum(x['cd30'] for x in S)/G))
lowc=[x for x in D if x['cd30f']>=.3]
print('any death with cd30f>=0.3: %.2f/game camp dmg/game %.0f'%(len(lowc)/G, sum(x['cd30'] for x in lowc)/G))
# per game counts
pg=defaultdict(Counter)
for x in D: pg[(x['dir'],x['won'])][x['rec']]+=1
print('\nper game (per side): winner side / loser side')
for k in sorted(set(x['rec'] for x in D)):
    print(f" {k:28s} W {sum(1 for x in D if x['rec']==k and x['won'])/G:.2f}  L {sum(1 for x in D if x['rec']==k and not x['won'])/G:.2f}")
# walking home low
wh=[x for x in D if x['branch']=='R' and x['hpf']<.5 and not x['seen5']]
print('walking home low, no enemy seen 5r:',len(wh),pc(len(wh),len(D)))
wh2=[x for x in D if x['branch']=='R' and x['hpf']<.5]
print('R & low:',pc(len(wh2),len(D)),' of those blind',pc(sum(x['blind'] for x in wh2),len(wh2)))
# allies near activity for each recipe
print()
for k in sorted(set(x['rec'] for x in D)):
    T=[x for x in D if x['rec']==k]
    a=Counter(al[2] for x in T for al in x['allies'] if al[1]<=8)
    print(k, 'ally<=8 acts', dict(a), 'ally branches', Counter(al[3] for x in T for al in x['allies'] if al[1]<=8).most_common(4))
# recalls
print('\nrecall: K kept at hit',pc(sum(x['kept_at_hit'] for x in D),len(D)),' K in window',pc(sum(x['kwin'] for x in D),len(D)), ' recall_start after hit (incl feints)',pc(sum(x['rstart']>0 for x in D),len(D)))
