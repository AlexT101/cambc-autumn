import sys, zipfile, collections
# Usage: dup.py replay.repl26a [team-a|team-b ...]
def lines(path, team):
    with zipfile.ZipFile(path) as z:
        return z.read(f'{team}.stdout').replace(b'\0', b'').decode(errors='replace').splitlines()
def analyse(path, team):
    L = lines(path, team)
    errs = [l for l in L if 'error' in l]
    rounds = collections.defaultdict(dict)
    extra = collections.defaultdict(dict)
    for l in L:
        p = l.split()
        if len(p) < 6 or p[0] != 'D': continue
        r, h, br, fg, cl = int(p[1]), int(p[2]), p[3], int(p[4]), int(p[5])
        rounds[r][h] = cl
        extra[r][h] = p[3:]
    n = dup = dup3 = 0
    claims = 0; noclaim = 0
    runs = collections.Counter(); cur = {}
    needs = 0; needrounds = collections.Counter()
    for r in sorted(rounds):
        c = collections.Counter(v for v in rounds[r].values() if v >= 0)
        n += 1
        claims += sum(1 for v in rounds[r].values() if v >= 0); noclaim += sum(1 for v in rounds[r].values() if v < 0)
        d = [g for g, k in c.items() if k >= 2]
        if d: dup += 1
        if any(k >= 3 for k in c.values()): dup3 += 1
        for g in d: cur[g] = cur.get(g, 0) + 1
        for g in list(cur):
            if g not in d: runs[cur.pop(g)] += 1
        for h, e in extra[r].items():
            if len(e) >= 6 and e[4] == '1': needs += 1; needrounds[r // 200 * 200] += 1
    runlens = sorted(runs.elements())
    mean = sum(runlens) / len(runlens) if runlens else 0
    print(f'{team}: rounds {n} dup-rounds {dup} ({100*dup/max(n,1):.0f}%) 3+ {dup3} runs {len(runlens)} mean-run {mean:.1f} max-run {max(runlens) if runlens else 0} claims {claims} none {noclaim} errors {len(errs)} need-turns {needs} {dict(sorted(needrounds.items()))}')
    for e in errs[:5]: print('  ', e)
for t in sys.argv[2:] or ['team-a', 'team-b']: analyse(sys.argv[1], t)
