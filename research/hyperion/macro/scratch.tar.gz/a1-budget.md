# Turn budget: 463 games from /home/ubuntu/cambc-autumn/replays/batch-20261030-114227-ab-m3-a1-ladder, /home/ubuntu/cambc-autumn/replays/batch-20261030-114227-ab-m3-a1-gen, /home/ubuntu/cambc-autumn/replays/batch-20261030-114227-ab-m3-a1-fresh-6035

Trace: 6 of 926 team stdouts truncated (1 MiB cap or D lines end before the last round), 0 missing; 0.0% of champion-rounds have no D line (branch `?`); 0 D-line champion ids outside the printing team.

## 1. Turn budget (% of champion-rounds)

| class | all astraeus-ef8f0b8 | all m3-a1 | r1-150 astraeus-ef8f0b8 | r1-150 m3-a1 | r151-400 astraeus-ef8f0b8 | r151-400 m3-a1 | r401-800 astraeus-ef8f0b8 | r401-800 m3-a1 | r801+ astraeus-ef8f0b8 | r801+ m3-a1 | r1-300 astraeus-ef8f0b8 | r1-300 m3-a1 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| dead | 6.2 | 5.9 | 2.7 | 2.8 | 4.9 | 4.5 | 6.0 | 5.7 | 8.2 | 7.9 | 3.6 | 3.6 |
| fight | 4.4 | 4.5 | 3.6 | 3.7 | 3.8 | 3.9 | 4.1 | 4.2 | 5.3 | 5.4 | 3.7 | 3.8 |
| tribute | 2.3 | 2.1 | 1.3 | 1.3 | 2.0 | 2.0 | 2.6 | 2.5 | 2.5 | 2.2 | 1.5 | 1.6 |
| recall | 3.7 | 3.7 | 3.1 | 3.0 | 3.9 | 3.9 | 3.8 | 3.8 | 3.6 | 3.6 | 3.5 | 3.5 |
| hold+recall | 2.7 | 2.5 | 3.1 | 2.9 | 3.6 | 3.5 | 3.0 | 2.9 | 1.8 | 1.7 | 3.3 | 3.2 |
| teleport | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.1 | 0.1 | 0.1 | 0.1 | 0.0 | 0.0 |
| camp | 14.3 | 13.5 | 24.0 | 23.1 | 18.3 | 17.8 | 14.6 | 13.8 | 8.8 | 7.9 | 21.5 | 20.6 |
| hold | 4.7 | 4.5 | 5.1 | 5.0 | 4.6 | 4.5 | 4.4 | 4.2 | 4.9 | 4.5 | 4.8 | 4.7 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 11.7 | 11.2 | 8.7 | 8.6 | 13.2 | 12.7 | 13.2 | 13.0 | 10.7 | 9.9 | 10.7 | 10.5 |
| bag->camp | 4.5 | 4.2 | 3.5 | 3.3 | 5.4 | 5.2 | 4.9 | 4.8 | 3.9 | 3.5 | 4.5 | 4.2 |
| bag-other | 3.1 | 3.2 | 1.5 | 1.7 | 2.8 | 2.8 | 3.1 | 3.3 | 3.9 | 3.8 | 2.1 | 2.2 |
| empty->camp | 24.5 | 24.5 | 31.6 | 31.6 | 24.2 | 24.9 | 24.1 | 24.2 | 22.6 | 22.2 | 28.1 | 28.3 |
| empty->spawn | 3.7 | 4.2 | 2.6 | 3.0 | 2.7 | 3.2 | 3.3 | 3.7 | 4.8 | 5.4 | 2.7 | 3.2 |
| empty-other | 7.6 | 9.1 | 5.7 | 6.8 | 5.6 | 6.7 | 6.7 | 8.0 | 9.9 | 12.0 | 5.7 | 6.7 |
| idle-off | 6.5 | 6.6 | 3.5 | 3.2 | 4.9 | 4.5 | 6.0 | 5.7 | 8.8 | 9.6 | 4.1 | 3.8 |
| idle-spawn | 0.2 | 0.1 | 0.1 | 0.0 | 0.0 | 0.0 | 0.1 | 0.0 | 0.4 | 0.2 | 0.1 | 0.0 |

By attack type (all rounds):

| class | melee astraeus-ef8f0b8 | melee m3-a1 | ranged astraeus-ef8f0b8 | ranged m3-a1 |
|---|---|---|---|---|
| dead | 6.0 | 5.7 | 6.5 | 6.3 |
| fight | 5.0 | 5.1 | 3.4 | 3.5 |
| tribute | 2.5 | 2.4 | 1.8 | 1.6 |
| recall | 3.8 | 3.8 | 3.5 | 3.5 |
| hold+recall | 2.9 | 2.8 | 2.2 | 2.1 |
| teleport | 0.0 | 0.0 | 0.1 | 0.1 |
| camp | 13.2 | 12.7 | 16.1 | 14.9 |
| hold | 4.3 | 3.9 | 5.3 | 5.5 |
| spawn-heal | 0.0 | 0.0 | 0.0 | 0.0 |
| bag->altar | 12.0 | 11.5 | 11.3 | 10.8 |
| bag->camp | 3.8 | 3.7 | 5.5 | 5.1 |
| bag-other | 3.1 | 3.1 | 3.3 | 3.3 |
| empty->camp | 25.1 | 25.1 | 23.3 | 23.5 |
| empty->spawn | 3.6 | 4.1 | 3.7 | 4.3 |
| empty-other | 8.0 | 9.5 | 6.8 | 8.5 |
| idle-off | 6.2 | 6.5 | 7.0 | 6.9 |
| idle-spawn | 0.2 | 0.1 | 0.1 | 0.2 |

By champion type (% of that type's champion-rounds; walk = all bag/empty walking):

| type | side | rounds | dead | fight | camp | hold | tribute | recall | spawn-heal | idle-spawn | idle-off | walk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cassi | astraeus-ef8f0b8 | 212663 | 6.4 | 1.8 | 15.6 | 5.3 | 1.4 | 2.7 | 0.0 | 0.0 | 6.5 | 57.1 |
| Cassi | m3-a1 | 212663 | 6.2 | 2.0 | 14.7 | 6.2 | 1.4 | 2.7 | 0.0 | 0.1 | 6.4 | 57.4 |
| Heart of Ruin | astraeus-ef8f0b8 | 498159 | 7.5 | 8.0 | 14.7 | 3.1 | 2.0 | 3.4 | 0.0 | 0.2 | 6.5 | 52.0 |
| Heart of Ruin | m3-a1 | 498159 | 6.8 | 8.2 | 13.9 | 3.1 | 2.1 | 3.3 | 0.0 | 0.1 | 6.8 | 53.3 |
| Issac | astraeus-ef8f0b8 | 212663 | 6.4 | 2.0 | 14.2 | 5.6 | 2.3 | 3.0 | 0.0 | 0.0 | 5.0 | 57.6 |
| Issac | m3-a1 | 212663 | 6.2 | 1.8 | 13.6 | 3.3 | 2.3 | 3.0 | 0.0 | 0.1 | 5.7 | 60.5 |
| Marcella | astraeus-ef8f0b8 | 515849 | 5.9 | 4.9 | 11.1 | 5.2 | 2.3 | 4.0 | 0.0 | 0.3 | 6.8 | 56.9 |
| Marcella | m3-a1 | 515849 | 5.8 | 5.0 | 10.8 | 4.9 | 2.2 | 4.1 | 0.0 | 0.1 | 6.7 | 58.0 |
| Prism | astraeus-ef8f0b8 | 232953 | 5.2 | 2.9 | 16.4 | 10.2 | 2.3 | 3.0 | 0.0 | 0.2 | 8.4 | 49.8 |
| Prism | m3-a1 | 232953 | 5.4 | 3.2 | 15.5 | 9.2 | 1.9 | 2.9 | 0.0 | 0.2 | 9.7 | 50.7 |
| Ren | astraeus-ef8f0b8 | 8410 | 1.5 | 4.1 | 21.3 | 2.9 | 2.9 | 4.1 | 0.0 | 0.0 | 1.9 | 57.8 |
| Ren | m3-a1 | 8410 | 4.4 | 4.6 | 18.2 | 1.8 | 1.8 | 4.0 | 0.0 | 0.0 | 2.5 | 60.1 |
| Ryth | astraeus-ef8f0b8 | 42359 | 8.8 | 10.5 | 11.0 | 7.4 | 3.1 | 3.7 | 0.0 | 0.1 | 3.1 | 50.1 |
| Ryth | m3-a1 | 42359 | 9.3 | 10.6 | 9.4 | 6.8 | 2.4 | 4.0 | 0.0 | 0.1 | 2.5 | 52.9 |
| Tavi | astraeus-ef8f0b8 | 59823 | 15.8 | 7.7 | 13.3 | 3.8 | 1.3 | 2.1 | 0.0 | 0.1 | 6.1 | 48.4 |
| Tavi | m3-a1 | 59823 | 13.3 | 8.0 | 12.1 | 3.5 | 1.4 | 2.2 | 0.0 | 0.1 | 5.0 | 53.2 |
| Varg | astraeus-ef8f0b8 | 36731 | 1.7 | 1.2 | 18.9 | 2.0 | 3.4 | 2.8 | 0.0 | 0.0 | 4.4 | 61.5 |
| Varg | m3-a1 | 36731 | 1.4 | 1.0 | 18.1 | 2.1 | 2.9 | 2.7 | 0.0 | 0.0 | 4.6 | 63.5 |
| Vendetta | astraeus-ef8f0b8 | 412641 | 4.5 | 3.0 | 13.2 | 3.9 | 3.4 | 4.5 | 0.0 | 0.3 | 6.4 | 57.3 |
| Vendetta | m3-a1 | 412641 | 4.1 | 3.2 | 12.7 | 3.8 | 3.2 | 4.3 | 0.0 | 0.1 | 6.7 | 58.3 |
| Vesper Vale | astraeus-ef8f0b8 | 281267 | 4.2 | 5.7 | 15.5 | 3.6 | 2.6 | 4.4 | 0.0 | 0.0 | 4.8 | 56.3 |
| Vesper Vale | m3-a1 | 281267 | 4.2 | 5.6 | 14.6 | 3.4 | 2.3 | 4.3 | 0.0 | 0.3 | 4.4 | 58.0 |
| Willow | astraeus-ef8f0b8 | 275798 | 7.9 | 2.0 | 17.3 | 3.2 | 1.1 | 3.9 | 0.0 | 0.2 | 8.7 | 53.9 |
| Willow | m3-a1 | 275798 | 7.7 | 2.0 | 15.4 | 4.2 | 1.0 | 4.0 | 0.0 | 0.1 | 8.0 | 55.9 |

Bot branch (D lines), % of champion-rounds:

| branch | all astraeus-ef8f0b8 | all m3-a1 | r1-300 astraeus-ef8f0b8 | r1-300 m3-a1 |
|---|---|---|---|---|
| `-` | 6.3 | 6.0 | 3.6 | 3.6 |
| `?` | 0.0 | 0.0 | 0.0 | 0.0 |
| `B` | 19.9 | 19.2 | 17.9 | 17.4 |
| `C` | 2.6 | 2.4 | 1.9 | 1.8 |
| `E` | 0.1 | 0.1 | 0.0 | 0.0 |
| `F` | 51.2 | 50.7 | 59.4 | 58.3 |
| `G` | 2.7 | 2.4 | 0.3 | 0.3 |
| `H` | 0.7 | 0.7 | 0.8 | 0.8 |
| `K` | 1.1 | 1.1 | 1.4 | 1.4 |
| `P` | 4.5 | 4.3 | 4.8 | 4.7 |
| `Q` | 2.0 | 2.0 | 2.6 | 2.5 |
| `R` | 6.6 | 6.2 | 5.8 | 5.2 |
| `S` | 0.0 | 0.0 | 0.0 | 0.0 |
| `T` | 1.0 | 0.9 | 0.6 | 0.6 |
| `W` | 0.0 | 0.0 | 0.0 | 0.0 |
| `X` | 0.1 | 0.0 | 0.1 | 0.1 |
| `Y` | 0.0 | 2.5 | 0.0 | 2.3 |
| `h` | 0.3 | 0.3 | 0.4 | 0.4 |
| `k` | 0.9 | 0.9 | 0.5 | 0.5 |
| `r` | 0.0 | 0.0 | 0.0 | 0.0 |

Branch x replay class (both sides pooled; % of the branch's rounds, cells under 1% blank):

| branch | n | dead | fight | tribute | recall | hold+recall | teleport | camp | hold | spawn-heal | bag->altar | bag->camp | bag-other | empty->camp | empty->spawn | empty-other | idle-off | idle-spawn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `-` | 341610 | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `?` | 1917 | 7 | 4 | 23 |  |  |  |  | 4 |  |  |  |  | 2 | 2 | 3 | 51 | 2 |
| `B` | 1089912 |  | 2 | 3 | 2 |  |  | 11 |  |  | 49 | 13 | 9 |  |  |  | 8 |  |
| `C` | 139479 |  | 18 |  |  |  |  |  |  |  | 11 | 4 | 12 | 18 | 5 | 30 |  |  |
| `E` | 7380 |  | 33 |  |  |  |  |  |  |  | 9 |  | 3 | 4 | 2 | 28 | 6 | 15 |
| `F` | 2842132 |  | 4 | 1 |  |  |  | 22 | 1 |  | 3 | 3 |  | 42 | 3 | 11 | 8 |  |
| `G` | 141473 |  | 4 |  |  |  |  | 10 |  |  | 3 |  |  | 22 | 14 | 23 | 24 |  |
| `H` | 40197 |  |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `K` | 62900 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `P` | 245844 |  | 1 |  |  | 10 |  | 2 | 87 |  |  |  |  |  |  |  |  |  |
| `Q` | 111481 |  |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |
| `R` | 356922 |  | 24 |  | 5 |  |  |  |  |  | 3 | 4 | 9 | 20 | 27 | 6 |  |  |
| `S` | 1848 |  | 3 | 38 | 4 |  |  |  |  |  | 3 | 4 | 8 | 9 | 30 |  |  |  |
| `T` | 54902 |  |  | 99 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `W` | 644 |  | 15 |  |  |  |  |  |  |  |  |  |  |  |  |  | 84 |  |
| `X` | 2793 |  | 9 |  |  |  |  |  | 14 |  | 2 |  | 1 | 33 | 3 | 36 |  |  |
| `Y` | 70578 |  | 2 |  |  |  |  |  |  |  |  |  |  | 34 | 9 | 48 | 4 |  |
| `h` | 14203 |  | 1 |  |  |  |  | 5 |  |  |  |  |  | 22 | 11 | 15 | 46 |  |
| `k` | 52181 |  |  |  | 100 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| `r` | 236 |  | 18 |  | 2 |  |  | 2 |  |  | 13 | 6 | 13 | 5 | 11 | 2 | 29 |  |

Replay class -> bot branches (pooled; % of the class's rounds, top 4):

| class | n | branches |
|---|---|---|
| dead | 338440 | `-` 100, `?` 0, `F` 0, `B` 0 |
| fight | 249922 | `F` 40, `R` 34, `B` 10, `C` 10 |
| tribute | 122003 | `T` 45, `B` 28, `F` 25, `S` 1 |
| recall | 204252 | `K` 31, `k` 25, `H` 20, `R` 10 |
| hold+recall | 145366 | `Q` 77, `P` 16, `F` 6, `B` 1 |
| teleport | 3072 | `F` 64, `B` 33, `C` 1, `R` 1 |
| camp | 776022 | `F` 82, `B` 16, `G` 2, `P` 1 |
| hold | 255700 | `P` 84, `F` 13, `B` 3, `R` 0 |
| spawn-heal | 59 | `H` 75, `F` 19, `B` 5, `Y` 2 |
| bag->altar | 639671 | `B` 83, `F` 12, `C` 2, `R` 2 |
| bag->camp | 241873 | `B` 61, `F` 31, `R` 6, `C` 2 |
| bag-other | 176887 | `B` 57, `R` 19, `F` 13, `C` 10 |
| empty->camp | 1365243 | `F` 88, `R` 5, `G` 2, `C` 2 |
| empty->spawn | 218586 | `R` 44, `F` 39, `G` 9, `C` 3 |
| empty-other | 465431 | `F` 70, `C` 9, `Y` 7, `G` 7 |
| idle-off | 367597 | `F` 62, `B` 25, `G` 9, `h` 2 |
| idle-spawn | 8508 | `F` 75, `E` 13, `B` 9, `G` 1 |

## 2. Earnings (per game per side unless noted)

| metric | astraeus-ef8f0b8 | m3-a1 |
|---|---|---|
| gems captured | 861 | 802 |
| gems tributed | 774 | 735 |
| gems taken by kills | 88.0 | 87.9 |
| gems lost at death to champions | 87.3 | 76.9 |
| gems lost at death to camps | 4.7 | 4.2 |
| gold earned (lifetime) | 5702 | 5347 |
| r1-300 gems captured | 177 | 178 |
| r1-300 gems tributed | 115 | 119 |
| r1-300 gems lost at death | 6.4 | 5.5 |
| gems captured per camp-hit round | 1.0 | 1.0 |
| gems captured per hold round | 3.0 | 3.0 |
| gems captured per (camp+hold) round | 0.8 | 0.7 |
| gems tributed per 100 alive rounds | 13.7 | 13.0 |
| mean bag carried per alive round | 17.3 | 18.6 |
| % alive rounds carrying 30+ | 13.4 | 13.0 |
| tributes per 1000 alive rounds | 6.6 | 6.3 |
| mean bag at tribute | 20.6 | 20.6 |
| walk steps per tributed gem | 5.2 | 5.6 |
| bag-walk rounds per tributed gem | 1.5 | 1.5 |
| bag-walk rounds just before a tribute (mean trip) | 7.9 | 7.9 |
| idle-off rounds in stretches of 50+ (% of idle-off) | 18.1 | 27.6 |
| idle-off rounds in 50+ stretches by branch at its start, per game | `F` 24.4, `G` 23.4, `B` 22.3, `E` 0.5 | `B` 43.8, `F` 43.5, `G` 19.1, `h` 3.4 |
| altar locks placed / tribute attempts blocked, per game | 4.32 / 0.00 | 4.20 / 0.00 |
| real recalls per game (completed) | 70.1 (59.8) | 68.6 (58.3) |
| tribute cancels per game (cause) | death 0.02, lock 0.32, manual 0.19, stun 0.29 | death 0.02, lock 0.32, manual 0.20, stun 0.23 |

By phase:

| per game | side | r1-150 | r151-400 | r401-800 | r801+ |
|---|---|---|---|---|---|
| gems captured | astraeus-ef8f0b8 | 80.3 | 170 | 307 | 304 |
| gems captured | m3-a1 | 80.7 | 169 | 290 | 262 |
| gems tributed | astraeus-ef8f0b8 | 43.8 | 133 | 274 | 323 |
| gems tributed | m3-a1 | 46.5 | 131 | 272 | 286 |
| alive champion-rounds | astraeus-ef8f0b8 | 707 | 1150 | 1708 | 2085 |
| alive champion-rounds | m3-a1 | 706 | 1155 | 1714 | 2092 |

Real recalls (completed or lasting 2+ rounds; feints excluded) by the branch at their start:

| side | `P` | `R` | `F` | `B` | `G` | `S` | `C` | `Y` | `E` | `X` | `W` | `?` |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 25.8/g, 94.8% done, 22.3% bag, 22.2 from spawn | 19.3/g, 81.2% done, 28.1% bag, 23.5 from spawn | 14.1/g, 71.1% done, 10.9% bag, 27.1 from spawn | 8.6/g, 92.1% done, 100.0% bag, 16.8 from spawn | 0.9/g, 68.2% done, 10.4% bag, 22.3 from spawn | 0.8/g, 94.9% done, 1.5% bag, 40.2 from spawn | 0.4/g, 67.3% done, 69.2% bag, 34.7 from spawn | - | 0.0/g, 50.0% done, 50.0% bag, 50.2 from spawn | 0.0/g, 100.0% done, 0.0% bag, 9.0 from spawn | 0.0/g, 50.0% done, 100.0% bag, 30.5 from spawn | - |
| m3-a1 | 24.6/g, 94.2% done, 21.9% bag, 22.4 from spawn | 19.3/g, 80.1% done, 27.9% bag, 24.1 from spawn | 13.6/g, 73.3% done, 11.0% bag, 28.1 from spawn | 8.9/g, 91.4% done, 100.0% bag, 17.7 from spawn | 0.8/g, 68.1% done, 10.0% bag, 22.6 from spawn | 0.7/g, 91.0% done, 0.6% bag, 38.3 from spawn | 0.5/g, 59.5% done, 74.0% bag, 32.2 from spawn | 0.2/g, 42.9% done, 0.0% bag, 21.3 from spawn | 0.0/g, 0.0% done, 0.0% bag, 23.0 from spawn | 0.0/g, 33.3% done, 0.0% bag, 24.3 from spawn | - | 0.0/g, 100.0% done, 0.0% bag, 23.0 from spawn |

Bag size at tribute (% of tributes): astraeus-ef8f0b8: 0-19 70.1, 20-39 17.4, 40-59 8.0, 60-79 2.3, 80-99 0.8, 100+ 1.4; m3-a1: 0-19 70.7, 20-39 17.0, 40-59 8.0, 60-79 2.2, 80-99 0.8, 100+ 1.4

## 3. Clears and captures

| group type | hitters | n | champ-turns | rounds | turns/gem | r1-300 turns/gem (n) | camp dmg/gem | own capture % | stolen % | uncaptured % | holders at payout | clear->payout | resets/clear | enemy also hit % |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Monolith | 2 | 16 | 38.9 | 90.1 | 0.22 | - | 34.0 | 100 | 0.0 | 0.0 | 1.1 | 7.8 | 0.00 | 12.5 |
| Monolith | 3+ | 99 | 86.5 | 96.2 | 0.40 | - | 28.4 | 94.9 | 4.0 | 1.0 | 1.6 | 5.6 | 0.03 | 38.4 |
| Golem | 1 | 227 | 14.5 | 35.4 | 0.34 | 0.11 (2) | 25.4 | 93.0 | 4.8 | 2.2 | 1.0 | 6.5 | 0.01 | 23.3 |
| Golem | 2 | 415 | 24.9 | 47.9 | 0.57 | 0.54 (4) | 35.9 | 97.8 | 1.7 | 0.5 | 1.0 | 6.5 | 0.05 | 12.5 |
| Golem | 3+ | 899 | 47.6 | 73.6 | 0.98 | 1.74 (178) | 61.2 | 98.1 | 1.3 | 0.6 | 1.1 | 6.4 | 0.05 | 14.5 |
| Elk | 1 | 3112 | 13.4 | 27.8 | 0.61 | 0.81 (126) | 26.2 | 96.8 | 1.9 | 1.3 | 1.0 | 7.1 | 0.02 | 11.2 |
| Elk | 2 | 4052 | 21.5 | 33.5 | 0.91 | 1.34 (808) | 35.1 | 98.4 | 1.3 | 0.3 | 1.0 | 6.5 | 0.04 | 7.8 |
| Elk | 3+ | 3966 | 29.9 | 34.1 | 1.02 | 1.38 (1583) | 36.8 | 98.0 | 1.7 | 0.3 | 1.1 | 6.2 | 0.06 | 10.9 |
| Wolf | 1 | 9431 | 11.5 | 16.5 | 1.30 | 1.83 (1416) | 21.8 | 97.9 | 1.5 | 0.6 | 1.0 | 6.9 | 0.14 | 4.9 |
| Wolf | 2 | 7431 | 16.4 | 23.4 | 1.88 | 2.75 (1854) | 29.1 | 98.6 | 1.1 | 0.2 | 1.0 | 6.4 | 0.03 | 4.5 |
| Wolf | 3+ | 4151 | 24.0 | 25.2 | 2.17 | 2.82 (1789) | 32.7 | 98.8 | 1.0 | 0.2 | 1.0 | 6.4 | 0.04 | 4.9 |
| GemCl | 1 | 14470 | 2.6 | 2.6 | 0.18 | 0.23 (3833) | 0.0 | 97.0 | 2.3 | 0.7 | 1.0 | 7.6 | 0.06 | 2.2 |
| GemCl | 2 | 2843 | 4.0 | 6.6 | 0.21 | 0.23 (727) | 0.0 | 97.3 | 2.1 | 0.6 | 1.0 | 6.9 | 0.08 | 4.5 |
| GemCl | 3+ | 608 | 6.2 | 4.9 | 0.21 | 0.20 (180) | 0.0 | 96.5 | 2.5 | 1.0 | 1.1 | 7.5 | 0.20 | 8.2 |
| GoldCl | 1 | 16648 | 2.6 | 3.9 | 0.32 | 0.50 (5121) | 0.0 | 96.5 | 2.2 | 1.4 | 1.0 | 9.5 | 0.04 | 2.3 |
| GoldCl | 2 | 2769 | 3.3 | 19.2 | 0.39 | 0.56 (1052) | 0.0 | 97.2 | 1.7 | 1.1 | 1.0 | 9.1 | 0.05 | 3.0 |
| GoldCl | 3+ | 255 | 4.8 | 17.0 | 0.94 | 4.21 (118) | 0.0 | 94.5 | 3.9 | 1.6 | 1.0 | 8.9 | 0.13 | 5.1 |

| side | clears/game | solo % | turns/gem | camp dmg/gem | own capture % | stolen from % | steals/game | holders at payout | clear->payout | resets/clear | contested/clear | camp deaths/clear |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 79.6 | 61.4 | 0.73 | 18.7 | 97.4 | 1.9 | 1.27 | 1.0 | 7.6 | 0.07 | 0.01 | 0.005 |
| m3-a1 | 74.6 | 61.6 | 0.76 | 19.0 | 97.5 | 1.7 | 1.54 | 1.0 | 7.6 | 0.05 | 0.00 | 0.005 |

Clears per game by group side (relative to the clearing team) and type:

| side | own Wolf | own Elk | own Golem | own Monolith | own GemCl | own GoldCl | mid Wolf | mid Elk | mid Golem | mid Monolith | mid GemCl | mid GoldCl | enemy Wolf | enemy Elk | enemy Golem | enemy Monolith | enemy GemCl | enemy GoldCl |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 20.29 | 9.92 | 1.36 | 0.06 | 15.88 | 19.37 | 1.75 | 1.50 | 0.13 | 0.06 | 1.98 | 1.15 | 1.32 | 1.18 | 0.19 | 0.02 | 1.97 | 1.43 |
| m3-a1 | 19.03 | 9.33 | 1.31 | 0.05 | 15.03 | 18.29 | 1.62 | 1.17 | 0.12 | 0.04 | 1.86 | 1.06 | 1.36 | 0.94 | 0.21 | 0.02 | 1.98 | 1.18 |

## 4. Supply (% of gem-weighted group-rounds in each state, groups by side relative to the team)

`asleep` = monsters up and asleep (nobody within range for 2 camp phases): available, unworked. `unclaimed` = cleared, nobody holding.

all:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 62.5 | 6.7 | 2.9 | 2.0 | 25.8 |
| astraeus-ef8f0b8 | mid | 73.2 | 7.6 | 1.9 | 1.2 | 16.2 |
| astraeus-ef8f0b8 | enemy | 64.4 | 6.8 | 2.2 | 1.9 | 24.6 |
| m3-a1 | own | 64.4 | 6.8 | 2.2 | 1.9 | 24.6 |
| m3-a1 | mid | 73.2 | 7.6 | 1.9 | 1.2 | 16.2 |
| m3-a1 | enemy | 62.5 | 6.7 | 2.9 | 2.0 | 25.8 |

r1-300:

| side | groups | asleep | awake | unclaimed | held | respawn |
|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | own | 67.6 | 7.4 | 1.7 | 2.2 | 21.1 |
| astraeus-ef8f0b8 | mid | 82.2 | 6.0 | 1.1 | 1.1 | 9.6 |
| astraeus-ef8f0b8 | enemy | 68.0 | 7.4 | 1.7 | 2.2 | 20.7 |
| m3-a1 | own | 68.0 | 7.4 | 1.7 | 2.2 | 20.7 |
| m3-a1 | mid | 82.2 | 6.0 | 1.1 | 1.1 | 9.6 |
| m3-a1 | enemy | 67.6 | 7.4 | 1.7 | 2.2 | 21.1 |

By group type (unweighted % of group-rounds; own/mid/enemy relative to the side):

| side | type | own asleep | own awake | own unclaimed | mid asleep | mid awake | mid unclaimed | enemy asleep | enemy awake | enemy unclaimed |
|---|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | Wolf | 57.8 | 8.6 | 2.0 | 65.8 | 8.6 | 2.2 | 60.1 | 8.6 | 1.7 |
| m3-a1 | Wolf | 60.1 | 8.6 | 1.7 | 65.8 | 8.6 | 2.2 | 57.8 | 8.6 | 2.0 |
| astraeus-ef8f0b8 | Elk | 49.6 | 10.8 | 1.7 | 52.2 | 14.1 | 2.3 | 50.8 | 10.9 | 1.5 |
| m3-a1 | Elk | 50.8 | 10.9 | 1.5 | 52.2 | 14.1 | 2.3 | 49.6 | 10.8 | 1.7 |
| astraeus-ef8f0b8 | Golem | 59.2 | 10.3 | 1.0 | 74.2 | 10.2 | 0.7 | 61.3 | 9.9 | 1.0 |
| m3-a1 | Golem | 61.3 | 9.9 | 1.0 | 74.2 | 10.2 | 0.7 | 59.2 | 10.3 | 1.0 |
| astraeus-ef8f0b8 | Monolith | 93.6 | 2.8 | 0.1 | 90.6 | 3.2 | 0.2 | 94.1 | 2.5 | 0.1 |
| m3-a1 | Monolith | 94.1 | 2.5 | 0.1 | 90.6 | 3.2 | 0.2 | 93.6 | 2.8 | 0.1 |
| astraeus-ef8f0b8 | GemCl | 34.9 | 2.3 | 4.8 | 43.2 | 4.4 | 5.2 | 37.8 | 2.5 | 4.4 |
| m3-a1 | GemCl | 37.8 | 2.5 | 4.4 | 43.2 | 4.4 | 5.2 | 34.9 | 2.3 | 4.8 |
| astraeus-ef8f0b8 | GoldCl | 49.8 | 1.8 | 7.1 | 68.2 | 1.8 | 4.2 | 52.0 | 1.9 | 6.5 |
| m3-a1 | GoldCl | 52.0 | 1.9 | 6.5 | 68.2 | 1.8 | 4.2 | 49.8 | 1.8 | 7.1 |

Upper bound on gems left asleep per game (each asleep round = 1/(respawn+15) of a farm cycle): astraeus-ef8f0b8: own 1258, mid 714, enemy 1299; m3-a1: own 1299, mid 714, enemy 1258

| side | own captures/game (gems) | mid captures/game (gems) | enemy captures/game (gems) | r1-300 own/mid/enemy |
|---|---|---|---|---|
| astraeus-ef8f0b8 | 66.4 (637) | 6.4 (135) | 5.9 (89) | 17.6/1.3/1.2 |
| m3-a1 | 62.7 (603) | 5.9 (117) | 5.6 (82) | 17.1/1.2/1.1 |

## 5. Deaths

| metric | astraeus-ef8f0b8 | m3-a1 |
|---|---|---|
| deaths/game (to champions + camps) | 5.2 + 0.68 | 5.0 + 0.66 |
| median first-death round (none = length+1) | 345 | 346 |
| % of games this side died first | 45.1 | 44.1 |
| % alone (no ally within 8) | 29.3 | 27.6 |
| % ally within 4 | 46.8 | 51.1 |
| % 2+ enemies within 8 | 73.2 | 70.7 |
| % on own ground | 61.1 | 53.7 |
| % on mid ground | 18.3 | 21.7 |
| % on enemy ground | 20.6 | 24.5 |
| % walking toward spawn (last 4 rounds) | 37.3 | 36.5 |
| % branch R in last 4 rounds | 88.2 | 86.4 |
| % carrying 30+ gems | 12.0 | 10.5 |
| mean enemies within 8 | 2.5 | 2.4 |
| mean gems carried at death | 14.9 | 14.1 |
| r1-300 deaths/game | 0.90 | 0.91 |

Gems lost at death by champion type, per game (% of the side's loss): astraeus-ef8f0b8: Prism 30.7 (35.2%), Vendetta 17.7 (20.2%), Marcella 13.5 (15.5%), Heart of Ruin 10.6 (12.1%); m3-a1: Prism 27.1 (34.2%), Vendetta 14.7 (18.6%), Marcella 12.5 (15.8%), Heart of Ruin 8.0 (10.1%)

Deaths carrying 100+ gems: astraeus-ef8f0b8 0.16/game holding 56.4% of gems lost; m3-a1 0.14/game holding 57.9% of gems lost

Branch at death (last D line): astraeus-ef8f0b8: `R` 82.5%, `F` 7.3%, `E` 5.2%, `B` 2.8%, `K` 0.8%, `C` 0.4%; m3-a1: `R` 81.0%, `E` 8.4%, `F` 6.8%, `B` 1.1%, `K` 0.9%, `G` 0.4%

Deaths by (allies within 8, enemies within 8), per 10 games:

| side | allies\enemies | 0 | 1 | 2 | 3+ |
|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 0 | 0.5 | 5.8 | 4.9 | 5.9 |
| astraeus-ef8f0b8 | 1 | 0.9 | 3.5 | 5.0 | 6.3 |
| astraeus-ef8f0b8 | 2 | 0.9 | 2.0 | 3.3 | 6.6 |
| astraeus-ef8f0b8 | 3+ | 1.1 | 1.1 | 1.9 | 8.8 |
| m3-a1 | 0 | 0.5 | 5.5 | 4.9 | 4.6 |
| m3-a1 | 1 | 1.0 | 4.0 | 4.7 | 5.7 |
| m3-a1 | 2 | 0.7 | 2.7 | 3.8 | 5.8 |
| m3-a1 | 3+ | 0.8 | 1.2 | 2.1 | 8.1 |

## 6. Kills and fights

| side | kills/game | r1-300 kills/game | fights/game | initiated % | won on kills % | lost on kills % | net bag gems/game |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 5.0 | 0.65 | 41.5 | 49.8 | 10.3 | 11.1 | -8.0 |
| m3-a1 | 5.2 | 0.66 | 41.5 | 50.2 | 11.1 | 10.3 | 8.0 |

By fight size (participants, side v enemy): fights per game, then net kills per fight (killed - lost):

| side | 1v1 | 1v2 | 1v3+ | 2v1 | 2v2 | 2v3+ | 3+v1 | 3+v2 | 3+v3+ |
|---|---|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 23.70 / -0.00 | 3.91 / -0.12 | 1.02 / -0.24 | 3.50 / +0.11 | 2.98 / +0.01 | 1.63 / -0.11 | 0.70 / +0.24 | 1.24 / +0.10 | 2.81 / -0.00 |
| m3-a1 | 23.70 / +0.00 | 3.50 / -0.11 | 0.70 / -0.24 | 3.91 / +0.12 | 2.98 / -0.01 | 1.24 / -0.10 | 1.02 / +0.24 | 1.63 / +0.11 | 2.81 / +0.00 |
| pooled | 23.70 / +0.00 | 3.70 / -0.11 | 0.86 / -0.24 | 3.70 / +0.11 | 2.98 / +0.00 | 1.44 / -0.11 | 0.86 / +0.24 | 1.44 / +0.11 | 2.81 / +0.00 |

By head-count difference at the start (own minus enemy champions alive within 8 of the fight, previous round end): fights per game / net kills per fight / % won on kills:

| side | -3 | -2 | -1 | 0 | 1 | 2 | 3 |
|---|---|---|---|---|---|---|---|
| astraeus-ef8f0b8 | 1.10 / -0.15 / 9.6 | 3.26 / -0.03 / 8.7 | 9.09 / -0.02 / 8.6 | 15.41 / +0.00 / 9.7 | 8.68 / +0.01 / 11.4 | 3.06 / +0.03 / 13.6 | 0.89 / +0.08 / 22.7 |
| m3-a1 | 0.89 / -0.08 / 13.8 | 3.06 / -0.03 / 10.5 | 8.68 / -0.01 / 10.3 | 15.41 / -0.00 / 9.8 | 9.09 / +0.02 / 11.8 | 3.26 / +0.03 / 12.3 | 1.10 / +0.15 / 24.5 |
| pooled | 1.00 / -0.12 / 11.5 | 3.16 / -0.03 / 9.6 | 8.89 / -0.02 / 9.4 | 15.41 / +0.00 / 9.7 | 8.89 / +0.02 / 11.6 | 3.16 / +0.03 / 12.9 | 1.00 / +0.12 / 23.7 |

## 7. What decides games

| gems, round | games reaching it | tied | leader wins % | lead 1-49 | lead 50-149 | lead 150+ |
|---|---|---|---|---|---|---|
| tributed r200 | 463 | 85 | 62.7 | 58.1 (n=296) | 79.5 (n=73) | 77.8 (n=9) |
| tributed r400 | 460 | 35 | 67.1 | 57.9 (n=235) | 76.6 (n=145) | 84.4 (n=45) |
| tributed r600 | 441 | 23 | 73.0 | 60.9 (n=184) | 79.2 (n=149) | 88.2 (n=85) |
| tributed+carried r200 | 463 | 63 | 65.0 | 60.3 (n=312) | 81.1 (n=74) | 85.7 (n=14) |
| tributed+carried r400 | 460 | 25 | 72.9 | 62.2 (n=251) | 83.2 (n=119) | 95.4 (n=65) |
| tributed+carried r600 | 441 | 13 | 76.9 | 68.0 (n=194) | 77.0 (n=122) | 92.0 (n=112) |

| predictor | win % |
|---|---|
| team that did not die first wins | 62.5 (n=413) |
| more kills wins | 84.9 (n=358) |
| more r1-300 kills wins | 67.7 (n=223) |
| more gems captured wins | 89.2 (n=462) |
| more r1-300 gems captured wins | 66.9 (n=423) |
| fewer gems lost at death wins | 82.8 (n=303) |
| more mid-group captures wins | 80.5 (n=195) |

Games where neither side tributes 200: 9 (gen-archipelago-603502017, gen-arena-603502615, gen-arena-603502620, mut-the-line-603501835, the-pack).

Game length: median 1169, quartiles 906-1660, min 314, max 2000; 16.6% reach round 2000; 83.4% end on 1000 gems.

## Examples

**bagdeath** (204 in all, largest first, one per game):

- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/442-gen-tunnels-603504307-21.repl26a` (d4b6afeff8c72af5) r1912 team B (m3-a1): Prism died with 2479 gems (champ, allies<=8 5, enemies<=8 1, branch B)
- `replays/batch-20261030-114227-ab-m3-a1-ladder/074-01boss-battle-21.repl26a` (58c7d5284ee98141) r569 team B (m3-a1): Vesper Vale died with 1222 gems (champ, allies<=8 4, enemies<=8 2, branch R)
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/020-gen-archipelago-603502017-21.repl26a` (0cc7e3b00094c294) r1790 team A (astraeus-ef8f0b8): Vesper Vale died with 1220 gems (champ, allies<=8 0, enemies<=8 1, branch E)
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/019-gen-archipelago-603502017-12.repl26a` (951538e84b1b7c74) r1675 team B (astraeus-ef8f0b8): Vendetta died with 1156 gems (champ, allies<=8 1, enemies<=8 1, branch E)
- `replays/batch-20261030-114227-ab-m3-a1-ladder/139-adgato-gemcombat5-12.repl26a` (01cfdd09bfd13dcd) r1047 team B (astraeus-ef8f0b8): Prism died with 991 gems (champ, allies<=8 1, enemies<=8 1, branch T)
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/441-gen-tunnels-603504307-12.repl26a` (8b23c3d4e4079895) r1024 team B (astraeus-ef8f0b8): Prism died with 679 gems (champ, allies<=8 1, enemies<=8 6, branch B)

**stolen** (1302 in all, largest first, one per game):

- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/039-gen-arena-603502615-12.repl26a` (1b567d79edfe771e) r272 team B (astraeus-ef8f0b8): GoldCl (428 gems, own) cleared r263 stolen
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/040-gen-arena-603502615-21.repl26a` (06a77f2960f69a81) r695 team A (astraeus-ef8f0b8): GoldCl (428 gems, enemy) cleared r678 stolen
- `replays/batch-20261030-114227-ab-m3-a1-ladder/073-01boss-battle-12.repl26a` (226ddf2aa7270f60) r450 team B (astraeus-ef8f0b8): Monolith (400 gems, mid) cleared r434 stolen
- `replays/batch-20261030-114227-ab-m3-a1-ladder/074-01boss-battle-21.repl26a` (58c7d5284ee98141) r444 team B (m3-a1): Monolith (400 gems, mid) cleared r434 stolen
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/295-gen-huge-shared-603505208-12.repl26a` (6149ea8bb9d43a9a) r190 team B (astraeus-ef8f0b8): GemCl (400 gems, mid) cleared r173 stolen
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/296-gen-huge-shared-603505208-21.repl26a` (0b12dd4fbe5cc5f3) r489 team B (m3-a1): GemCl (400 gems, mid) cleared r478 stolen

**idle-off30** (632 in all, largest first, one per game):

- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/016-gen-archipelago-603502014-21.repl26a` (ae3f0395ea488787) r275 team B (m3-a1): Heart of Ruin#9 idle off spawn 1726 rounds at (29, 10) branch B
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/015-gen-archipelago-603502014-12.repl26a` (db60f4c1c9b5902e) r364 team B (astraeus-ef8f0b8): Willow#8 idle off spawn 1637 rounds at (28, 10) branch F
- `replays/batch-20261030-114227-ab-m3-a1-gen/019-gen-archipelago-600102011-12.repl26a` (3e5ebe7e43ea0783) r438 team A (m3-a1): Heart of Ruin#4 idle off spawn 1543 rounds at (14, 29) branch B
- `replays/batch-20261030-114227-ab-m3-a1-fresh-6035/441-gen-tunnels-603504307-12.repl26a` (8b23c3d4e4079895) r540 team A (m3-a1): Vendetta#0 idle off spawn 1461 rounds at (42, 38) branch F
- `replays/batch-20261030-114227-ab-m3-a1-gen/061-gen-atoll-600101919-12.repl26a` (011fa60bfe6e37e4) r622 team B (astraeus-ef8f0b8): Heart of Ruin#5 idle off spawn 1379 rounds at (35, 5) branch G
- `replays/batch-20261030-114227-ab-m3-a1-gen/062-gen-atoll-600101919-21.repl26a` (54bc1317bcc20fa8) r674 team A (astraeus-ef8f0b8): Heart of Ruin#2 idle off spawn 1327 rounds at (43, 68) branch G

