import pickle,statistics as st
from collections import Counter
res=pickle.load(open('dstate.pkl','rb'))
D=[x for r in res for x in r[4]]
G=len(res)
print('games',G,'champ-kill deaths',len(D),'per game %.2f'%(len(D)/G))
print('camp deaths per game %.2f'%(sum(sum(r[6].values()) for r in res)/G))
for b in ('ladder','gen','fresh-gen-s1'):
    rr=[r for r in res if r[1]==b]; print(b,len(rr),'%.2f'%(sum(len(r[4]) for r in rr)/len(rr)))
def q(xs):
    xs=sorted(xs); n=len(xs)
    return f'med {xs[n//2]:.2f} q25 {xs[n//4]:.2f} q75 {xs[3*n//4]:.2f}' if n else '-'
def pc(n,m): return f'{100*n/m:.0f}%' if m else '-'
def summ(S,lab):
    n=len(S)
    print(f'\n== {lab} n={n} ({n/G:.2f}/game)')
    print(' hpf at first hit',q([x['hpf'] for x in S]),' <50%:',pc(sum(x['hpf']<.5 for x in S),n),' <30%:',pc(sum(x['hpf']<.3 for x in S),n))
    print(' camp dmg 30r (frac maxhp)',q([x['cd30f'] for x in S]),' >=0.3:',pc(sum(x['cd30f']>=.3 for x in S),n),' champ dmg 30r>=0.3',pc(sum(x['chd30f']>=.3 for x in S),n))
    print(' clearing at hit',pc(sum(x['clearing'] for x in S),n),' blind',pc(sum(x['blind'] for x in S),n))
    print(' branch',' '.join(f'{k}:{pc(v,n)}' for k,v in Counter(x['branch'] for x in S).most_common()))
    print(' ground',' '.join(f'{k}:{pc(v,n)}' for k,v in Counter(x['ground'] for x in S).most_common()))
    print(' dspawn',q([min(x['dsp'],999) for x in S]))
    print(' killers>victims within8',pc(sum(x['nk']>x['nv'] for x in S),n),' equal',pc(sum(x['nk']==x['nv'] for x in S),n),' fewer',pc(sum(x['nk']<x['nv'] for x in S),n))
    print(' nk',Counter(x['nk'] for x in S).most_common(),' nv',Counter(x['nv'] for x in S).most_common())
    print(' ally<=8',pc(sum(x['ally8']>0 for x in S),n),' ally<=12',pc(sum(x['ally12']>0 for x in S),n))
    acts=Counter(a[2] for x in S for a in x['allies'] if a[1]<=12); print(' ally acts (<=12)',acts.most_common(), Counter(a[3] for x in S for a in x['allies']).most_common())
    print(' dur first hit->death',q([x['dur'] for x in S]),' 0-1r',pc(sum(x['dur']<=1 for x in S),n),' attackers',Counter(x['attackers'] for x in S).most_common())
    print(' recall active at hit',pc(sum(x['rec_active'] for x in S),n),' recall started after',pc(sum(x['rstart']>0 for x in S),n),' cancel by dmg',pc(sum(x['rcancel_dmg']>0 for x in S),n),' tributing',pc(sum(x['trib'] for x in S),n))
    print(' gems',q([x['gems'] for x in S]))
summ(D,'all')
summ([x for x in D if x['won']],'winners')
summ([x for x in D if not x['won']],'losers')
summ([x for x in D if x['r1']<=400],'r1-400')
summ([x for x in D if x['r1']>400],'r401+')
