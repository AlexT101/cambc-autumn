import gzip, json, os, re, sys, zipfile, glob
A = '/tmp/claude-1000/m4-rta/analysis'
idx = json.load(open(A + '/index.json'))
src2dir = {os.path.abspath(os.path.join('/home/ubuntu/cambc-autumn', g['source'])) if not os.path.isabs(g['source']) else g['source']: g['dir'] for g in idx['games']}
fires = []
games = 0
for path, gdir in src2dir.items():
    if '/base/' in path: continue
    games += 1
    team = 0 if os.path.basename(path).startswith('m4-rta-vs') else 1
    out = zipfile.ZipFile(path).read('team-%s.stdout' % 'ab'[team]).decode('latin1')
    lines = [l.split() for l in out.splitlines() if l.startswith('RTA ')]
    if not lines: continue
    d = os.path.join(A, gdir)
    ev = [json.loads(l) for l in gzip.open(d + '/events.jsonl.gz', 'rt')]
    rounds = json.load(gzip.open(d + '/rounds.json.gz'))
    meta = json.load(open(d + '/meta.json'))
    team_of = {c['id']: c['team'] for c in meta['champions']}
    name = {c['id']: c['name'] for c in meta['champions']}
    rix = {r: i for i, r in enumerate(rounds['round'])}
    champs = {c['id']: c for c in rounds['champions']}
    for l in lines:
        r, h, a = int(l[1]), int(l[2]), int(l[3])
        here = (int(l[4]), int(l[5])); allyp = (int(l[6]), int(l[7]))
        i = rix[r]
        c = champs[h]
        # sanity: replay position at the round's end-state vs the trace's turn start (may differ by our step)
        W = range(r, r + 11)
        died = [e['r'] for e in ev if e['k'] == 'death' and e['v'] == h and e['r'] in W]
        ally_died = [e['r'] for e in ev if e['k'] == 'death' and e['v'] == a and e['r'] in W]
        enemy_deaths = [e for e in ev if e['k'] == 'death' and team_of.get(e['v']) != team and e['r'] in W]
        def hits(who):
            n, dmg = 0, 0.0
            for e in ev:
                if e['r'] in W and e.get('a') == who and e['k'] in ('attack', 'cast'):
                    for v, x in e.get('dmg', []):
                        if team_of.get(v) is not None and team_of[v] != team: n += 1; dmg += x
            return n, dmg
        taken = 0.0
        for e in ev:
            if e['r'] in W and e['k'] in ('attack', 'cast') and team_of.get(e.get('a')) not in (None, team):
                for v, x in e.get('dmg', []):
                    if v == h: taken += x
        # distance to ally 1 and 3 rounds later
        def dist_at(rr):
            j = rix.get(rr)
            if j is None: return None
            x1, y1, x2, y2 = champs[h]['x'][j], champs[h]['y'][j], champs[a]['x'][j], champs[a]['y'][j]
            if None in (x1, y1, x2, y2): return None
            return max(abs(x1 - x2), abs(y1 - y2))
        recall_end = [e['r'] for e in ev if e['k'] == 'recall_end' and e.get('a') == h and e['r'] in W]
        fires.append(dict(game=os.path.basename(os.path.dirname(path)), r=r, me=name[h], ally=name[a], hp=int(l[8]),
                          d0=max(abs(here[0]-allyp[0]), abs(here[1]-allyp[1])), d1=dist_at(r), d3=dist_at(r + 3),
                          my_hits=hits(h), ally_hits=hits(a), taken=round(taken), died=died, ally_died=ally_died,
                          kills=len(enemy_deaths), recalled=recall_end,
                          pos_ok=(champs[h]['x'][rix[r-1]], champs[h]['y'][rix[r-1]]) == here if r-1 in rix else None))
print('games', games, 'fires', len(fires), 'games with fires', len({f['game'] for f in fires}))
for f in fires: print(f)
# fire episodes: consecutive rounds of the same champion merged
eps = []
for f in sorted(fires, key=lambda f: (f['game'], f['me'], f['r'])):
    if eps and eps[-1][-1]['game'] == f['game'] and eps[-1][-1]['me'] == f['me'] and f['r'] - eps[-1][-1]['r'] <= 2: eps[-1].append(f)
    else: eps.append([f])
print('episodes', len(eps))
fought = sum(1 for e in eps if e[0]['my_hits'][0] > 0 and e[0]['ally_hits'][0] > 0)
any_f = sum(1 for e in eps if e[0]['my_hits'][0] > 0 or e[0]['ally_hits'][0] > 0)
died = sum(1 for e in eps if e[0]['died'])
adied = sum(1 for e in eps if e[0]['ally_died'])
kills = sum(1 for e in eps if e[0]['kills'])
print('both hit enemies', fought, 'either hit', any_f, 'we died<=10', died, 'ally died<=10', adied, 'an enemy died<=10', kills)
