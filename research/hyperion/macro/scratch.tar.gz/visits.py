import json, gzip, glob, os, pickle, collections, sys, statistics as st
ana = '/tmp/claude-1000/m4-diag/ana'
games = pickle.load(open('/tmp/claude-1000/m4-diag/games.pkl', 'rb'))
STRONG = {'Elk', 'Golem', 'Monolith'}
allv = []
for d in sorted(glob.glob(ana + '/*/meta.json')):
    gd = os.path.dirname(d)
    meta = json.load(open(d))
    run = meta['sources'][0]['source'].split('/')[-2]
    if run not in games: continue
    fs, wk, D, wh = games[run]
    mp = json.load(open(os.path.join(gd, meta['mapFile'])))
    camp_g = {c['id']: c['group'] for c in mp['camps']}
    gtypes = {g['id']: g['types'] for g in mp['groups']}
    ghp = {g['id']: sum(c['hp'] for c in mp['camps'] if c['group'] == g['id']) for g in mp['groups']}
    strong = {g for g, t in gtypes.items() if STRONG & set(t) and 'Monolith' not in t}
    team = {c['id']: c['team'] for c in meta['champions']}
    name = {c['id']: c['name'] for c in meta['champions']}
    ev = [json.loads(l) for l in gzip.open(gd + '/events.jsonl.gz', 'rt')]
    R = json.load(gzip.open(gd + '/rounds.json.gz'))
    rid = {r: i for i, r in enumerate(R['round'])}
    chp = {c['id']: c for c in R['champions']}
    acts = collections.defaultdict(list)  # (c,G) -> [(r, dealt, taken)]
    dealers = collections.defaultdict(lambda: collections.defaultdict(float))  # (G, r) -> c -> dmg
    clears = collections.defaultdict(list); recalls = collections.defaultdict(list); deaths = collections.defaultdict(list)
    wakes = []
    for e in ev:
        k = e['k']; r = e['r']
        if k in ('attack', 'cast') and 'cdmg' in e:
            for camp, dmg in e['cdmg']:
                G = camp_g.get(camp)
                if G is None: continue
                acts[(e['a'], G)].append((r, dmg, 0))
                dealers[(G, r)][e['a']] += dmg
        elif k == 'camp_attack':
            G = e['g']
            acts[(e['tgt'], G)].append((r, 0, e['dmg']))
            for x in e.get('xdmg', []) or []:
                try: acts[(x[0], G)].append((r, 0, x[1]))
                except Exception: pass
        elif k == 'group_clear': clears[e['g']].append(r)
        elif k == 'recall_end': recalls[e['a']].append(r)
        elif k == 'death': deaths[e['v']].append(r)
        elif k == 'group_wake': wakes.append((r, e['g'], e.get('by')))
    fs_by = collections.defaultdict(dict)
    for r, h, g, kv, l in fs: fs_by[h][r] = (int(g[1:]), kv, l)
    for (c, G), lst in acts.items():
        if team.get(c) != 0 or G not in strong: continue
        lst.sort()
        cur = None
        segs = []
        for r, dl, tk in lst:
            if cur and r - cur['r1'] <= 5:
                cur['r1'] = r; cur['dealt'] += dl; cur['taken'] += tk
            else:
                cur = {'r0': r, 'r1': r, 'dealt': dl, 'taken': tk}; segs.append(cur)
        for s in segs:
            if s['dealt'] < 1: continue  # walked through range only
            r0, r1 = s['r0'], s['r1']
            s.update(game=run, c=c, name=name[c], G=G, types=gtypes[G])
            s['cleared'] = any(r0 <= r <= r1 + 3 for r in clears[G])
            s['recalled'] = any(r1 <= r <= r1 + 15 for r in recalls[c])
            s['died'] = any(r0 <= r <= r1 + 2 for r in deaths[c])
            mates = set(); foes = set()
            for r in range(r0, r1 + 1):
                for a, dmg in dealers.get((G, r), {}).items():
                    if a != c: (mates if team[a] == 0 else foes).add(a)
            s['mates'] = sorted(mates); s['foes'] = sorted(foes)
            i0 = rid.get(r0 - 1, rid.get(r0)); i1 = rid.get(r1, None)
            s['hp0'] = chp[c]['hp'][i0]; s['max'] = chp[c]['maxHp'][i0]
            s['hp1'] = chp[c]['hp'][i1] if i1 is not None else None
            s['ghp0'] = None
            s['woke'] = any(r0 - 1 <= r <= r0 and g == G and b == c for r, g, b in wakes)
            # FS at first hit round, else up to 3 before
            s['fs'] = None
            for r in range(r0, r0 - 4, -1):
                if r in fs_by[c]:
                    s['fs'] = (r,) + fs_by[c][r]; break
            s['D'] = D[c].get(r0)
            allv.append(s)
pickle.dump(allv, open('/tmp/claude-1000/m4-diag/visits.pkl', 'wb'))
print('visits', len(allv))
def summ(vs, label):
    if not vs: return
    dl = sum(v['dealt'] for v in vs); tk = sum(v['taken'] for v in vs)
    print(f'{label:40s} n={len(vs):4d} dealt={dl:8.0f} taken={tk:7.0f} ratio={dl/max(tk,1):.2f} solo={sum(not v["mates"] for v in vs)/len(vs):.2f} recalled={sum(v["recalled"] for v in vs)/len(vs):.2f} woke={sum(v["woke"] for v in vs)/len(vs):.2f}')
clr = [v for v in allv if v['cleared']]; chip = [v for v in allv if not v['cleared']]
summ(allv, 'all'); summ(clr, 'cleared'); summ(chip, 'chip')
summ([v for v in chip if not v['foes']], 'chip, no enemy dmg on group')
print('chips per game', len(chip) / len(games))
print('\nchips by branch/reason at first hit (FS):')
bb = collections.defaultdict(list)
for v in chip:
    key = (v['fs'][2]['br'] + '/' + v['fs'][2]['rsn']) if v['fs'] and v['fs'][1] == v['G'] else ('FS-other-g' if v['fs'] else 'noFS:' + (v['D'][0] if v['D'] else '?'))
    bb[key].append(v)
for key, vs in sorted(bb.items(), key=lambda x: -len(x[1])): summ(vs, key)
print('\ncleared by branch:')
bb2 = collections.defaultdict(list)
for v in clr:
    key = (v['fs'][2]['br'] + '/' + v['fs'][2]['rsn']) if v['fs'] and v['fs'][1] == v['G'] else ('FS-other-g' if v['fs'] else 'noFS:' + (v['D'][0] if v['D'] else '?'))
    bb2[key].append(v)
for key, vs in sorted(bb2.items(), key=lambda x: -len(x[1])): summ(vs, key)
