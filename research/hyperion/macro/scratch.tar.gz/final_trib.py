import sys, json, gzip, collections, glob, os
sys.path.insert(0,'/home/ubuntu/cambc-autumn/tools/replay')
from analysis import Game, resolve
dirs = resolve(sys.argv[1:])
seen=set(); rows=[]
for d in dirs:
    g=Game(d)
    m=g.meta
    if m['sha256'] in seen: continue
    seen.add(m['sha256'])
    res=m['result']; w=res['winner']; R=res['rounds']
    team={c['id']:c['team'] for c in m['champions']}
    typ={c['id']:c['type'] for c in m['champions']}
    starts=[e for e in g.events if e['k']=='tribute_start']
    ends=[e for e in g.events if e['k']=='tribute_end']
    cancels=[e for e in g.events if e['k']=='tribute_cancel']
    if res['gems'][w] < 1000: rows.append(('limit',)); continue
    last=[e for e in ends if team[e['a']]==w]
    if not last: continue
    le=last[-1]
    st=[e for e in starts if e['a']==le['a'] and e['r']<=le['r']][-1]
    before = le['total']-le['gems']
    # enemy cancels of winner's tributes in game
    rows.append(('win', le['gems'], st['dur'], before, typ[le['a']], res['gems'][1-w], R))
n=len(rows); lim=sum(1 for r in rows if r[0]=='limit')
wins=[r for r in rows if r[0]=='win']
print('games',n,'round-limit',lim)
import statistics as S
print('final tribute gems median',S.median(r[1] for r in wins),'mean',S.mean(r[1] for r in wins))
print('dur median',S.median(r[2] for r in wins))
b=collections.Counter(('<20' if r[1]<20 else '<100' if r[1]<100 else '<300' if r[1]<300 else '300+') for r in wins); print(b)
print('by type',collections.Counter(r[4] for r in wins).most_common(6))
print('loser score at end median',S.median(r[5] for r in wins))
big=[r for r in wins if r[2]>=10]; print('final channel>=10 turns:',len(big), 'loser median score', S.median(r[5] for r in big) if big else None)
