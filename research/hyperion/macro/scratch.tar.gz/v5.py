import pickle, sys
allv = pickle.load(open('/tmp/claude-1000/m4-diag/visits.pkl', 'rb'))
game = sys.argv[1]
for v in sorted([v for v in allv if v['game'] == game], key=lambda v: v['r0']):
    k = v['fs'][2] if v['fs'] else {}
    print(f"r{v['r0']}-{v['r1']} {v['name'][:10]:10s} c{v['c']} G{v['G']} {'CLEAR' if v['cleared'] else 'chip '} dealt={v['dealt']:.0f} taken={v['taken']:.0f} hp0={v['hp0']:.0f}/{v['max']:.0f} hp1={v['hp1']} mates={v['mates']} foes={v['foes']} woke={int(v['woke'])} rec={int(v['recalled'])} br={k.get('br')}/{k.get('rsn')} alone={k.get('alone')} spare={k.get('spare')} line={k.get('line')}")
