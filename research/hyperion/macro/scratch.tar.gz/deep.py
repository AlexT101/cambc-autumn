import sys, json, collections, math
sys.path.insert(0, '/home/ubuntu/cambc-autumn/tools/emblab')
import pilot as P, evehicle as ev
lab = '/home/ubuntu/cambc-autumn/replays/emblab/pilot/'
G = {g['id']: g for g in P.jsonl(lab + 'games.jsonl') if 'winner' in g and g.get('draft_ok') and 'pair' not in g or ('pair' in g and g['vehicle'] % 2 == 0 and 'winner' in g)}
D = [d for d in P.jsonl(lab + 'decisions.jsonl') if d['id'] in G and d['k'] <= 2 and d['arm'] >= 0 and d['chosen'] != d['model']]
TYPES = ['ryth','vesper','vendetta','cassi','issac','stellar','prism','marcella','willow','ren','varg','tavi','hor']
# forced arm stat vs the model's stat, regret by the analytic model
def regret(d):
    vm, va = d['v'][d['model']], d['v'][d['arm']]
    return (vm - va) / max(abs(vm), 1e-3)
cols = ['side'] + [f'c{c}' for c in range(12)] + [f'stat_{s}' for s in ev.STATS] + ['same_stat'] + ['reg_lo', 'reg_mid', 'reg_hi']
cols += [f'{t}_{s}' for t in TYPES for s in ev.STATS]
idx = {c: i for i, c in enumerate(cols)}
per = collections.defaultdict(lambda: [collections.Counter(), collections.Counter()])
for d in D:
    c = per[d['id']][d['team']]
    s = d['arm'] % 3
    c[f'stat_{ev.STATS[s]}'] += 1
    c['same_stat'] += s == d['model'] % 3
    r = regret(d)
    c['reg_lo' if r < 0.15 else 'reg_mid' if r < 0.4 else 'reg_hi'] += 1
    c[f"{TYPES[d['type']]}_{ev.STATS[s]}"] += 1
X, y = [], []
for gid, g in G.items():
    x = [0.0] * len(cols); x[0] = 1
    for t, sgn in ((0, 1), (1, -1)):
        for ch in g['AB'[t]]: x[idx[f'c{P.CH.index(ch)}']] += sgn
        for k, v in per[gid][t].items(): x[idx[k]] += sgn * v
    X.append(x); y.append(1.0 if g['winner'] == 0 else 0.0)
lam = [0.01] + [1.0] * (len(cols) - 1)
# two fits: stat + regret (collinear sets kept apart)
def fit(keep):
    ks = [0] + [idx[c] for c in cols if any(c.startswith(p) for p in keep)]
    th, se = P.logistic([[x[j] for j in ks] for x in X], y, [lam[j] for j in ks])
    return {cols[j]: (th[i], se[i]) for i, j in enumerate(ks)}
print(len(G), 'games', len(D), 'forced k<=2 decisions that differ from the model')
r = fit(['c', 'stat_', 'same_stat']); print({k: f'{a*25:+.2f}±{b*25:.2f}' for k, (a, b) in r.items() if not k.startswith('c') or k == 'same_stat'})
r = fit(['c', 'reg_']); print({k: f'{a*25:+.2f}±{b*25:.2f}' for k, (a, b) in r.items() if k.startswith('reg')})
r = fit(['c'] + [t + '_' for t in TYPES])
for t in TYPES:
    print(f'{t:9s}', '  '.join(f"{s[:3]} {r[f'{t}_{s}'][0]*25:+5.1f}±{r[f'{t}_{s}'][1]*25:.1f}" for s in ev.STATS if f'{t}_{s}' in r))
